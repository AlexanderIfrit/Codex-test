---
source: https://m3.material.io/styles/motion/transitions/transition-patterns + applying-transitions
category: Styles / Motion
spec-version: v0.192
---

# Motion Transitions — Heuristiques de décision

4 patterns : Container Transform · Shared Axis · Fade Through · Fade
Règles d'application : sans jump cuts · fades propres · modèle spatial cohérent · direction unifiée

---

## Schéma de pensée

Les patterns de transition M3 sont des protocoles narratifs : ils expliquent à l'utilisateur comment deux états sont reliés spatialement. Container Transform dit "cet élément vient de là". Shared Axis dit "on se déplace dans une direction". Fade Through dit "on remplace un contenu par un autre sans lien direct". Fade dit "cet élément apparaît/disparaît dans sa propre bulle". Choisir le bon pattern revient à choisir la bonne narrative pour la relation entre les deux états.

---

## Principes

- Les transitions communiquent des **relations spatiales** entre éléments et états.
- Un jump cut (transition instantanée) est toujours désorienter — ne l'utiliser que si la vitesse pure est la priorité absolue (apps de productivité experts).
- Les skeleton loaders stabilisent le layout pendant le chargement — ils évitent les sauts de position au moment où le contenu réel arrive.
- Les éléments persistent entre les états quand ils existent dans les deux (hero image, titre) — les autres entrent/sortent selon leur direction.
- Toujours maintenir un modèle spatial cohérent dans toute l'app — deux patterns contradictoires entre les mêmes deux vues créent une confusion durable.

---

## Les 4 patterns de transition

### Container Transform
**Usage :** Quand un élément UI se développe pour révéler une vue détail (card → détail, list item → écran plein)
- L'élément source (card, fab, chip) se transforme en conteneur de la destination
- La forme, la couleur et la position de l'élément source morphent vers la vue destination
- Crée la relation sémantique la plus forte : "cette vue vient de cet élément"

### Shared Axis
**Usage :** Navigation entre destinations ayant une relation spatiale ou hiérarchique (tabs, onboarding steps, forward/back)
- Les deux vues partagent un axe de mouvement (X = horizontal, Y = vertical, Z = scale in/out)
- Axe X : navigations latérales (tabs, wizards, carousel)
- Axe Y : défilement vers des niveaux (settings qui s'ouvrent vers le bas)
- Axe Z : zoom in/out (parent → enfant, écran → focus)

### Fade Through
**Usage :** Quand les deux états n'ont pas de relation spatiale directe (bottom nav entre destinations, changement de contenu d'un même conteneur)
- Vue sortante fade out complètement avant que la vue entrante fade in
- Jamais de cross-fade simultané — le contenu des deux vues ne se superpose jamais
- Signifie : "ces deux contenus sont dans le même espace mais sans lien direct"

### Fade
**Usage :** Éléments qui entrent ou sortent au sein d'un conteneur sans changer la structure de la page (tooltips, popovers, snackbars, overlays)
- Transition de simple opacité — l'élément n'a pas d'origine spatiale logique
- Le plus discret des patterns — à utiliser quand aucun des trois autres n'est pertinent

---

## H1 — Sélectionner le bon pattern

**Équation :** Pertinence du pattern ∝ Force de la relation entre les deux états (fort) + Cohérence avec le modèle spatial (fort)

| Relation entre les deux états | Pattern recommandé |
|------------------------------|-------------------|
| Un élément devient une vue (card → detail) | Container Transform |
| Navigation latérale entre vues de même niveau | Shared Axis X |
| Navigation en profondeur (parent → enfant) | Shared Axis Z (scale) |
| Changement de destination sans lien spatial | Fade Through |
| Apparition/disparition dans la même vue | Fade |
| Aucun lien — priorité à la vitesse | Jump Cut (exception) |

**Zone de bascule :** Une nav bar avec 4 destinations : Shared Axis X ou Fade Through ? Si les destinations ont une logique spatiale ordonnée (Home < Explore < Library < Profile), Shared Axis X. Si elles sont des destinations équivalentes sans ordre, Fade Through — le Shared Axis X impliquerait une logique d'ordre qui n'existe pas.

**Raison généralisable :** Le pattern de transition est une affirmation sur la relation spatiale. Container Transform dit "ça vient de là". Utiliser le mauvais pattern crée une incohérence cognitive — l'utilisateur attend d'où vient l'élément et il vient d'ailleurs.

---

## H2 — Règles anti-patterns d'application

**Équation :** Qualité des transitions ∝ Fades propres (fort) + Direction unifiée (fort) + Skeleton loaders (modéré) − Jump cuts (fort) − Cross-fades simultanés (fort)

### ❌ Jump cuts
- Éviter sauf si vitesse pure > compréhension (apps experts, raccourcis clavier)
- Si jump cut unavoidable : au minimum, changer la couleur de fond ou d'un élément pivot pour signaler le changement d'état

### ❌ Cross-fades simultanés
- Ne jamais fade-in une vue pendant que l'autre fait son fade-out — le chevauchement de transparences produit des frames visuellement sales
- Séquence correcte : fade-out complet → fade-in (Fade Through)

### ✅ Skeleton loaders
- Stabiliser le layout avec des skeletons avant d'afficher le contenu réel
- Éviter que le contenu "pop" et décale d'autres éléments après le chargement
- Le skeleton doit respecter exactement la structure finale (même nombre de lignes, même hauteur de carte)

**Raison généralisable (règles anti-patterns) :** La mémoire visuelle de l'utilisateur retient l'état précédent pendant ~200ms après un changement. Un cross-fade ou un jump cut n'est pas "instantané" pour le cerveau — il produit une rupture de continuité perçue comme un bug ou un glitch, même quand c'est intentionnel.

### ✅ Direction unifiée
- Tous les éléments d'une même transition bougent dans la même direction primaire
- Exception tolérée : un élément hero (image, titre) peut persister et ne pas se déplacer pendant que le reste de la vue transite

### ✅ Modèle spatial cohérent
- Définir et documenter le modèle spatial de l'app (quelle direction = quel type de navigation)
- Ne pas le changer selon les vues — l'utilisateur construit mentalement une carte de l'app

---

## H3 — Container Transform : conditions d'application

**Équation :** Pertinence Container Transform ∝ Élément source identifiable (fort) + Continuité visuelle possible (modéré) − Distance trop grande entre source et destination (faible)

- L'élément source doit être visible à l'écran avant le trigger — pas de Container Transform depuis un élément invisible (ex : bouton en dessous du fold)
- La forme de l'élément source doit pouvoir morphper naturellement vers la destination — une petite card vers un grand dialog fonctionne, un chip vers une app bar non
- Sur les devices avec GPU limité, Container Transform peut créer des jank — prévoir un fallback en Fade Through

**Zone de bascule :** Une liste d'items très longue avec Container Transform sur chaque item : correct si seule une instance à la fois peut être ouverte. Si plusieurs items peuvent être sélectionnés simultanément, Container Transform ne s'applique pas (il n'y a pas un seul élément source).

**Raison généralisable :** Container Transform fonctionne parce qu'il ancre la nouvelle vue à un élément connu de l'utilisateur. Sans cet ancrage (élément source absent ou multiple), la transition perd sa valeur narrative et devient un effet visuel coûteux sans bénéfice cognitif.

---

## H4 — Shared Axis : choisir l'axe correct

**Équation :** Cohérence de l'axe ∝ Direction implicite dans la structure de l'app (fort) + Convention plateforme (modéré)

| Axe | Direction physique | Corresponds à |
|-----|-------------------|--------------|
| X (horizontal) | Gauche ↔ Droite | Tabs, wizards, carousel, histoire temporelle |
| Y (vertical) | Bas → Haut | Hiérarchie descendante, settings nested |
| Z (scale) | Petit → Grand | Parent → enfant, zoom sémantique |

- Axe Z (scale in) : l'écran enfant entre en grossissant depuis le centre, sortie en rétrécissant
- Convention iOS : navigation stack = slide X (droite → gauche). Ne pas contrevenir aux conventions de la plateforme.
- Convention Android : le bouton Back inverse le Shared Axis de l'entrée

---

## Traduction en application concrète

- **Mapping des transitions** : pour chaque pair de vues dans l'app, documenter le pattern de transition utilisé dans un tableau de référence — évite les incohérences entre équipes.
- **Skeleton loaders** : toujours préfixer les vues avec skeleton quand le temps de chargement peut dépasser 300ms.
- **Reduced motion** : remplacer Container Transform par un simple Fade, Shared Axis par des Fades directionnels subtils (pas de déplacement, juste opacity).
- **Performance** : Container Transform est coûteux (morphing de forme + layout change) — tester sur des devices mid-range avant de le généraliser.
