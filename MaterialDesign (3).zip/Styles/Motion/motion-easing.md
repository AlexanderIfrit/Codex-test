---
source: https://m3.material.io/styles/motion/easing-and-duration
category: Styles / Motion
spec-version: v0.192
---

# Motion Easing & Duration — Heuristiques de décision

4 courbes d'easing · Durées calibrées par type de changement
Tokens : md-sys-motion.*

---

## Schéma de pensée

L'easing transforme un déplacement mécanique en mouvement naturel. Les quatre courbes de M3 correspondent chacune à une intention physique précise : Standard pour les transitions bidirectionnelles, Emphasized pour les moments d'entrée importants, Emphasized Decelerate pour l'arrivée au premier plan, Emphasized Accelerate pour la sortie de l'écran. La durée règle l'énergie du mouvement : trop court = brusque, trop long = lent. Ces deux paramètres (courbe + durée) sont les seuls qui font la différence entre une interface qui semble vivante et une interface qui semble coincée.

---

## Principes

- **Standard** : démarrage rapide, fin progressive — pour les éléments qui entrent et sortent du cadre visible (menus, chips, cartes).
- **Emphasized** : accent fort au démarrage et à l'arrivée — pour les transitions principales de navigation qui doivent se sentir importantes.
- **Emphasized Decelerate** : démarrage rapide, décélération longue — pour les éléments qui entrent en scène depuis hors-cadre (arrive en premier plan).
- **Emphasized Accelerate** : accélération longue, fin rapide — pour les éléments qui quittent l'écran (sort du premier plan).
- Pour les transitions de navigation principale : utiliser Emphasized Decelerate pour l'entrée et Emphasized Accelerate pour la sortie. Pour les composants secondaires (menus, chips, tooltips), Standard suffit.

---

## Tokens de design — courbes d'easing

| Token | Cubic-bezier | Usage |
|-------|-------------|-------|
| `md-sys-motion.easing-standard` | `cubic-bezier(0.2, 0, 0, 1)` | Transitions standard bidirectionnelles |
| `md-sys-motion.easing-standard-accelerate` | `cubic-bezier(0.3, 0, 1, 1)` | Sortie de la vue (sort du cadre) |
| `md-sys-motion.easing-standard-decelerate` | `cubic-bezier(0, 0, 0, 1)` | Entrée dans la vue (entre dans le cadre) |
| `md-sys-motion.easing-emphasized` | `cubic-bezier(0.2, 0, 0, 1)` (avec début accéléré) | Navigation principale, transitions importantes |
| `md-sys-motion.easing-emphasized-accelerate` | `cubic-bezier(0.3, 0, 0.8, 0.15)` | Sortie écran (slide out, close) |
| `md-sys-motion.easing-emphasized-decelerate` | `cubic-bezier(0.05, 0.7, 0.1, 1)` | Entrée écran (slide in, open) |
| `md-sys-motion.easing-linear` | `cubic-bezier(0, 0, 1, 1)` | Animations en boucle, progress bars |

---

## Tokens de design — durées

| Token | Valeur | Usage |
|-------|--------|-------|
| `md-sys-motion.duration-short1` | 50ms | Micro-feedback (ripple, highlight) |
| `md-sys-motion.duration-short2` | 100ms | Fade in/out rapide, tooltip show |
| `md-sys-motion.duration-short3` | 150ms | Changement d'état simple |
| `md-sys-motion.duration-short4` | 200ms | Expansion petite (menu, popover) |
| `md-sys-motion.duration-medium1` | 250ms | Transition composant moyen |
| `md-sys-motion.duration-medium2` | 300ms | Transition dialog, snackbar |
| `md-sys-motion.duration-medium3` | 350ms | Transition élément riche |
| `md-sys-motion.duration-medium4` | 400ms | Transition complexe bidirectionnelle |
| `md-sys-motion.duration-long1` | 450ms | Transition de page |
| `md-sys-motion.duration-long2` | 500ms | Transition plein écran |
| `md-sys-motion.duration-long3` | 550ms | Expanded/collapsed riche |
| `md-sys-motion.duration-long4` | 600ms | Transition avec hero image |
| `md-sys-motion.duration-extra-long1` | 700ms | Animation expressive simple |
| `md-sys-motion.duration-extra-long2` | 800ms | Animation expressive modérée |
| `md-sys-motion.duration-extra-long3` | 900ms | Animation expressive riche |
| `md-sys-motion.duration-extra-long4` | 1000ms | Onboarding, célébration |

---

## H1 — Choisir entre Standard et Emphasized

**Équation :** Emphase de la transition ∝ Importance navigationnelle (fort) + Taille de l'élément animé (modéré) − Fréquence de répétition (modéré)

| Contexte | Easing recommandé |
|----------|------------------|
| Ouverture d'un dialog | Emphasized Decelerate (entrée) |
| Fermeture d'un dialog | Emphasized Accelerate (sortie) |
| Navigation entre pages principales | Emphasized (aller) / Emphasized (retour inversé) |
| Menu dropdown qui s'ouvre/ferme | Standard |
| Chip qui s'ajoute/supprime | Standard |
| Snackbar qui entre/sort | Emphasized Decelerate/Accelerate |
| Progress bar | Linear |

- Emphasized est réservé aux transitions qui méritent d'être remarquées — ne pas l'appliquer à tous les micro-changements
- Standard est la valeur par défaut pour tout ce qui n'est pas une transition de navigation principale

**Zone de bascule :** Un bottom sheet qui s'ouvre — est-ce Standard ou Emphasized Decelerate ? Si le bottom sheet contient du contenu contextuel secondaire → Standard. Si c'est un écran plein écran ou une action principale → Emphasized Decelerate.

**Raison généralisable :** Emphasized Decelerate simule un objet qui arrive rapidement puis ralentit pour "atterrir" — perception physique de quelque chose de significatif qui se pose. Standard simule un objet qui démarre doucement — perception d'un mécanisme fluide mais discret.

---

## H2 — Calibrer la durée selon la taille de l'animation

**Équation :** Durée optimale ∝ Distance parcourue (fort) + Complexité visuelle (modéré) + Importance du moment (faible)

| Échelle de l'animation | Fourchette de durée |
|-----------------------|-------------------|
| Micro-feedback (< 50dp de déplacement) | 50–200ms (short1–short4) |
| Composant moyen (dialog, tooltip, chip) | 200–400ms (medium1–medium4) |
| Transition de page/écran | 400–600ms (long1–long4) |
| Animation expressive (onboarding, joie) | 600–1000ms (extra-long) |

- Une animation de 600ms sur une action répétée (envoi de message, ajout à la liste) devient irritante après la 3ème occurrence — utiliser ≤ 300ms pour les actions répétables
- Les durées extra-long sont réservées aux moments uniques ou rares — jamais sur des flows courants

**Zone de bascule :** La même transition peut nécessiter une durée différente selon le device. Sur un device lent, 400ms peut sembler fluide mais sur un flagship à 120Hz, 400ms semblera lent. La durée perçue dépend du frame rate — tester sur la cible réelle.

---

## H3 — Entrée et sortie : toujours des courbes asymétriques

**Équation :** Naturel perçu ∝ Asymétrie entrée/sortie (fort) − Symétrie mécanique (fort)

- **Entrée** → toujours Decelerate : l'élément arrive vite et ralentit pour s'ancrer
- **Sortie** → toujours Accelerate : l'élément part lentement et accélère pour disparaître
- Ne jamais utiliser la même courbe pour entrée et sortie d'un même élément — c'est ce qui crée l'effet "mécanique"

```css
/* Exemple correct */
.dialog-enter { animation: slide-in 300ms cubic-bezier(0.05, 0.7, 0.1, 1); }    /* Decelerate */
.dialog-exit  { animation: slide-out 250ms cubic-bezier(0.3, 0, 0.8, 0.15); }   /* Accelerate */
```

**Zone de bascule :** Pour les transitions instantanées (opacity toggle sans déplacement), une légère asymétrie de durée suffit : fade-in en 200ms, fade-out en 150ms. Le rapport ~1.3x rend la sortie plus rapide que l'entrée, ce qui semble naturel.

---

## Traduction en application concrète

- **Design handoff** : spécifier systématiquement 3 paramètres pour chaque animation : durée (token), easing (token), propriété(s) animée(s). Jamais "fade in rapide".
- **CSS** : utiliser `transition-timing-function` + `transition-duration` avec les valeurs de token exactes.
- **Performance** : animer uniquement `transform` et `opacity` — éviter `width`, `height`, `top`, `left` qui déclenchent un layout reflow.
