---
source: https://m3.material.io/styles/motion/overview
category: Styles / Motion
spec-version: v0.192
---

# Motion Physics — Heuristiques de décision

Système : physique naturelle · continuité spatiale · feedback expressif
Principes fondateurs : informative · directionnelle · attentive · expressive

---

## Schéma de pensée

Le motion M3 n'est pas de l'animation pour l'animation — chaque mouvement transporte une information spatiale ou causale. L'utilisateur doit comprendre intuitivement d'où vient un élément, où il va, et pourquoi il bouge. Les quatre qualités du bon motion (informative, directionnelle, attentive, expressive) servent de filtre de décision : si un mouvement ne passe pas ce filtre, il ralentit l'interface sans rien apporter.

---

## Principes

- **Informative** : le movement révèle des relations entre éléments — une carte qui s'ouvre en plein écran montre visuellement son origine.
- **Directionnelle** : les éléments se déplacent de façon cohérente avec un modèle spatial de l'app — retour arrière = mouvement inverse d'entrée.
- **Attentive** : le movement guide l'attention vers ce qui compte — les éléments qui entrent en scène arrivent avant ceux qui sont secondaires.
- **Expressive** : moments délibérés de joie ou de personnalité, réservés aux points clés du parcours, pas systématisés.
- Le mouvement naturel utilise la physique (accélération, décélération) plutôt que les interpolations linéaires.

---

## H1 — Les 4 qualités comme filtre de validation

**Équation :** Pertinence d'une animation ∝ Valeur informationnelle (fort) + Cohérence directionnelle (modéré) + Pertinence attentionnelle (modéré) − Animation décorative pure (fort)

| Question | Valide si |
|----------|----------|
| Cette animation apprend-elle quelque chose à l'utilisateur ? | Oui → Informative |
| Le mouvement a-t-il un sens spatial cohérent ? | Oui → Directionnelle |
| L'animation guide-t-elle l'œil vers le bon endroit ? | Oui → Attentive |
| C'est un moment de célébration ou de personnalité intentionnel ? | Oui → Expressive |
| Aucune de ces réponses n'est "oui" | ❌ Supprimer l'animation |

**Zone de bascule :** Une animation de chargement (spinner, skeleton) est-elle "informative" ? Oui — elle informe que quelque chose est en cours. Mais si le contenu arrive en < 300ms, l'animation doit être absente plutôt que de flasher brièvement.

**Raison généralisable :** Les animations inutiles coûtent du temps cognitif. Sur des sessions longues (apps de productivité), le cumul de ces coûts génère de la fatigue et de la frustration.

---

## H2 — Motion réduit : toujours respecter la préférence utilisateur

**Équation :** Accessibilité motion ∝ Support prefers-reduced-motion (fort) + Alternatives sans mouvement (fort) − Animations imposées (fort)

- `prefers-reduced-motion: reduce` → désactiver toutes les transitions de position et transformation
- **Conserver** : changements d'opacité (fade in/out), changements de couleur, changements d'état visuels sans déplacement
- **Supprimer** : slide, scale, translate, rotate, parallax, auto-play
- Les utilisateurs avec des troubles vestibulaires ou de l'épilepsie peuvent être physiquement affectés par certains mouvements

**Zone de bascule :** Un simple `opacity` change est-il acceptable en reduced-motion ? Oui — l'opacité ne crée pas de mouvement perçu qui peut provoquer des réactions vestibulaires. Une légère scale (95%→100%) est borderline — à éviter si le scale est perceptible.

---

## H3 — Cohérence spatiale : le modèle mental de l'app

**Équation :** Orientation de l'utilisateur ∝ Cohérence directionnelle des transitions (fort) + Modèle spatial persistant (fort) − Directions arbitraires (fort)

Modèle spatial de base :
- **Hiérarchie** (parent → enfant) : éléments enfants entrent depuis le fond/centre, sortent vers le fond/centre
- **Navigation latérale** (entre onglets/pages mêmes niveau) : slide horizontal, le sens indique la position relative
- **Retour** : mouvement inverse de l'entrée — si entré depuis la droite, retour vers la droite
- **Modal/overlay** : entre depuis le bas (mobile), disparaît vers le bas

**Zone de bascule :** Dans une navigation complexe avec tabs + stack + modals, maintenir la cohérence directionnelle devient difficile. Dans ce cas, simplifier — choisir 2-3 patterns directionnels et les appliquer systématiquement plutôt que d'inventer une direction par cas.

---

## H4 — Timing psychologique : quand le mouvement est trop long

**Équation :** Fluidité perçue ∝ Durée adaptée à l'échelle du mouvement (fort) − Sur-animation (fort)

| Type de changement | Durée cible |
|-------------------|------------|
| Micro-interaction (bouton, checkbox) | 100–200ms |
| Transition de composant (dialog, snackbar) | 200–400ms |
| Transition de page / écran | 300–500ms |
| Animation expressive (onboarding, célébration) | 500–1000ms |

- En dessous de 100ms : imperceptible (inutile)
- Au-delà de 500ms pour une navigation : l'app semble lente
- Les animations expressives sont tolérées plus longues parce que l'utilisateur sait qu'il est dans un moment spécial, pas dans un flux de navigation

**Zone de bascule :** Sur de vieux devices ou connexions lentes, même des animations bien calibrées peuvent dégrader la fluidité perçue. Tester sur le device le moins performant de la cible, pas seulement sur le flagship.

---

## Traduction en application concrète

- **Premier audit** : passer chaque animation dans le filtre des 4 qualités — supprimer toutes celles qui n'en passent aucune.
- **Accessibility** : implémenter `prefers-reduced-motion` en CSS/JS comme requirement non-négociable, pas en afterthought.
- **Documentation** : pour chaque pattern de transition, documenter le modèle spatial qu'il exprime — sinon les développeurs inventeront des directions incohérentes.
