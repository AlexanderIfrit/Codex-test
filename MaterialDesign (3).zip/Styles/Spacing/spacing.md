---
source: https://m3.material.io/styles/spacing/overview + applying-spacing + tokens
category: Styles / Spacing
spec-version: v0.192
---

# Spacing — Heuristiques de décision

Unité de base : 4dp · 13 tokens définis · Application : padding, margin, gap, inset
Grille adaptative : 4 colonnes (compact) → 8 (medium) → 12 (expanded)

---

## Schéma de pensée

L'espacement M3 repose sur une grille de 4dp qui crée de la cohérence visuelle à tous les niveaux — de l'espace interne d'un bouton à l'écartement entre les sections de page. La règle fondamentale est simple : tout espacement doit être un multiple de 4. L'exception tolérée est le multiple de 2 (2dp) pour des ajustements optiques fins. Cette discipline d'espacement est ce qui donne à une interface sa sensation de "serré mais respiré" : chaque espace est intentionnel, rien n'est aléatoire.

---

## Principes

- Unité de base : **4dp** — tous les espacements sont des multiples de 4.
- Exception tolérée : **2dp** (`spacing-50`) pour des ajustements fins (icône/label gap, badge offset).
- L'espacement s'applique à toutes les dimensions : padding interne, margin externe, gap entre éléments, inset dans les conteneurs.
- Les composants M3 ont des valeurs d'espacement internes définies dans leur spec — ne pas les modifier.
- La grille de layout divise l'écran en colonnes avec des gutters (espacements entre colonnes) et des margins (espacement sur les bords).

---

## Tokens de design — espacement

| Token | Valeur px | Valeur dp | Usage typique |
|-------|----------|----------|---------------|
| `md-sys-spacing-0` | 0px | 0dp | Pas d'espace, adjacents |
| `md-sys-spacing-50` | 2px | 2dp | Ajustement optique fin, badge offset |
| `md-sys-spacing-100` | 4px | 4dp | Très proche (icône + texte inline) |
| `md-sys-spacing-200` | 8px | 8dp | Intérieur compact (chips, dense list) |
| `md-sys-spacing-300` | 12px | 12dp | Padding vertical composant compact |
| `md-sys-spacing-400` | 16px | 16dp | **Standard** — padding horizontal composant |
| `md-sys-spacing-500` | 20px | 20dp | Padding généreux |
| `md-sys-spacing-600` | 24px | 24dp | Séparation de sections proches |
| `md-sys-spacing-700` | 28px | 28dp | — |
| `md-sys-spacing-800` | 32dp | 32dp | Séparation de blocs distincts |
| `md-sys-spacing-900` | 36px | 36dp | — |
| `md-sys-spacing-1000` | 40px | 40dp | Séparation importante |
| `md-sys-spacing-1100` | 44px | 44dp | — |
| `md-sys-spacing-1200` | 48px | 48dp | Séparation forte, sections majeures |

---

## Grille de layout M3

| Point de rupture | Colonnes | Gutter | Margin |
|-----------------|----------|--------|--------|
| Compact (< 600dp) | 4 | 16dp | 16dp |
| Medium (600–839dp) | 8 | 24dp | 24dp |
| Expanded (≥ 840dp) | 12 | 24dp | 24dp |
| Large (≥ 1200dp) | 12 | 24dp | 48–200dp variable |
| Extra Large (≥ 1600dp) | 12 | 24dp | Max-width container centré |

---

## Espacements internes standards par composant

| Zone du composant | Valeur standard |
|------------------|----------------|
| Padding horizontal bouton | 24dp (16dp avec icône leading) |
| Padding vertical bouton | 10dp (hauteur totale 40dp) |
| Padding interne card | 16dp |
| Padding liste item | 16dp horizontal, 12dp vertical |
| Gutter entre composants dans la même section | 8dp |
| Gutter entre sections de la page | 24–32dp |
| Padding écran (margin globale) | 16dp (compact), 24dp (medium+) |

---

## H1 — Choisir l'espacement selon la densité voulue

**Équation :** Densité de l'interface ∝ Taille de l'espacement inversée (fort) + Fréquence d'usage de la vue (modéré) + Nombre d'items affichés (fort)

| Densité | Espacement type | Cas d'usage |
|---------|----------------|-------------|
| Ultra-dense | 4–8dp | Tableaux de données, IDEs, dashboards techniques |
| Dense | 8–12dp | Listes longues, apps de messagerie |
| Standard | 12–16dp | Apps généralistes, navigation, paramètres |
| Aéré | 16–24dp | Landing pages, onboarding, media apps |
| Très aéré | 24–48dp | Pages éditoriales, lecteurs, vides |

- Plus une vue est utilisée fréquemment (inbox, feed), plus la densité peut être élevée — l'utilisateur expert préfère voir plus d'info
- Les vues rares ou critiques (onboarding, checkout) bénéficient d'un espacement généreux — réduit la charge cognitive au moment décisif

**Zone de bascule :** Un même composant dans deux contextes différents peut nécessiter des densités différentes — ex : une liste d'emails en vue inbox (dense) vs en vue recherche (standard). Prévoir des variantes de densité explicites plutôt que d'ajuster composant par composant.

**Raison généralisable :** L'espacement est une ressource écran. Plus d'espace = moins d'info visible = plus de scroll = plus de charge pour l'utilisateur. Moins d'espace = plus d'info visible = moins de scroll = plus de charge cognitive par item. La densité optimale dépend du contenu et du contexte d'usage.

---

## H2 — Respecter la zone de tap 48×48dp minimum

**Équation :** Accessibilité tactile ∝ Zone de tap ≥ 48×48dp (fort) + Espacement entre zones adjacentes ≥ 8dp (modéré)

- Un élément interactif de 24dp visuellement doit avoir une zone de tap de 48dp (12dp de marge invisible de chaque côté)
- Deux boutons adjacents sans marge visible peuvent avoir des zones de tap qui se chevauchent → erreurs tactiles
- Espacement minimum entre deux zones de tap : 8dp pour éviter les erreurs accidentelles

**Zone de bascule :** Sur tablet/desktop avec curseur, la zone de tap 48dp n'est pas critique — la précision de la souris compense. Mais sur mobile, c'est une règle d'accessibilité fondamentale, pas une recommandation.

**Raison généralisable :** Le doigt humain a une zone de contact de 10–14mm (~40–56dp à 160dpi). Une zone de tap inférieure à 48dp demande une précision physique supérieure à la capacité moyenne — les utilisateurs manquent la cible, cliquent sur le mauvais élément, et perçoivent l'app comme "difficile à utiliser".

---

## H3 — Espacement vertical vs horizontal : logiques différentes

**Équation :** Lisibilité du layout ∝ Espacement vertical ≥ espacement horizontal interne (modéré) + Séparation de sections claire (fort)

- L'espacement vertical sépare des contenus de nature différente (section → section) → valeurs plus grandes (24–48dp)
- L'espacement horizontal sépare des contenus du même type (colonne → colonne) → valeurs intermédiaires (16–24dp)
- Le padding interne des composants (horizontal) est souvent plus grand que le padding vertical — les composants sont naturellement plus larges que hauts
- Entre deux éléments de même groupe (deux chips, deux boutons en ligne), utiliser 8dp systématiquement

**Zone de bascule :** Sur un layout qui utilise des cartes en grille, l'espacement vertical (entre rangées) et horizontal (entre colonnes) doit être identique — un espacement asymétrique crée une grille qui "penche" visuellement.

**Raison généralisable :** L'œil perçoit la grille sous-jacente à travers les espaces négatifs. Une asymétrie de gutter (vertical ≠ horizontal) suggère que les éléments ont une relation différente selon l'axe, ce qui n'est généralement pas l'intention dans une grille de cards homogènes.

---

## H4 — Ne jamais utiliser des valeurs hors de la grille 4dp

**Équation :** Cohérence visuelle ∝ Valeurs multiples de 4 (fort) + Tokens définis (fort) − Valeurs arbitraires (fort)

- 3dp, 7dp, 15px : valeurs hors-grille qui créent des incohérences visuelles subtiles mais réelles
- 2dp acceptable uniquement pour des décalages optiques (ex : badge offset, icon/label alignment)
- Sur web, 1px peut être nécessaire pour des bordures — toléré uniquement pour les bordures, pas pour les espacements

**Zone de bascule :** Quand un espacement de 16dp semble trop grand et 12dp trop petit, la tentation est de mettre 14dp. La solution correcte est de revisiter le composant et son contexte plutôt que de briser la grille — souvent, c'est un problème de taille de police ou d'icône, pas d'espacement.

**Raison généralisable :** Les valeurs hors-grille créent des sous-pixels sur des densités d'affichage non-entières (1.5x, 2.625x…). Un espacement de 14dp sur un écran à 2.625x (Pixel 6) donne 36.75px — arrondi à 37px par le renderer, créant un artefact d'1px sur certains éléments adjacents. La grille 4dp garantit que toutes les valeurs sont entières sur tous les facteurs de densité courants.

---

## Traduction en application concrète

- **Design** : utiliser uniquement les tokens `md-sys-spacing-*` dans Figma — jamais des valeurs numériques libres.
- **Code** : créer des variables CSS/design tokens pour les espacements et ne jamais hardcoder des valeurs dans les composants.
- **Audit** : passer en revue tout espacement non-multiple de 4 comme un bug de token — le corriger au niveau du token, pas du composant.
- **Responsive** : adapter l'espacement aux points de rupture (margins 16dp → 24dp, gutters 16dp → 24dp) via des tokens responsive.
