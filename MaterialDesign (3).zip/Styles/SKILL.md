---
name: material-design-styles
description: >
  Documentation de référence M3 pour les décisions de style visuel :
  couleur, élévation, icônes, motion, forme, espacement, typographie.
  Format : heuristiques pondérées + tokens réels (v0.192+).
---

# Material Design 3 — Styles : Index

> Chaque fichier = schéma de pensée + principes + heuristiques décisionnelles + tokens.
> Format : **jamais un résumé**, toujours des équations pondérées.

---

## Structure

```
MaterialDesign/Styles/
├── Color/
│   ├── color-system.md        → Système HCT, rôles, palettes tonales
│   ├── color-roles.md         → 26 rôles, groupes, appariements
│   ├── color-schemes.md       → Statique vs Dynamique, choix de schéma
│   └── color-advanced.md      → Couleurs fixes, personnalisation, fidelité
├── Elevation/
│   └── elevation.md           → Niveaux 0–5, overlay tonal, ombres
├── Icons/
│   └── icons.md               → Material Symbols, axes variables, application
├── Motion/
│   ├── motion-physics.md      → Système de physique, principes fondamentaux
│   ├── motion-easing.md       → Courbes d'easing, durées, tokens
│   └── motion-transitions.md  → Patterns de transition, règles d'application
├── Shape/
│   └── shape.md               → Échelle de coins, morphing, bibliothèque
├── Spacing/
│   └── spacing.md             → Unité 4dp, tokens, application
└── Typography/
    ├── typography-system.md   → Type scale 15 styles, hiérarchie
    ├── typography-type-scale.md → Tokens, valeurs, rôles
    ├── typography-applying.md → Règles d'application, appariements
    └── typography-editorial.md → Traitements éditoriaux, axes variables
```

---

## Index par question de décision

| Question | Fichier |
|----------|---------|
| Quelle couleur pour cette action/surface/texte ? | `Color/color-roles.md` |
| Statique ou dynamique ? Baseline ou custom ? | `Color/color-schemes.md` |
| Comment fonctionne le système HCT ? | `Color/color-system.md` |
| Couleurs fixes, harmonisées, custom roles ? | `Color/color-advanced.md` |
| Quelle élévation pour ce composant ? | `Elevation/elevation.md` |
| Tonal overlay ou ombre ? | `Elevation/elevation.md` |
| Quelle icône, quelle taille, quel style ? | `Icons/icons.md` |
| Motion fluide ou réduit ? Quel easing ? | `Motion/motion-easing.md` |
| Quelle transition entre ces deux écrans ? | `Motion/motion-transitions.md` |
| Quel rayon de coin pour ce composant ? | `Shape/shape.md` |
| Morphing de forme animé : quand ? | `Shape/shape.md` |
| Espacement entre ces éléments ? | `Spacing/spacing.md` |
| Quel style typographique pour ce texte ? | `Typography/typography-system.md` |
| Quelle typo pour quel écran/contexte ? | `Typography/typography-applying.md` |
| Traitement éditorial : quand et comment ? | `Typography/typography-editorial.md` |

---

## Référentiel tokens systèmes (rappel rapide)

### md-sys-color (rôles essentiels)
| Rôle | Usage |
|------|-------|
| `primary` | Action principale |
| `on-primary` | Texte/icône sur `primary` |
| `primary-container` | Surface d'action tonal |
| `secondary-container` | Indicateurs de sélection |
| `surface` | Fond de base |
| `surface-container` | Nav, menus |
| `surface-container-high` | Dialogs |
| `on-surface` | Texte principal |
| `on-surface-variant` | Texte secondaire |
| `outline` | Bordures |
| `inverse-surface` | Snackbar, tooltips |

### md-sys-elevation
| Level | Valeur |
|-------|--------|
| `level0` | 0dp |
| `level1` | 1dp |
| `level2` | 3dp |
| `level3` | 6dp |
| `level4` | 8dp |
| `level5` | 12dp |

### md-sys-shape
| Token | Valeur |
|-------|--------|
| `corner-none` | 0px |
| `corner-extra-small` | 4px |
| `corner-small` | 8px |
| `corner-medium` | 12px |
| `corner-large` | 16px |
| `corner-large-increased` | 20px |
| `corner-extra-large` | 28px |
| `corner-extra-large-increased` | 32px |
| `corner-extra-extra-large` | 48px |
| `corner-full` | 9999px |

### md-sys-typescale (styles)
Display L/M/S · Headline L/M/S · Title L/M/S · Body L/M/S · Label L/M/S

### md-sys-spacing (base 4dp)
`spacing-0`=0 · `spacing-50`=2px · `spacing-100`=4px · `spacing-200`=8px · `spacing-300`=12px · `spacing-400`=16px · `spacing-500`=20px · `spacing-600`=24px · `spacing-700`=28px · `spacing-800`=32px · `spacing-900`=36px · `spacing-1000`=40px
