# Routage Styles — Question → Fichier de documentation

> Tableau de décision rapide : quelle section Styles pour quel besoin ?
> Une fois la section identifiée, ouvrir le fichier pour les heuristiques détaillées.

---

## Par domaine de décision stylistique

### Couleur
| Question | Fichier |
|----------|---------|
| Comment fonctionne le système de couleur M3 ? Qu'est-ce que HCT ? | `Color/color-system.md` |
| Quel rôle couleur pour cet élément (fond, texte, action) ? | `Color/color-roles.md` |
| Quels rôles existent ? Comment les appariements fonctionnent ? | `Color/color-roles.md` |
| Baseline statique ou dynamic color ? | `Color/color-schemes.md` |
| Comment configurer le scheme de mon app ? | `Color/color-schemes.md` |
| Ma couleur de marque dans un context dynamique ? | `Color/color-advanced.md` |
| Créer un custom color role ? Couleur fixe ? Harmonisation ? | `Color/color-advanced.md` |

### Élévation
| Question | Fichier |
|----------|---------|
| Quelle élévation pour ce composant ? | `Elevation/elevation.md` |
| Tonal overlay ou ombre ? Différence M2/M3 ? | `Elevation/elevation.md` |
| Comment l'élévation change selon l'état (hover, pressed) ? | `Elevation/elevation.md` |
| Tokens d'élévation, valeurs en dp ? | `Elevation/elevation.md` |

### Icônes
| Question | Fichier |
|----------|---------|
| Quel style d'icône (Outlined/Rounded/Sharp) ? | `Icons/icons.md` |
| Quelle taille d'icône pour ce contexte ? | `Icons/icons.md` |
| Axes variables : Fill, Weight, Grade, Optical Size ? | `Icons/icons.md` |
| Comment communiquer l'état sélectionné/actif ? | `Icons/icons.md` |
| Icône avec ou sans label ? | `Icons/icons.md` |

### Motion
| Question | Fichier |
|----------|---------|
| Cette animation est-elle justifiée ? | `Motion/motion-physics.md` |
| Quels principes gouvernent le motion M3 ? | `Motion/motion-physics.md` |
| Quel easing pour cette animation ? | `Motion/motion-easing.md` |
| Quelle durée pour cette transition ? | `Motion/motion-easing.md` |
| Tokens d'easing et de durée ? | `Motion/motion-easing.md` |
| Quelle transition entre ces deux vues ? | `Motion/motion-transitions.md` |
| Container Transform, Shared Axis, Fade Through, Fade ? | `Motion/motion-transitions.md` |
| Règles anti-patterns : jump cuts, cross-fades ? | `Motion/motion-transitions.md` |

### Forme (Shape)
| Question | Fichier |
|----------|---------|
| Quel rayon de coin pour ce composant ? | `Shape/shape.md` |
| Quelle valeur pour corner-extra-large, corner-full, etc. ? | `Shape/shape.md` |
| Coins asymétriques : quand et comment ? | `Shape/shape.md` |
| Shape morphing : quand l'utiliser ? | `Shape/shape.md` |
| Formes abstraites M3 Expressive : usage ? | `Shape/shape.md` |

### Espacement
| Question | Fichier |
|----------|---------|
| Quel espacement entre ces éléments ? | `Spacing/spacing.md` |
| Padding interne d'un composant ? | `Spacing/spacing.md` |
| Grille de layout : colonnes, gutters, margins ? | `Spacing/spacing.md` |
| Tokens d'espacement md-sys-spacing-* ? | `Spacing/spacing.md` |
| Zone de tap minimum ? | `Spacing/spacing.md` |

### Typographie
| Question | Fichier |
|----------|---------|
| Quel style typographique (Display/Headline/Title/Body/Label) ? | `Typography/typography-system.md` |
| Quelle police, quel weight par défaut ? | `Typography/typography-system.md` |
| Valeurs exactes de size, line-height, tracking, weight ? | `Typography/typography-type-scale.md` |
| Tokens typographiques md-sys-typescale-* ? | `Typography/typography-type-scale.md` |
| Comment construire la hiérarchie typographique d'une vue ? | `Typography/typography-applying.md` |
| Longueur de ligne, alignement, règles d'application ? | `Typography/typography-applying.md` |
| Typographie dans les composants M3 (boutons, dialogs, etc.) ? | `Typography/typography-applying.md` |
| Traitement éditorial : weight variable, axes expressifs ? | `Typography/typography-editorial.md` |
| Variable fonts : axes wght, GRAD, wdth, opsz ? | `Typography/typography-editorial.md` |

---

## Arbitrages courants (questions fréquentes Styles)

| Question | Réponse |
|----------|---------|
| Tonal overlay ou ombre pour indiquer l'élévation ? | Tonal overlay (toujours) + ombre (si protection sur fond complexe nécessaire) |
| dynamic color ou static baseline ? | Dynamic si Android 12+, grand public. Static si iOS, enterprise, brand stricte. |
| `on-surface` vs `on-surface-variant` ? | `on-surface` pour texte principal. `on-surface-variant` pour texte secondaire/inactif. |
| `corner-full` ou `corner-extra-large` pour les boutons ? | `corner-full` — c'est le token M3 officiel pour tous les boutons. |
| Easing Standard ou Emphasized pour une transition de navigation ? | Emphasized (entrée : Decelerate, sortie : Accelerate) pour toute transition de navigation principale. |
| Fade Through ou Shared Axis pour les tabs de bottom nav ? | Fade Through si tabs sans ordre spatial. Shared Axis X si les tabs ont un ordre logique gauche/droite. |
| Weight 400 ou 500 pour les labels ? | 500 (Medium) — tous les `label-*` sont Medium dans le type scale M3. |
| `body-large` ou `body-medium` pour du texte courant ? | `body-large` pour des articles/textes longs. `body-medium` pour des descriptions brèves dans des composants. |
| Espacement 12dp ou 16dp pour le padding horizontal ? | 16dp (spacing-400) est le standard. 12dp (spacing-300) uniquement pour les composants compacts/dense. |
| Shape morph ou changement de couleur pour un état actif ? | Les deux ensemble — shape morph + couleur `secondary-container` pour l'indicateur actif de navigation. |
| Material Symbols ou Material Icons ? | Material Symbols uniquement — Material Icons est déprécié en M3. |
