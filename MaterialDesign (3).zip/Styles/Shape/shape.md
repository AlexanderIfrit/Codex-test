---
source: >
  https://m3.material.io/styles/shape/overview-principles
  https://m3.material.io/styles/shape/corner-radius-scale
  https://m3.material.io/styles/shape/shape-morph
category: Styles / Shape
spec-version: v0.192 + M3 Expressive (mai 2025)
---

# Shape — Heuristiques de décision

Périmètre : échelle de coins (15 variants) · 35 formes abstraites · shape morphing · harmonie typo-forme · 2.5D

---

## Schéma de pensée

La forme en M3 n'est pas seulement esthétique — elle communique l'identité de la marque, la hiérarchie des éléments et les états interactifs. L'échelle de coins (0 → 9999px) est le levier principal : les coins arrondis suggèrent l'amicalité et l'accessibilité, les coins droits suggèrent la structure et la précision. M3 Expressive va plus loin avec deux dimensions supplémentaires : (1) le **shape morphing** — la forme change de façon animée pour connecter la fonction et le ressenti, (2) la **bibliothèque de 35 formes abstraites** — pour des moments expressifs en dehors des conteneurs rectangulaires.

Point clé issu de la spec M3 : **shape is versatile, not semantic** — la forme n'a pas de signification sémantique fixe. `corner-full` ne signifie pas "bouton" ; `corner-medium` ne signifie pas "carte". Les formes communiquent le caractère et la hiérarchie, pas une catégorie fonctionnelle.

---

## Principes

1. **Forme ≠ sémantique, forme = caractère** : la forme exprime le ton du produit (doux/angulaire, expressif/fonctionnel) — elle n'encode pas une catégorie.
2. **Formes et typographie en harmonie** : les formes abstraites et les arrondis doivent écho aux attributs visuels de la typographie choisie (ex: Google Sans Flex et ses terminaisons arrondies appellent `corner-full` et `corner-extra-large`).
3. **Morphing = connexion fonction-ressenti** : le shape morph communique les états interactifs et les actions en cours — il ne décore pas.
4. **Formes abstraites = moments rares et décisifs** : 1-2 maximum par vue ; réservées aux surfaces expressives, pas aux composants fonctionnels.
5. **Formes 2.5D** : combinées avec le motion, les formes créent l'illusion de profondeur — technique avancée pour des moments visuellement marquants.
6. **Oser la tension** : M3 Expressive encourage l'utilisation de contrastes de forme délibérés (formes angulaires à côté d'arrondis extrêmes) — la tension visuelle crée de l'intérêt sans nuire à la lisibilité.

---

## Tokens de design — échelle complète (15 variants)

| Token | Valeur | Alias nommé M3 | Exemples de composants |
|-------|--------|----------------|------------------------|
| `corner-none` | 0px | No rounding | Divider, items de liste, tableaux |
| `corner-extra-small` | 4px | Extra small rounding | Snackbar, tooltip, badge |
| `corner-extra-small-top` | 4px (top only) | Extra small top rounding | — |
| `corner-small` | 8px | Small rounding | Chip (input/filter), text field, menus |
| `corner-medium` | 12px | Medium rounding | Cards (elevated/outlined/filled) |
| `corner-large` | 16px | Large rounding | — |
| `corner-large-start` | 16px (start) | Large start rounding | Asymétrie ancrée à gauche |
| `corner-large-end` | 16px (end) | Large end rounding | Asymétrie ancrée à droite |
| `corner-large-top` | 16px (top only) | Large top rounding | Bottom sheets |
| `corner-large-increased` ✨ | 20px | Large increased rounding | M3 Expressive |
| `corner-extra-large` | 28px | Extra large rounding | Dialog, date picker |
| `corner-extra-large-top` | 28px (top only) | Extra large top rounding | Grandes bottom sheets |
| `corner-extra-large-increased` ✨ | 32px | Extra large increased rounding | M3 Expressive |
| `corner-extra-extra-large` ✨ | 48px | Extra extra large rounding | M3 Expressive |
| `corner-full` | 9999px | Fully rounded | Buttons (all), FAB, chips assist/suggestion, search bar |

✨ = Nouveau M3 Expressive (mai 2025)

> **Note migration** : `corner-full` était précédemment défini en utilisant 50% de la taille du composant. Depuis M3 Expressive, il utilise le token `full` (9999px) — vérifier les implémentations qui utilisaient l'ancienne valeur dynamique.

---

### Shape par composant (référence rapide)

| Composant | Token de forme |
|-----------|---------------|
| Buttons (all) | `corner-full` |
| FAB | `corner-large` → `corner-full` (M3 Expressive) |
| Extended FAB | `corner-large` → `corner-full` (M3 Expressive) |
| Button Group | `corner-full` (avec shape morph sur press) |
| Cards | `corner-medium` |
| Chips (input/filter) | `corner-small` |
| Chips (assist/suggestion) | `corner-full` |
| Dialog | `corner-extra-large` |
| Bottom Sheet (standard) | `corner-large-top` |
| Bottom Sheet (grande) | `corner-extra-large-top` |
| Navigation Bar — indicateur actif | `corner-full` |
| Navigation Bar — conteneur | Transparent / `surface` (pas de shape propre) |
| Navigation Drawer modal — conteneur | `corner-large-end` (arrondi côté ouverture) |
| Navigation Drawer permanent — conteneur | `corner-none` |
| Navigation Drawer — item actif (indicateur) | `corner-full` |
| Text Field (Outlined) | Conteneur : `corner-extra-small` (4 coins) |
| Text Field (Filled) | Conteneur : `corner-extra-small-top` (top only, fond plat en bas) |
| Snackbar | `corner-extra-small` |
| Tooltip | `corner-extra-small` |
| Search Bar | `corner-full` |
| Loading Indicator | Forme abstraite + shape morph |
| Menus | `corner-extra-small` (bords) + `corner-small` (items sélectionnés) |

---

## Heuristiques

**H1 — Choisir l'arrondi selon le caractère du produit**

Cohérence du caractère ∝ Alignement entre rayon de coin et ton de marque [poids: fort] + Cohérence des arrondis inter-composants [poids: fort] − Dissonance de niveau dans un même écran [poids: modéré]

| Rayon | Signal émotionnel | Convient à |
|-------|------------------|-----------|
| `corner-none` (0px) | Structure pure, rigueur | Tableaux de données, interfaces très denses, outils pro |
| `corner-extra-small` (4px) | Fonctionnel, sobre | Toasts, labels courts, interfaces compactes |
| `corner-small` (8px) | Neutre, pratique | Chips, menus, text fields |
| `corner-medium` (12px) | Équilibré, standard | Cards, composants de contenu |
| `corner-large–extra-large` (16–28px) | Ouvert, accueillant | Dialogs, surfaces importantes |
| `corner-extra-large–full` (28–9999px) | Fluide, expressif, amical | Boutons, FABs, apps grand public |

- La cohérence de l'échelle dans tout le produit est plus importante que le choix exact d'un niveau.
- Un produit avec `corner-full` partout a un caractère "doux" marqué — vérifier l'alignement avec l'identité de marque.

**Zone de bascule :** Une app enterprise avec des tableaux de données denses → arrondis faibles (`extra-small` à `medium`). Les grands arrondis occupent de l'espace visuel et créent visuellement trop de "bulle" dans des layouts d'information dense. Une app grand public / social → arrondis larges.

**Raison généralisable :** La forme est versatile, pas sémantique — le même token peut servir dans des contextes très différents. Ce n'est pas le token qui définit le composant, c'est le système cohérent de tokens à travers le produit qui définit son caractère.

---

**H2 — Harmonie forme + typographie**

Cohésion visuelle du produit ∝ Alignement entre terminaisons de forme et attributs visuels de la typo [poids: fort] + Cohérence de style (angulaire vs arrondi) [poids: modéré] − Dissonance typo/forme [poids: modéré]

| Style typographique | Formes compatibles |
|--------------------|-------------------|
| Typo avec terminaisons arrondies (Google Sans, Nunito, Poppins) | `corner-large` → `corner-full`, formes abstraites arrondies |
| Typo géométrique avec terminaisons droites (Futura, DM Sans) | `corner-medium` → `corner-extra-large`, modéré |
| Typo serif (Playfair, Lora) | `corner-none` → `corner-small` → dissonance forte avec `corner-full` |
| Typo monospace (code, données) | `corner-none` → `corner-extra-small` |

- Google Sans Flex (typo M3 par défaut) et ses terminaisons arrondies appellent naturellement `corner-full` et `corner-extra-large`.
- Vérifier que le "style de terminaison" de la police (arrondi/droit/pointu) est cohérent avec le niveau de l'échelle de coins choisi.

**Zone de bascule :** Produit utilisant une typo brand très singulière (ex: typo angulaire avec `corner-full`) — le contraste intentionnel peut être un choix artistique assumé. Sans intention claire, c'est incohérent.

**Raison généralisable :** L'œil perçoit globalement avant de lire — une typo ronde avec des composants angulaires crée une tension visuelle non intentionnelle qui se traduit par un sentiment de "quelque chose cloche" chez l'utilisateur sans qu'il puisse l'identifier.

---

**H3 — Coins asymétriques : quand et comment**

Pertinence de l'asymétrie ∝ Ancrage directionnel de l'élément [poids: fort] + Signal spatial communiqué [poids: modéré] − Complexité visuelle gratuite [poids: fort, négatif]

| Pattern asymétrique | Token | Usage |
|--------------------|-------|-------|
| Top arrondi seulement | `corner-large-top` / `corner-extra-large-top` | Bottom sheets ancrées en bas |
| Start arrondi seulement | `corner-large-start` | Éléments ancrés à gauche (liste sélectionnée côté gauche) |
| End arrondi seulement | `corner-large-end` | Éléments ancrés à droite |
| Top-right + bottom-right élevé, left = 0 | Custom | Bulle de chat (ancrée à gauche) |

- Les coins asymétriques communiquent un ancrage directionnel — ils "pointent" vers leur origine ou leur surface parente.
- Ne pas créer d'asymétrie arbitraire sans raison spatiale.

**Zone de bascule :** Les bulles de chat avec coins asymétriques sont une convention bien établie. Sur d'autres composants, l'asymétrie doit être justifiée par une relation spatiale claire — sinon, utiliser des coins symétriques.

**Raison généralisable :** Les coins asymétriques créent une "flèche" visuelle implicite — l'œil suit la direction indiquée. Si cette flèche ne pointe vers rien de significatif, elle crée de la confusion directionnelle.

---

**H4 — Shape morphing : quand animer la forme**

Pertinence du morph ∝ Changement d'état communicatif [poids: fort] + Continuité visuelle entre état source et cible [poids: fort] − Fréquence trop élevée d'apparition [poids: fort, négatif] − Usage sur Web (non disponible) [poids: bloquant]

| Cas d'usage du morphing | Signal communiqué |
|------------------------|------------------|
| Bouton sélectionné dans un Button Group | Changement d'état interactif (press → selected) |
| Loading Indicator | Progression en cours |
| FAB qui se développe en Extended FAB | Expansion d'action |
| Composant de chargement (pulsing shape) | Action en cours |
| Feedback d'un geste utilisateur | Connexion directe geste/forme |
| Indicateur de son/musique | Réponse à l'environnement en temps réel |

**Disponibilité technique :**
- ✅ **Android Compose** : API `MaterialShapes` (`androidx.compose.material3.MaterialShapes`)
- ✅ **Android Views (MDC-Android)** : via la Shape Library
- ❌ **Web** : non disponible en 2025 (pas d'équivalent CSS natif)
- **Motion scheme** : utilise le schéma **Expressive** par défaut — peut être switché vers le schéma Standard si besoin.

**Composants M3 qui utilisent le shape morph nativement :**
- `Standard Button Group` — morph au press pour montrer l'interaction entre boutons adjacents
- `Loading Indicator` — morph pour montrer la progression

- Limiter le morphing aux composants interactifs ou aux états significatifs — le morphing décoratif en boucle crée de la fatigue visuelle.
- Respecter `prefers-reduced-motion` : supprimer ou réduire le morph à un simple changement de couleur.

**Zone de bascule :** Un indicateur de navigation active qui morph à chaque tap devient distrayant si l'utilisateur navigue vite. S'assurer que la durée du morph est plus courte que la fréquence d'usage probable.

**Raison généralisable :** Le shape morphing tire son impact de la rareté. Un morph à chaque interaction devient du bruit en moins de 10 occurrences. Réserver aux changements d'état qui méritent d'être remarqués.

---

**H5 — Formes abstraites M3 (Shape Library) : 35 formes, usage expressif**

Pertinence forme abstraite ∝ Moment expressif clairement défini [poids: fort] + Rareté dans l'écran [poids: fort] − Usage fonctionnel du composant [poids: très fort, négatif]

**Cas d'usage des 35 formes M3 :**

| Contexte | Usage pertinent |
|----------|----------------|
| Onboarding / écrans d'accueil | Illustration de concept, background expressif |
| Célébration / achievement | Forme abstraite animée pour marquer le moment |
| Avatars et masques | Découpe d'image en forme (avatar non-circulaire) |
| Recadrage de photographies | Masque créatif pour du contenu éditorial |
| Empty states | Illustration en forme abstraite |
| Hero d'écrans marketing | Background, conteneur d'image |

**Règles d'usage :**
- 1-2 formes abstraites par vue maximum — au-delà, l'interface perd sa lisibilité.
- Jamais sur des composants fonctionnels (boutons, champs de saisie, listes) — uniquement sur des surfaces expressives ou décoratives.
- Les formes abstraites peuvent coexister avec des composants rectangulaires arrondis — elles créent le contraste expressif voulu.
- Associer forme + typographie de façon cohérente (harmonie des terminaisons visuelles).

**Zone de bascule :** Dans une app de productivité ou enterprise → formes abstraites hors-contexte. Dans une app grand public avec des moments de célébration → pertinentes et bienvenues.

**Raison généralisable :** Une forme abstraite dans un contexte fonctionnel dense détourne l'attention de l'action principale — elle est perçue comme une distraction plutôt qu'une aide.

---

**H6 — Oser la tension visuelle et le 2.5D**

Impact visuel ∝ Contraste intentionnel entre niveaux de forme [poids: modéré] + Cohérence avec le ton du produit [poids: fort] − Tension non intentionnelle (incohérence) [poids: fort, négatif]

- M3 Expressive encourage d'oser le contraste entre formes angulaires et arrondis extrêmes dans un même écran — la tension visuelle crée de l'intérêt.
- **2.5D** : combiner forme + motion (couches animées avec des offsets différents) pour créer l'illusion de profondeur et de volume dans des interfaces 2D. Technique réservée aux moments visuellement forts (hero screens, onboarding, landing pages).
- La différence entre tension intentionnelle (art direction assumée) et incohérence (manque de décision) réside dans la systématisation — si le contraste est appliqué partout de façon cohérente, c'est un parti-pris. Si c'est ponctuel et aléatoire, c'est une incohérence.

**Zone de bascule :** Apps utilitaires / entreprise → éviter la tension visuelle de forme ; la cohérence de l'échelle prime sur l'intérêt expressif. Apps grand public / médias / créatives → la tension assumée (ex: `corner-none` pour les images + `corner-full` pour les boutons dans le même écran) est bienvenue. Pour le 2.5D, réserver aux surfaces sans interaction directe (heroes, splashs, onboardings) — sur des éléments interactifs, la profondeur simulée crée de l'ambiguïté affordance.

**Raison généralisable :** L'uniformité visuelle réduit l'intérêt perceptif — un écran où tous les éléments ont le même niveau de forme est plat et monotone. La hiérarchie de forme (contraste délibéré entre composants) crée du rythme visuel.

---

## Règles Do / Don't

✅ **Do :** Définir un "shape scale" du produit (conservateur = extra-small à medium, expressif = medium à full) et l'appliquer via tokens.
✅ **Do :** Harmoniser le niveau d'arrondi avec le style de terminaison de la typographie.
✅ **Do :** Réserver le shape morph aux changements d'état significatifs (states, progression, interaction).
✅ **Do :** Utiliser `corner-full` pour tous les boutons M3 — c'est le token officiel.
✅ **Do :** Vérifier la disponibilité du shape morph selon la plateforme (Compose ✅ / Web ❌).
✅ **Do :** Appliquer `prefers-reduced-motion` pour désactiver les morphings.
✅ **Do :** Utiliser les formes abstraites pour la photographie, les avatars, les empty states.
❌ **Don't :** Traiter la forme comme sémantique — `corner-full` ne signifie pas "bouton".
❌ **Don't :** Utiliser des formes abstraites sur des composants fonctionnels (champs, boutons, listes).
❌ **Don't :** Morphing en boucle sans interaction utilisateur — fatigue visuelle assurée.
❌ **Don't :** Créer des coins asymétriques sans relation spatiale justifiée.
❌ **Don't :** Utiliser le shape morph sur Web (non disponible).
❌ **Don't :** Mélanger un style typo arrondi avec des coins angulaires sans intention assumée.

---

## Traduction en application concrète

- **Design tokens** : définir le shape scale du produit dans Figma Tokens avant de commencer les maquettes — appliquer via variables ou tokens, jamais en valeurs fixées manuellement sur les composants.
- **Figma** : Material Shape Library (Figma Design Kit) donne accès aux 35 formes + au prototypage du shape morph.
- **Compose** : `MaterialShapes` fournit toutes les formes M3 avec morphing intégré via `Morph`. Motion scheme : `MotionScheme.Expressive` par défaut, changeable en `MotionScheme.Standard`.
- **Android Views** : Shape Library via MDC-Android, voir `ShapeAppearance` pour les tokens.
- **Web** : shape morph non disponible — utiliser des transitions CSS `border-radius` comme fallback (pas de morph inter-formes).
- **Cohérence marque** : si la police est à terminaisons arrondies, préférer `corner-full` et `corner-extra-large` pour les composants principaux.
- **Avatars & médias** : utiliser les formes abstraites comme masques CSS/clip-path pour créer des recadrages créatifs non-circulaires.

---

## Ressources

| Type | Ressource | Statut |
|------|----------|--------|
| Design | Shape Library — Figma Design Kit | Disponible |
| Compose | `androidx.compose.material3.MaterialShapes` | Disponible |
| Android Views | MDC-Android — Shape docs (GitHub) | Disponible |
| Web | Shape morph | ❌ Non disponible |
