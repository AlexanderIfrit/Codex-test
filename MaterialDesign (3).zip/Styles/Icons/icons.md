---
source: https://m3.material.io/styles/icons/overview + designing-icons + applying-icons
category: Styles / Icons
spec-version: v0.192
---

# Icons — Heuristiques de décision

Système : Material Symbols (variable fonts) · 3 styles · 5 axes variables
Tailles : 20, 24 (défaut), 40, 48dp · Grille 24×24dp

---

## Schéma de pensée

Material Symbols est un système d'icônes à fonts variables : une seule icône s'adapte à son contexte en ajustant ses axes (poids, remplissage, grade, taille optique). L'erreur la plus commune est de traiter les icônes comme des images figées — en réalité chaque axe communicue quelque chose : Fill = état sélectionné, Weight = emphase, Grade = réponse au contraste, Optical Size = fidélité à la taille d'affichage. Comprendre les axes permet de concevoir des icônes qui répondent au contexte sans créer des variantes supplémentaires.

---

## Principes

- **Material Symbols remplace Material Icons** — ne pas mélanger les deux dans le même produit.
- Les 3 styles (Outlined, Rounded, Sharp) définissent la terminaison des traits — choisir un style unique et rester cohérent dans tout le produit.
- Les 5 axes variables (Fill, Weight, Grade, Optical Size + opsz automatique) permettent d'adapter chaque icône sans créer de nouvelle ressource.
- La grille de design est 24×24dp — tout artwork d'icône s'inscrit dans une zone de protection de 20×20dp (2dp de marge sur chaque côté).
- Toujours accompagner une icône d'un label accessible quand le contexte ne rend pas l'action évidente.

---

## Tokens de design — axes variables

### Axes Material Symbols
| Axe | Plage | Défaut | Rôle |
|-----|-------|--------|------|
| `Fill` (FILL) | 0–1 | 0 | 0 = outlined, 1 = filled (état sélectionné) |
| `Weight` (wght) | 100–700 | 400 | Épaisseur du trait — cohérence avec la typographie |
| `Grade` (GRAD) | -25 à 200 | 0 | Ajustement optique fin (contraste, fond sombre) |
| `Optical Size` (opsz) | 20–48 | 24 | Correspond à la taille d'affichage en dp |

### Tailles standards et opsz correspondant
| Taille | opsz recommandé | Usage |
|--------|----------------|-------|
| 20dp | 20 | Interfaces denses, labels, boutons text |
| 24dp | 24 | **Standard** — navigation, actions, app bar |
| 40dp | 40 | Moments visuels, illustrations, vides |
| 48dp | 48 | Hero moments, onboarding, grandes surfaces |

### Presets d'axes par contexte
| Contexte | Fill | Weight | Grade | Optical Size |
|----------|------|--------|-------|-------------|
| Navigation inactive | 0 | 400 | 0 | 24 |
| Navigation active | 1 | 400 | 0 | 24 |
| App bar icon | 0 | 400 | 0 | 24 |
| Dense toolbar | 0 | 300 | 0 | 20 |
| Hero/empty state | 0–1 | 400–600 | 0 | 40–48 |
| Dark background | 0 | 400 | 200 | 24 |
| High emphasis | 0 | 600 | 0 | 24 |

---

## H1 — Choisir le style (Outlined / Rounded / Sharp)

**Équation :** Cohérence du style ∝ Cohérence avec la typographie et la forme des composants (fort) + Unicité du style dans le produit (fort) − Mélange de styles (fort)

| Style | Caractère | Convient à |
|-------|-----------|-----------|
| **Outlined** | Neutre, professionnel | Productivité, enterprise, apps neutres |
| **Rounded** | Amical, doux | Consumer apps, éducation, santé |
| **Sharp** | Moderne, éditorial | Médias, actualités, apps techniques |

- Un seul style pour tout le produit — ne pas alterner Outlined et Rounded dans la même app
- Choisir le style en cohérence avec les `corner-radius` des composants : `corner-full` → Rounded Icons, `corner-none`/`corner-extra-small` → Sharp Icons

**Zone de bascule :** Si les composants ont des coins mixed (certains full, certains medium), choisir le style dominant de la marque ou l'Outlined (valeur neutre par défaut).

**Raison généralisable :** L'œil perçoit la cohérence entre la terminaison des traits d'icônes et les coins des composants. Une app avec `corner-full` partout mais des icônes Sharp crée un signal de dissonance visuelle.

---

## H2 — Utiliser Fill=1 pour communiquer l'état sélectionné

**Équation :** Clarté de l'état ∝ Différence Fill (fort) + Couleur (fort) + Position active marker (faible si Fill présent)

- `Fill=0` → état inactif, non-sélectionné, default
- `Fill=1` → état actif, sélectionné, activé
- **Navigation bar** : icône inactive = Fill 0, icône active = Fill 1 + `secondary-container` indicator
- **Favoris, bookmarks** : vide = Fill 0, rempli = Fill 1 — l'axe remplace la variante d'icône

Ne pas inverser la convention : Fill=1 sur une icône inactive crée une confusion sur l'état.

**Zone de bascule :** Sur des icônes très complexes (pictogrammes détaillés), Fill=1 peut rendre l'icône trop lourde visuellement. Dans ce cas, utiliser un changement de couleur seul (`primary` vs `on-surface-variant`) plutôt que le fill.

**Raison généralisable :** Fill simule la distinction "outline vs filled" qui est le signal universel d'état sélectionné dans tous les systèmes de design (checkboxes, toggles, stars). Le reprendre pour les icônes navigue la même convention intuitive.

---

## H3 — Taille et optical size : toujours les synchroniser

**Équation :** Fidélité visuelle ∝ Correspondance taille affichée / opsz (fort) − Désynchronisation opsz/taille (modéré)

- Afficher une icône à 24dp avec opsz=48 → traits trop fins, détails trop nombreux, illisible à petite taille
- Afficher une icône à 48dp avec opsz=24 → traits trop épais, icône massive et lourde

**Zone de bascule :** Quand la taille d'affichage est variable (responsive), fixer l'opsz sur la taille la plus fréquente ou utiliser `opsz: auto` quand la plateforme le supporte.

---

## H4 — Grade : répondre au contraste et au contexte

**Équation :** Lisibilité de l'icône ∝ Grade adapté au fond (fort) + Cohérence avec l'emphase typographique (modéré)

| Contexte | Grade recommandé |
|----------|-----------------|
| Fond clair, contenu standard | 0 |
| Fond sombre, dark mode | +200 (compense l'amincissement perçu sur fond sombre) |
| Icône à faible emphase | -25 (allège visuellement) |
| Icône à haute emphase | +200 (renforce sans changer le weight) |

- Grade n'est pas identique à Weight : Grade ajuste finement sans changer la structure de l'icône, Weight change son épaisseur structurelle
- Sur dark mode systématique, passer toutes les icônes à Grade=200 par défaut

**Zone de bascule :** Grade=200 sur des icônes déjà en Weight=700 peut sembler excessif — l'icône paraît "brûlée". Dans ce cas, rester à Grade=0 et se fier au Weight seul.

---

## H5 — Avec ou sans label : règle d'accompagnement

**Équation :** Compréhension de l'action ∝ Label présent (fort) + Universalité de l'icône (modéré) − Contexte explicite suffisant (faible)

- **Toujours** accompagner d'un label visible quand l'icône n'est pas universellement reconnue (home, back, close sont des exceptions)
- **Navigation bar M3** : label obligatoire sous l'icône — 3–5 destinations avec label et icône
- **App bar** : icône seule acceptable pour des actions secondaires (overflow menu, search, share)
- **Floating action button** : icône seule si l'action est contextuelle et évidente ; Extended FAB avec label si besoin de clarté

**Zone de bascule :** Sur mobile, la zone de tap est 48×48dp minimum — une icône de 24dp dans une zone de 48dp est correcte. Ne jamais forcer une icône de 48dp dans une zone de 48dp (pas de marge de tap).

---

## Traduction en application concrète

- **Implémentation** : utiliser `font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24` comme valeur CSS de base, modifier les axes par état.
- **Design Figma** : utiliser le plugin Material Symbols pour accéder aux axes variables directement dans Figma.
- **Accessibilité** : toujours fournir un `aria-label` ou un label visible — les icônes seules ne sont pas accessibles aux lecteurs d'écran.
- **Un seul style** : définir le style (Outlined/Rounded/Sharp) dans le design system en premier, ne jamais le changer composant par composant.
