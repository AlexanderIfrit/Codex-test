---
source: https://m3.material.io/styles/elevation/overview + applying-elevation + tokens
category: Styles / Elevation
spec-version: v0.192
---

# Elevation — Heuristiques de décision

6 niveaux (level0–5) · Distance en dp sur l'axe z · Exprimé par overlay tonal ou ombre
Différence M2→M3 : overlay de couleur primaire remplace les ombres systématiques

---

## Schéma de pensée

L'élévation M3 est une métaphore spatiale : les composants flottent à des hauteurs différentes au-dessus de la surface de la page. Cette hauteur est communiquée visuellement en deux modes — un overlay de couleur primaire sur la surface (recommandé, adaptatif), ou une ombre projetée (complémentaire, contextuelle). Le changement radical par rapport à M2 : les ombres ne sont plus le signal primaire d'élévation. La couleur de surface est.

---

## Principes

- Tout composant M3 a une élévation de repos (`resting elevation`) — ne pas la modifier sauf raison explicite.
- L'élévation s'exprime en density-independent pixels (dp) sur l'axe z.
- Le tonal overlay applique une couche de `primary` à opacité variable sur la surface — plus l'élévation est haute, plus l'opacité est forte, plus la surface est colorée.
- Les ombres sont optionnelles en M3 et servent à créer une séparation visuelle supplémentaire, pas à signaler l'élévation.
- L'élévation change en réponse aux événements : hover, pressed, dragged, disabled.

---

## Tokens de design — niveaux d'élévation

| Token | Valeur dp | Overlay opacity (light) | Usage typique |
|-------|----------|------------------------|---------------|
| `md-sys-elevation.level0` | 0dp | 0% | Surfaces de base, texte, fonds |
| `md-sys-elevation.level1` | 1dp | 5% | Cards, menus, drawers |
| `md-sys-elevation.level2` | 3dp | 8% | FAB (resting), autocomplete |
| `md-sys-elevation.level3` | 6dp | 11% | Dialogs, modals |
| `md-sys-elevation.level4` | 8dp | 12% | Navigation drawer ouvert |
| `md-sys-elevation.level5` | 12dp | 14% | Bottom sheet, tooltips |

### Élévations par état (exemples)
| Composant | Resting | Hover | Pressed | Dragged |
|-----------|---------|-------|---------|---------|
| FAB | level3 | level4 | level3 | level4 |
| Card | level1 | level2 | level1 | level4 |
| Elevated Button | level1 | level2 | level1 | — |
| Dialog | level3 | — | — | — |
| Nav Drawer | level1 | — | — | — |

---

## H1 — Choisir entre tonal overlay et ombre

**Équation :** Signal d'élévation ∝ Tonal overlay (fort) + Ombre (faible/complémentaire) − Systématisation des ombres (modéré)

| Méthode | Quand l'utiliser |
|---------|-----------------|
| **Tonal overlay** (défaut) | Toujours — s'adapte au dark mode et dynamic color automatiquement |
| **Ombre seule** | Quand la surface ne peut pas changer de couleur (image, carte colorée) |
| **Tonal overlay + ombre** | FAB (protège contre n'importe quel fond), dialogs critiques |

- Le tonal overlay s'adapte automatiquement au dark mode et au dynamic color — ne pas le remplacer par une couleur fixe
- Les ombres M3 sont optionnelles et plus subtiles que M2 — ne pas reproduire l'ombre M2 "lourde" sur tous les éléments élevés
- Sur fond très clair, le tonal overlay peut être imperceptible sur level1 — ajouter une ombre subtile uniquement si la distinction est nécessaire fonctionnellement

**Zone de bascule :** Sur dark theme, le tonal overlay fait monter les surfaces vers des teintes de `primary` plus claires — certains designs dark mode semblent trop clairs visuellement. Si l'identité dark doit rester très sombre, réduire la saturation primaire ou utiliser un scheme adapté.

**Raison généralisable :** La couleur (tonal overlay) est perçue avant l'ombre — le cerveau lit d'abord la chrominance puis la luminance. C'est pourquoi M3 passe à l'overlay tonal : l'élévation est communiquée plus directement.

---

## H2 — Quand changer l'élévation (états interactifs)

**Équation :** Changement d'élévation justifié ∝ Interaction utilisateur directe (fort) + Événement système (modéré) − Décoration pure (fort)

| Déclencheur | Comportement d'élévation |
|-------------|------------------------|
| Hover | +1 niveau (ex : level1 → level2) |
| Pressed/Focus | Retour au niveau resting |
| Dragged | level4 (FAB, card) |
| Disabled | level0 — surface aplatie |
| Ouverture modal | level3+ — clairement au-dessus du fond |

- Les composants **non-interactifs** ne changent jamais d'élévation
- Ne pas inventer des animations d'élévation pour des éléments statiques — ça crée une fausse affordance d'interactivité
- Le `level4` (dragged) est visuellement fort — le réserver aux seuls cas de drag réel

**Zone de bascule :** Un FAB a une élévation de repos de level3 — beaucoup plus haute que les cards à level1. Sur un fond fortement coloré (dynamic color saturé), l'ombre du FAB peut sembler excessive. Ne pas réduire l'ombre du FAB — elle existe précisément pour le différencier de n'importe quel fond.

---

## H3 — Ne pas modifier l'élévation par défaut des composants M3

**Équation :** Cohérence système ∝ Respect des resting elevations (fort) − Ajustements locaux non documentés (fort)

- Chaque composant M3 a une élévation de repos calibrée par rapport aux autres composants de l'écosystème
- Modifier un composant (ex : passer les cards de level1 à level3) crée des conflits avec les composants qui s'y superposent (dialogs à level3)
- Si une élévation custom est nécessaire, documenter comme exception et vérifier la cohérence avec tous les composants qui se superposent à ce niveau

**Zone de bascule :** Sur web/desktop où les overlays modaux sont nombreux, l'échelle 0–5 peut sembler insuffisante. Dans ce cas, créer des niveaux custom documentés (level6+) en s'assurant que les ombres et overlays correspondants sont définis.

---

## Traduction en application concrète

- **Dark mode** : tester visuellement que le tonal overlay fonctionne bien (les surfaces level2+ ont une teinte visible de `primary`).
- **Custom component** : attribuer l'élévation la plus proche sémantiquement — un panneau latéral fixe = level1 (comme un drawer), un panneau flottant contextuel = level2-3.
- **Performance** : le tonal overlay est un simple CSS/paint override — pas d'impact perf. Les ombres multiples sur mobile peuvent dégrader le scroll — les réserver aux composants critiques (FAB, dialog).
