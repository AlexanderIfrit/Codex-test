---
source: https://m3.material.io/styles/color/roles
category: Styles / Color
spec-version: v0.192
---

# Color Roles — Heuristiques de décision

26 rôles standard nommés dans la spec · 6 groupes : primary, secondary, tertiary, error, surface, outline
Rôles supplémentaires (non comptés dans les 26) : fixed, fixed-dim, on-fixed, on-fixed-variant, inverse, scrim, shadow

---

## Schéma de pensée

Les rôles couleur sont le vocabulaire qui traduit l'intention UI en valeur de couleur. Ils fonctionnent en paires contraintes : `X` est le fond, `on-X` est ce qu'on pose dessus. Comprendre cette logique de paires est suffisant pour mapper correctement 90 % des cas — le reste se règle avec la logique de hiérarchie (primary > secondary > tertiary) et la logique de surface (plus le numéro de container est haut, plus la surface est proéminente).

---

## Principes

- Chaque rôle est préfixé par son groupe (primary, secondary, tertiary, error, surface, outline) pour signaler son niveau d'emphase relatif.
- `on-X` = texte et icônes **sur** la surface `X` — jamais pour un fond.
- `X-container` = surface de remplissage pour éléments foreground (boutons, chips) — ne pas utiliser pour du texte directement.
- `surface-variant` et `on-surface-variant` = alternative moins proéminente de `surface` / `on-surface`.
- Les rôles `fixed` et `fixed-dim` restent constants entre light et dark — usage : couleurs de marque, badges.

---

## Tokens — Référence complète des 26 rôles

### Groupe Primary (action principale)
| Rôle | Usage principal |
|------|----------------|
| `primary` | Composants d'action les plus proéminents (bouton filled, FAB) |
| `on-primary` | Texte/icône sur `primary` |
| `primary-container` | Surface d'action moins proéminente (bouton tonal) |
| `on-primary-container` | Texte/icône sur `primary-container` |

### Groupe Secondary (accents, filtres)
| Rôle | Usage principal |
|------|----------------|
| `secondary` | Composants moins proéminents que primary |
| `on-secondary` | Texte/icône sur `secondary` |
| `secondary-container` | Indicateurs de sélection (nav, chips, segmented) |
| `on-secondary-container` | Texte/icône sur `secondary-container` |

### Groupe Tertiary (accents différenciés)
| Rôle | Usage principal |
|------|----------------|
| `tertiary` | Accents de contraste par rapport au primary/secondary |
| `on-tertiary` | Texte/icône sur `tertiary` |
| `tertiary-container` | Surface d'accent tertiaire |
| `on-tertiary-container` | Texte/icône sur `tertiary-container` |

### Groupe Error (états d'erreur)
| Rôle | Usage principal |
|------|----------------|
| `error` | Indicateurs d'erreur critiques |
| `on-error` | Texte/icône sur `error` |
| `error-container` | Surface d'erreur (banner, field error) |
| `on-error-container` | Texte/icône sur `error-container` |

### Groupe Surface (fonds et conteneurs)
| Rôle | Usage principal |
|------|----------------|
| `surface` | Fond de base des composants |
| `surface-dim` | Surface assombrie (fond derrière modal) |
| `surface-bright` | Surface éclaircie |
| `surface-container-lowest` | Surface la moins proéminente |
| `surface-container-low` | Cartes, drawers |
| `surface-container` | Nav bar, menus, fond standard |
| `surface-container-high` | Dialogs, date pickers |
| `surface-container-highest` | Text fields filled, checkboxes inactifs |
| `on-surface` | Texte principal sur surfaces |
| `on-surface-variant` | Texte secondaire, icônes inactives |
| `inverse-surface` | Fond inversé (snackbar, tooltip) |
| `inverse-on-surface` | Texte sur `inverse-surface` |
| `inverse-primary` | Action sur fond inversé |

### Groupe Outline (bordures)
| Rôle | Usage principal |
|------|----------------|
| `outline` | Bordures fonctionnelles (text fields, cards outlined) |
| `outline-variant` | Bordures décoratives, dividers |

### Rôles spéciaux
| Rôle | Usage principal |
|------|----------------|
| `scrim` | Overlay modal semi-transparent (opacity 0.32) |
| `shadow` | Couleur d'ombre (noir en light et dark) |
| `primary-fixed` | Primary stable indépendant du thème |
| `primary-fixed-dim` | Variante assombrie de `primary-fixed` |
| `on-primary-fixed` | Texte sur `primary-fixed` |
| `on-primary-fixed-variant` | Texte variant sur `primary-fixed` |

---

## H1 — Choisir entre primary, secondary, tertiary

**Équation :** Niveau d'emphase requis ∝ Importance de l'action (fort) + Fréquence d'usage (modéré) − Risque de dilution (modéré)

| Groupe | Signal d'usage |
|--------|---------------|
| Primary | L'action la plus importante de la vue (1 seul élément dominant idéalement) |
| Secondary | Actions complémentaires, états de sélection, filtres actifs |
| Tertiary | Différenciation visuelle uniquement, accent de contraste, rarement pour des actions |

- Un écran avec trois éléments en `primary` n'a plus de hiérarchie — un seul élément primary par zone d'attention
- Secondary et tertiary peuvent coexister au même niveau, primary ne peut pas

**Zone de bascule :** Navigation bar et chips utilisent `secondary-container` pour l'indicateur actif — même si ce sont des actions primaires de navigation, le design M3 réserve `primary` pour les FAB et boutons filled, pas pour les indicateurs d'état.

**Raison généralisable :** Le cerveau perçoit `primary` comme "à faire maintenant". Multiplier les éléments primary détruit ce signal.

---

## H2 — Choisir le bon niveau de surface

**Équation :** Prominence de surface ∝ Niveau de container (fort) + Élévation (modéré)

| Rôle surface | Signal |
|-------------|--------|
| `surface` | Fond de page, zone neutre |
| `surface-container-low` | Cartes à elevation1, sidebar, drawer |
| `surface-container` | Nav bar, menus, composants standard |
| `surface-container-high` | Dialog, date picker (au-dessus du reste) |
| `surface-container-highest` | Text field filled (contrasté sur fond) |

- Ne pas utiliser `surface-container-high` pour du contenu non-modal — crée une fausse hiérarchie de profondeur
- `inverse-surface` est réservé aux composants qui ont besoin d'un contraste fort sur n'importe quel fond (snackbar, tooltip) — ne pas l'utiliser comme fond de page ou de section

**Zone de bascule :** Sur dark theme, `surface-container-highest` et `surface` s'inversent visuellement (le highest devient plus clair, pas plus sombre) — ne pas dessiner la hiérarchie en supposant que "container-high = plus sombre".

**Raison généralisable :** La hiérarchie des surfaces communique la profondeur spatiale : plus un élément est "en avant", plus son token container est élevé.

---

## H3 — Paires obligatoires : ne pas mélanger les groupes

**Équation :** Accessibilité garantie = Respect des paires (fort) − Croisements inter-groupes (fort)

| ✅ Appariement valide | ❌ Appariement invalide |
|----------------------|------------------------|
| `primary` + `on-primary` | `primary` + `on-secondary` |
| `primary-container` + `on-primary-container` | `primary-container` + `on-surface` |
| `surface-container` + `on-surface` | `surface-container-high` + `on-surface-variant` |

- Seules les paires officielles garantissent un contraste ≥ 3:1 algorithmiquement
- Mélanger les groupes peut fonctionner visuellement sur la baseline mais échoue silencieusement sur des dynamic schemes à chroma élevé

**Zone de bascule :** `on-surface-variant` sur `surface-container` est acceptable pour du texte secondaire — c'est une exception connue qui reste dans le seuil 3:1 sur la baseline. Sur dynamic schemes à forte saturation, à vérifier.

**Raison généralisable :** Les paires de couleur M3 sont garanties accessibles sur la baseline, mais le dynamic color peut produire des combinaisons de teintes où le contraste baisse sous les seuils WCAG. C'est pourquoi les paires inter-groupes ne sont jamais garanties — le système ne peut pas calculer l'accessibilité de combinaisons qu'il n'a pas lui-même définies.

---

## Traduction en application concrète

- **Audit rapide** : si un élément text/icône n'est pas coloré avec un rôle `on-X`, c'est un bug de token potentiel.
- **Custom component** : identifier d'abord l'emphase (primary/secondary/tertiary), puis si c'est un fond (→ rôle seul) ou un contenu sur fond coloré (→ rôle `on-X`).
- **Formulaires** : `on-surface-variant` pour les labels inactifs, `on-surface` pour les labels actifs, `primary` pour le focus indicator.
