---
source: https://m3.material.io/styles/color/advanced + /resources
category: Styles / Color
spec-version: v0.192
---

# Color Advanced — Heuristiques de décision

Fonctions avancées : couleurs fixes · harmonisation · roles custom · fidelité · combinaison de schemes

---

## Schéma de pensée

Les personnalisations avancées couvrent les cas où le système de base est insuffisant : couleurs de marque qui doivent rester exactes même avec dynamic color, nouvelles entités sémantiques qui n'ont pas de rôle M3 prédéfini, et ajustements algorithmiques pour que le dynamic color ressemble davantage à la couleur souhaitée. Chaque fonctionnalité avancée ajoute de la complexité — n'utiliser que ce qui répond à un besoin réel identifié.

---

## Principes

- Les **couleurs statiques** (anciennement "custom colors") s'ajoutent au scheme dynamique tout en restant constantes — parfaites pour les couleurs sémantiques fixes (success vert, warning orange).
- L'**harmonisation** ajuste une couleur statique pour qu'elle reste visuellement cohérente avec la couleur source dynamique — évite le clash visuel entre la couleur de marque et le dynamic scheme.
- Les **custom color roles** créent des rôles supplémentaires (ex : `shopping-cart`, `premium`) avec la même structure que les 26 rôles standard.
- La **color fidelity** force l'algorithme à produire des couleurs plus proches de la couleur d'entrée, au prix potentiel d'un contraste légèrement moindre.
- **Combiner plusieurs schemes** permet d'avoir un baseline scheme global + un content-based scheme local (ex : player dans l'app).

---

## H1 — Couleurs statiques dans un context dynamique

**Équation :** Besoin de couleur statique ∝ Valeur sémantique fixe (fort) + Conformité brand stricte (modéré) − Cohérence avec dynamic scheme (modéré)

| Cas | Solution |
|-----|----------|
| Couleur de marque qui ne doit pas changer | `fixed` color role |
| Couleur sémantique (success, warning) | Static color + harmonisation optionnelle |
| Couleur décorative dans un media app | Content-based color (ne pas fixer) |

- Une couleur statique non-harmonisée peut créer un contraste ou un conflit de teinte choquant avec un dynamic scheme — toujours tester sur plusieurs wallpapers
- L'harmonisation ajuste légèrement la teinte de la couleur statique pour qu'elle "appartienne" visuellement au scheme courant sans la changer radicalement

**Zone de bascule :** Une couleur de marque très distinctive (rouge Coca-Cola, orange Hermès) résiste mal à l'harmonisation — elle perd son identité. Dans ce cas, utiliser `fixed` sans harmonisation et accepter l'éventuel léger conflit visuel.

**Raison généralisable :** L'harmonisation fonctionne en décalant la teinte vers celle de la source. Sur des teintes très éloignées (ex : marque bleue + wallpaper vert), le décalage peut rendre la couleur méconnaissable.

---

## H2 — Créer un custom color role

**Équation :** Pertinence d'un custom role ∝ Sémantique distincte non couverte (fort) + Usage récurrent dans le produit (modéré) − Complexité de maintenance (modéré)

Structure d'un custom color role (même logique que les rôles standard) :
```
custom-name                  → fond/surface de l'entité
on-custom-name               → texte/icône sur custom-name
custom-name-container        → surface moins proéminente
on-custom-name-container     → texte/icône sur custom-name-container
```

- Ne créer un custom role que si l'entité a besoin de **4 sous-rôles** (fond + on + container + on-container) — sinon, mapper sur un rôle existant
- Les custom roles suivent exactement les mêmes règles de pairage et tone que les rôles standard
- Limiter à 2-3 custom roles maximum — chaque ajout alourdit le système de tokens

**Zone de bascule :** Si un custom role n'est utilisé que sur 1-2 composants, mieux vaut mapper ces composants sur un rôle existant (ex : tertiary) plutôt que créer un nouveau rôle.

---

## H3 — Ajuster le scheme : fidelité et algorithme custom

**Équation :** Fidelité du scheme ∝ Score de chroma fidelity (fort) − Risque de contraste dégradé (modéré)

### Color fidelity
- Forcing option : fait en sorte que `primary` ressemble plus à la couleur source exacte
- Utile quand la couleur de marque doit être reconnaissable même en dynamic scheme
- Contrepartie : certains tons peuvent se rapprocher de zones de faible contraste

### Baseline scheme personnalisé
- Saisir des couleurs d'entrée personnalisées → Material Theme Builder génère les palettes tonales complètes
- La différence avec un scheme dynamique : les palettes ne changent jamais avec l'environnement de l'utilisateur

### Dynamic scheme custom
- Définir des règles d'algorithme (chroma minimum, mapping de tons) pour contrôler précisément la sortie
- Cas d'usage : brand guidelines très strictes qui doivent coexister avec le personalization system

**Zone de bascule :** Modifier l'algorithme de génération est une opération avancée réservée aux équipes avec des designers système et des ingénieurs M3 experts — éviter sauf nécessité absolue.

---

## H4 — Combiner plusieurs schemes

**Équation :** Richesse colorimétrique ∝ Nombre de schemes combinés (modéré) − Complexité d'implémentation (fort) − Risque d'incohérence perçue (modéré)

| Pattern | Description | Cas d'usage |
|---------|-------------|-------------|
| Baseline global + content-based local | Player media change ses propres couleurs | Music app |
| Statique global + dynamique partial | Brand color global, accents dynamiques | App enterprise avec personal touch |
| Multi-brand | Plusieurs schemes selon l'entité affichée | Marketplace multi-marques |

- Toujours délimiter clairement les zones de chaque scheme (surfaces, composants) — éviter qu'un rôle soit interprété différemment selon le scheme courant
- Les composants qui traversent plusieurs zones (nav bar, app bar) doivent utiliser le scheme global — les schemes locaux restent dans des surfaces délimitées

---

## Traduction en application concrète

- **Couleur de succès/erreur custom** : créer une static color `success` harmonisée, générer ses 4 rôles, mapper aux badges et messages de confirmation.
- **Music player** : activer content-based color sur la surface du player uniquement — le reste de l'app reste sur le baseline/user-generated scheme.
- **Audit couleur** : vérifier que toute couleur hors des 26 rôles standard est soit un custom role documenté, soit une fixed color intentionnelle — toute valeur hex libre est un bug de système.
