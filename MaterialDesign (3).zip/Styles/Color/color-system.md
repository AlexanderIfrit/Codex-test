---
source: https://m3.material.io/styles/color/system/overview + how-the-system-works
category: Styles / Color
spec-version: v0.192
---

# Color System — Heuristiques de décision

Système : 26+ rôles couleur · Espace HCT · Palettes tonales · Schémas statiques & dynamiques
Métaphore fondatrice : peinture par numéros — chaque élément UI = numéro → numéro = couleur

---

## Schéma de pensée

Le système couleur M3 sépare radicalement la **sémantique** (quel rôle joue cet élément ?) de la **valeur** (quelle couleur exacte ?). Cette séparation est ce qui rend le dark mode, le dynamic color et l'accessibilité automatiques : les rôles restent constants, seules les valeurs changent. Ignorer cette séparation — nommer des couleurs hexadécimales directement dans les composants — rend le thème impossible à maintenir.

---

## Principes

- Le système repose sur HCT (Hue, Chroma, Tone) : une teinte peut varier en chroma et tone de 0 à 100 pour produire une palette tonale complète depuis le blanc (100) jusqu'au noir (0).
- Chaque couleur d'entrée génère 5 palettes-clés (primary, secondary, tertiary, error, neutral) composées de 13 tons chacune.
- Les rôles couleur sont la couche d'abstraction qui protège le design : `primary` peut valoir `#6750A4` en light et `#D0BCFF` en dark — les composants n'ont besoin de connaître que `primary`.
- Les paires de couleurs accessibles sont algorithmiquement garanties : toute valeur assignée à `on-X` offre au minimum 3:1 de contraste avec `X`.
- La couleur source unique (wallpaper ou contenu) suffit pour générer un schéma complet cohérent par dynamic color.

---

## Tokens de design — palettes tonales

| Palette | Tons disponibles |
|---------|-----------------|
| Primary | 0, 10, 20, 25, 30, 35, 40, 50, 60, 70, 80, 90, 95, 98, 99, 100 |
| Secondary | idem |
| Tertiary | idem |
| Error | idem |
| Neutral | idem |
| Neutral Variant | idem |

### Assignation light/dark theme (exemples)
| Rôle | Light (tone) | Dark (tone) |
|------|-------------|------------|
| `primary` | 40 | 80 |
| `on-primary` | 100 | 20 |
| `primary-container` | 90 | 30 |
| `on-primary-container` | 10 | 90 |
| `surface` | 98 | 6 |
| `on-surface` | 10 | 90 |
| `surface-container` | 94 | 12 |

---

## H1 — Utiliser un rôle couleur, jamais une valeur brute

**Équation :** Maintenabilité du thème ∝ Abstraction par rôle (fort) − Valeurs hexadécimales directes (fort)

- **Rôle = token sémantique** : `md-sys-color.primary` → s'adapte automatiquement au thème clair/sombre et au dynamic color
- **Valeur brute = rupture** : `#6750A4` codé directement dans un composant ne se met jamais à jour avec le thème
- **Sens de la variable** : plus on colle aux rôles, plus le dark mode et le dynamic color fonctionnent sans travail supplémentaire

**Zone de bascule :** Les couleurs de marque figées (logo couleur exacte, badge critique) nécessitent parfois une valeur statique — dans ce cas, utiliser `fixed` ou `harmonized` colors (voir `color-advanced.md`), pas des hexadécimaux libres.

**Raison généralisable :** HCT garantit l'accessibilité algorithmiquement. Sortir du système en injectant des valeurs brutes casse cette garantie silencieusement.

---

## H2 — Comprendre tone pour piloter le contraste

**Équation :** Contraste perçu ∝ Différence de tone (fort) + Chroma du contexte (faible)

- Tone 40 sur tone 100 → contraste ~4.5:1 (AA lisible)
- Tone 40 sur tone 90 → contraste < 3:1 (insuffisant pour texte)
- **Règle pratique** : une différence de ≥ 50 tones entre fond et texte garantit un contraste accessible
- Les paires `X` / `on-X` sont pré-calculées pour respecter ce seuil

**Zone de bascule :** Les ton-sur-ton décoratifs (fond primary-container avec bordure primary) peuvent être sous le seuil 3:1 si seuls les éléments non-texte sont concernés — le critère WCAG 3:1 ne s'applique qu'aux éléments fonctionnels (icônes actives, boutons) pas aux séparateurs décoratifs.

**Raison généralisable :** HCT est perceptuellement uniforme : une différence de 50 tones produit le même saut visuel quelle que soit la teinte. C'est ce qui rend les paires accessibles robustes sur n'importe quelle couleur d'entrée.

---

## H3 — Choisir la couleur source dynamic

**Équation :** Cohérence visuelle perçue ∝ Proximité de la source avec le contenu dominant (fort) + Chroma de la source (modéré)

| Source | Quand l'utiliser |
|--------|-----------------|
| Wallpaper utilisateur | App grand public, personnalisation prioritaire |
| Contenu in-app (album, cover) | Media players, lecture, galeries |
| Couleur de marque statique | Enterprise, apps institutionnelles, iOS |

- Une source à faible chroma (gris, beige pâle) produit un schéma terne → préférer une couleur de marque saturée comme source fallback
- Une source trop vive (chroma > 100) peut être désaturée par l'algorithme → le résultat reste lisible mais moins vibrant que prévu

**Zone de bascule :** Sur iOS, dynamic color (basé sur le wallpaper Android) n'est pas disponible — prévoir systématiquement un fallback static baseline.

**Raison généralisable :** Le système extrait la teinte dominante mais ajuste le chroma et le tone algorithmiquement pour garantir l'accessibilité. La source oriente, elle ne commande pas.

---

## Traduction en application concrète

- **En design** : utiliser exclusivement les variables de token `md-sys-color.*` dans Figma — jamais picker libre sauf pour définir la couleur source du theme builder.
- **En code** : mapper chaque élément custom au rôle le plus proche sémantiquement avant d'envisager un custom role.
- **Migration M2→M3** : commencer par le baseline scheme (mapping 1:1 des rôles M2 vers M3), puis activer dynamic color en second temps sans toucher aux composants.
- **Test** : vérifier le schéma sur 3 tons de source (clair/moyen/sombre) pour s'assurer que tous les rôles restent lisibles.
