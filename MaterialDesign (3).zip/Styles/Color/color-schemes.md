---
source: https://m3.material.io/styles/color/choosing-a-scheme + /static + /dynamic
category: Styles / Color
spec-version: v0.192
---

# Color Schemes — Heuristiques de décision

Types : Statique (baseline) · Dynamique (user-generated · content-based)
Décision centrale : quelle source de couleur pour quel produit ?

---

## Schéma de pensée

Le choix entre schéma statique et dynamique est une décision produit, pas une décision technique. Un schéma statique privilégie la cohérence de marque et la prévisibilité — ce que les designers connaissent depuis M2. Un schéma dynamique privilégie la personnalisation et l'émotion — les couleurs changent avec l'utilisateur. Les deux respectent les rôles et garantissent l'accessibilité ; seule la valeur des tokens change.

---

## Principes

- Un **schéma couleur** décrit la totalité des couleurs d'un produit sur light et dark theme via les rôles couleur.
- Le schéma **baseline** est le schéma statique par défaut de M3 — couleurs pré-définies par Google pour un démarrage rapide conforme.
- Le **dynamic color** génère un schéma complet depuis une source unique (wallpaper ou contenu) via l'espace HCT.
- Les rôles couleur restent identiques entre statique et dynamique — seules les valeurs changent.
- Dynamic color n'est disponible nativement que sur Android 12+ — iOS et Web nécessitent une implémentation manuelle ou restent en baseline.

---

## H1 — Statique ou dynamique : critères de décision

**Équation :** Pertinence du dynamic color ∝ Contexte grand public (fort) + Personnalisation prioritaire (fort) + Plateforme Android 12+ (modéré) − Exigences de marque rigide (fort) − Contexte enterprise (fort)

| Critère | → Statique (baseline) | → Dynamique |
|---------|----------------------|------------|
| Plateforme | iOS, Web, Android < 12 | Android 12+, Web avec polyfill |
| Utilisateurs | Enterprise, institutionnel | Grand public, consommateur |
| Priorité | Cohérence de marque | Personnalisation |
| Migration | Vient de M2 | Greenfield M3 |
| Contenu | Neutre (outils, productivité) | Riche (media, galerie, musique) |

**Zone de bascule :** Un produit Android grand public sans contrainte forte de marque devrait presque toujours activer dynamic color — l'absence de personnalisation est perçue comme un manque de polish sur les devices récents.

**Raison généralisable :** Dynamic color n'est pas un gadget : sur Android 12+, le Material You system attend que les apps répondent aux couleurs du wallpaper — une app qui n'y répond pas se perçoit comme "hors système".

---

## H2 — Static baseline : comment le personnaliser sans casser l'accessibilité

**Équation :** Sécurité du scheme personnalisé ∝ Utilisation du Material Theme Builder (fort) + Vérification des paires (fort) − Saisie manuelle de valeurs hex (modéré)

- **Material Theme Builder** (Figma plugin) : saisir une couleur de marque → génère automatiquement toutes les palettes tonales et assigne les rôles correctement
- Ne jamais modifier une valeur de rôle isolément — changer `primary` sans recalculer `primary-container` et `on-primary-container` casse la chaîne d'accessibilité
- Tester le scheme sur light + dark + high contrast avant de livrer

### Baseline — valeurs de référence M3
| Rôle | Light (HEX) | Dark (HEX) |
|------|------------|-----------|
| `primary` | `#6750A4` | `#D0BCFF` |
| `on-primary` | `#FFFFFF` | `#381E72` |
| `primary-container` | `#EADDFF` | `#4F378B` |
| `on-primary-container` | `#21005D` | `#EADDFF` |
| `secondary` | `#625B71` | `#CCC2DC` |
| `secondary-container` | `#E8DEF8` | `#4A4458` |
| `tertiary` | `#7D5260` | `#EFB8C8` |
| `surface` | `#FEF7FF` | `#141218` |
| `on-surface` | `#1D1B20` | `#E6E0E9` |

**Zone de bascule :** La baseline purple est faite pour démontrer le système, pas pour être utilisée telle quelle en production — remplacer systématiquement par la couleur de marque via Material Theme Builder.

---

## H3 — Dynamic color : trois sources possibles

**Équation :** Cohérence émotionnelle ∝ Proximité source/contenu (fort) + Chroma de la source (modéré)

| Source | Description | Cas d'usage |
|--------|-------------|-------------|
| **User-generated** | Wallpaper de l'appareil | Toute app grand public Android |
| **Content-based** | Image in-app (album, couverture) | Music, lecture, galeries |
| **App-defined** | Couleur fixe choisie par le produit | Fallback ou contenu neutre |

- **Content-based** : extraire la couleur dominante de l'image affichée → scheme change à chaque changement de contenu. Idéal pour les players musicaux, les apps de lecture.
- **User-generated** : l'OS Android fournit la couleur — aucun code spécifique nécessaire côté app si on utilise les tokens M3 correctement.
- Toujours fournir un fallback à la baseline quand la source est indisponible (image non chargée, OS < Android 12).

**Zone de bascule :** Le content-based color change à chaque changement de contenu — sur des vues riches avec beaucoup de contenu, cela peut créer un effet "disco". Limiter le content-based aux vues immersives (player plein écran, détail album).

---

## H4 — Contraste utilisateur (user-controlled contrast)

**Équation :** Accessibilité étendue = Support standard + medium + high contrast (fort) − Schéma couleur qui n'ajuste pas ses tones (fort)

- Dynamic color offre trois niveaux de contraste contrôlés par l'utilisateur : standard, medium, high
- Les tokens M3 ajustent automatiquement les tones selon le niveau sélectionné
- Static baseline ne supporte pas ce feature — les utilisateurs avec besoins de contraste élevé ne peuvent pas personnaliser

**Zone de bascule :** Si le produit cible des utilisateurs avec des besoins d'accessibilité élevés (apps de santé, apps gouvernementales), dynamic color avec support du user-controlled contrast devient presque obligatoire.

---

## Traduction en application concrète

- **Démarrage** : toujours commencer par le baseline scheme même si dynamic color est prévu — le remap des rôles se fait une seule fois et reste valide.
- **iOS** : utiliser une couleur de marque statique extraite dans Material Theme Builder, pas de dynamic color.
- **Android** : activer user-generated color dès le début, implémenter content-based color si media app.
- **Web** : le Material Web polyfill supporte dynamic color via une API JS — à activer explicitement.
