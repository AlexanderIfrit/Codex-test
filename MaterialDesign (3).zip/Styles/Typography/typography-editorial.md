---
source: https://m3.material.io/styles/typography/editorial-treatments
category: Styles / Typography
spec-version: v0.192 + M3 Expressive
---

# Typography Editorial Treatments — Heuristiques de décision

Usage : moments expressifs · axes variables (weight, grade, width, opsz) · type scale étendu
Principe : départ du type scale standard → amplification délibérée → cohérence par token

---

## Schéma de pensée

Les traitements éditoriaux sont les moments où la typographie cesse d'être fonctionnelle pour devenir expressive. Ce ne sont pas des erreurs ou des excès — ce sont des moments conçus et délibérés qui utilisent les axes des variable fonts pour créer une émotion ou marquer un moment particulier du parcours utilisateur. La clé : ces traitements sont **rares et tokenisés** — un usage systématique détruit leur impact, et l'absence de token crée de l'incohérence.

---

## Principes

- Les traitements éditoriaux s'écartent volontairement du type scale standard — c'est leur rôle.
- Ils s'appliquent dans **3 contextes** : célébration de contenu, voix de l'utilisateur, fonctionnalité bespoke.
- Chaque traitement éditorial récurrent doit être tokenisé — pas ajusté manuellement à chaque occurrence.
- Ne pas mixer plusieurs traitements dans le même layout — un seul traitement éditorial par zone d'attention.
- Ne pas reproduire les patterns de personnalisation de l'OS (dynamic theming) dans des traitements éditoriaux — risque de confusion.

---

## Les 3 contextes éditoriaux

### 1. Célébration de contenu
Marquer un moment fort lié à une action, un souvenir ou une préférence utilisateur.
- Album photo complété → grande typographie dramatique
- Objectif atteint → poids variable fort + typographie expansive
- Moment de journée / saison → texture typographique qui reflète l'émotion

### 2. Voix de l'utilisateur
Laisser l'utilisateur personnaliser l'apparence de la typographie ou adapter le texte selon ses inputs.
- Intensité d'une émotion → poids de la police qui varie (text-to-variable-font)
- Paramètre utilisateur → style typographique qui change (journal, mood tracker)
- Réponse à un contenu → traitement qui exprime la tonalité du contenu

### 3. Fonctionnalité bespoke
Utiliser les axes de la police pour exprimer visuellement une fonctionnalité unique du produit.
- Niveau de luminosité → width de la police qui varie
- Intensité sonore → weight qui répond en temps réel
- Vitesse d'un événement → condensed ↔ extended selon la vélocité

---

## Axes variables et leur rôle expressif

### Weight (wght) — axe principal
**Plage Roboto Flex** : 100 (Thin) → 900 (Black)
| Traitement | Weight | Émotion/Signal |
|-----------|--------|---------------|
| Sérénité, légèreté | 100–200 | Minimalisme, air |
| Standard neutre | 400 | Fonctionnel |
| Emphase, confiance | 600–700 | Force, autorité |
| Expressivité maximale | 800–900 | Énergie, célébration |

⚠️ Poids très légers (< 200) à grande taille uniquement — illisibles en petites tailles, surtout sur basse résolution.
⚠️ Poids très lourds (> 700) en petites tailles → letters trop serrées, illisibilité.

### Grade (GRAD) — ajustement optique fin
**Plage Roboto Flex** : -200 → 150
- Grade faible (-200 à -50) → allège visuellement sans changer la structure (économie d'attention)
- Grade élevé (+100 à +150) → renforce l'épaisseur percue (dark mode, fond sombre)
- Grade n'est pas un substitut au weight — c'est un ajustement subperceptif complémentaire

### Width (wdth) — condensed ↔ extended
**Plage Roboto Flex** : 25% (très condensé) → 151% (très élargi)
- Condensed : densité, urgence, pression (news ticker, alerte)
- Extended : détente, espace, luxe (editorial, landing page premium)
- Sur du texte multilignes, les variations de width changent le nombre de caractères par ligne → ne pas modifier en cours de paragraphe

### Optical Size (opsz) — lisibilité à la taille
**Plage Roboto Flex** : 8 → 144
- Toujours synchroniser avec la `font-size` réelle — voir `typography-system.md` H4

---

## H1 — Décider si un traitement éditorial est justifié

**Équation :** Pertinence du traitement éditorial ∝ Caractère de moment unique (fort) + Rareté dans le parcours (fort) + Émotion intentionnelle (modéré) − Traitement sur du texte fonctionnel (fort) − Systématisation (fort)

| ✅ Traitement éditorial adapté | ❌ Pas adapté |
|-------------------------------|--------------|
| Écran de célébration d'objectif atteint | Labels de navigation |
| Message de bienvenue personnalisé | Corps de texte standard |
| Visualisation d'une émotion utilisateur | Informations dans un formulaire |
| Hero moment d'onboarding | Texte dans un dialog |
| Réponse expressive à un input | Titres de liste récurrents |

**Zone de bascule :** Un écran "résultats de recherche" avec 50+ items peut avoir un titre éditorial fort — si et seulement si c'est chaque fois la première chose que l'utilisateur voit en entrant dans la vue (hero de page), pas un titre de section parmi d'autres.

**Raison généralisable :** L'impact éditorial est dilué par la répétition. Un traitement typographique qui apparaît 20 fois par session cesse d'être un moment éditorial et devient du bruit visuel.

---

## H2 — Tokeniser les traitements éditoriaux

**Équation :** Cohérence des moments éditoriaux ∝ Tokens créés par traitement (fort) + Portée définie (fort) − Ajustements manuels case-by-case (fort)

Structure d'un token éditorial :
```css
/* Token éditorial : célébration d'objectif */
--editorial-achievement-size: 48sp;
--editorial-achievement-weight: 800;
--editorial-achievement-tracking: -1sp;
--editorial-achievement-line-height: 52sp;
--editorial-achievement-color: var(--md-sys-color-primary);
```

- Créer un token par traitement éditorial récurrent — pas par occurrence
- Si un traitement n'est utilisé qu'une seule fois dans tout le produit, un token est optionnel mais recommandé pour la documentation
- Les tokens éditoriaux sont distincts des tokens du type scale standard — les nommer clairement avec un préfixe `editorial-`

**Zone de bascule :** Combien de tokens éditoriaux est trop ? Règle pratique : au-delà de 8-10 tokens éditoriaux, revisiter l'architecture — soit le design system manque de tokens standard, soit trop de moments sont traités comme éditoriaux.

---

## H3 — Combiner traitement éditorial + autres attributs M3

**Équation :** Impact du moment éditorial ∝ Typographie expressive (fort) + Motion (modéré) + Couleur (modéré) + Forme (modéré) − Surenchère de tous les attributs simultanément (fort)

| Combinaison | Effet |
|------------|-------|
| Typo expressive + motion (poids qui change) | Réponse vivante à l'input utilisateur |
| Typo expressive + couleur dynamique | Moment personnalisé fort |
| Typo expressive + shape morph | Célébration de niveau supérieur |
| Typo expressive + motion + couleur + shape | ⚠️ Trop — choisir 2 attributs maximum |

- La règle des 2 attributs : un moment éditorial gagne en impact avec 2 attributs expressifs combinés. Au-delà, l'effet est trop chargé et perd sa cohérence.
- Le mouvement amplifie l'expressivité de la typographie — une police qui change de weight en réponse à une interaction est plus mémorable qu'une police statique même très lourde.

---

## H4 — Garde-fous : ce qui ne doit jamais arriver

**Équation :** Intégrité du système ∝ Cohérence des moments éditoriaux (fort) + Lisibilité maintenue (fort) − Traitements incohérents entre eux (fort) − Illisibilité par excès (fort)

| Règle | Pourquoi |
|-------|----------|
| Ne pas mixer deux styles éditoriaux dans le même layout | Crée un conflit d'attention visuelle |
| Ne pas utiliser des poids très légers sur fond sombre | Illisible à basse résolution |
| Ne pas utiliser le traitement éditorial pour donner de l'information | L'édito doit être compris même si ignoré |
| Ne pas imiter le dynamic theming système | Confus avec la personnalisation OS |
| Ne pas alterner les traitements selon le contexte sans règle | Incohérence perçue comme bug |

**Zone de bascule :** Une app grand public peut avoir des traitements éditoriaux fréquents (3-4 par session) si chaque moment est distinct et espacé dans le temps. Une app enterprise ou de productivité devrait limiter à 1-2 par session — les utilisateurs en session longue rejettent rapidement les traitements "fun" qui ralentissent leur flux.

---

## Traduction en application concrète

- **Variable font setup** : Roboto Flex doit être chargé avec les axes nécessaires (`font-variation-settings`). Ne charger que les axes utilisés pour éviter le poids de police inutile.
- **Animation d'axe** : animer `font-variation-settings` en CSS/JS avec `transition: font-variation-settings 300ms ease` pour des transitions de weight/width fluides.
- **Documentation** : créer une page "Moments éditoriaux" dans le design system avec le mapping de chaque token éditorial à son contexte d'usage, son effet et ses contraintes.
- **Reduced-motion** : les animations d'axes variables (weight qui change) doivent être désactivées en `prefers-reduced-motion` — remplacer par un changement de couleur statique pour signaler le même état.
