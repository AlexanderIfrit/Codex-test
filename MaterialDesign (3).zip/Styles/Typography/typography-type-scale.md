---
source: https://m3.material.io/styles/typography/type-scale-tokens
category: Styles / Typography
spec-version: v0.192
---

# Typography Type Scale & Tokens — Heuristiques de décision

Tokens : md-sys-typescale-* · 5 propriétés par style · Appliquer via tokens, jamais en dur

---

## Schéma de pensée

Les tokens de type scale sont la traduction technique du type scale sémantique en valeurs précises. Leur rôle est de garantir que chaque instance de "Body Large" dans tout le produit a exactement la même taille, le même line-height et le même tracking — quelle que soit la plateforme. La maîtrise des tokens typographiques permet aussi de modifier globalement le type scale (changer la police, augmenter les tailles) en un seul endroit plutôt que de chasser des valeurs hardcodées dans tout le code.

---

## Structure complète des tokens

Chaque style génère **5 tokens** :

```
md-sys-typescale-{style}-font        → famille de police
md-sys-typescale-{style}-size        → taille en sp/px
md-sys-typescale-{style}-line-height → hauteur de ligne
md-sys-typescale-{style}-weight      → graisse (100-900)
md-sys-typescale-{style}-tracking    → letter-spacing en sp/px
```

---

## Référence complète des valeurs

### Display
| Token | font | size | line-height | weight | tracking |
|-------|------|------|------------|--------|---------|
| `display-large` | Roboto | 57sp | 64sp | 400 | -0.25sp |
| `display-medium` | Roboto | 45sp | 52sp | 400 | 0sp |
| `display-small` | Roboto | 36sp | 44sp | 400 | 0sp |

### Headline
| Token | font | size | line-height | weight | tracking |
|-------|------|------|------------|--------|---------|
| `headline-large` | Roboto | 32sp | 40sp | 400 | 0sp |
| `headline-medium` | Roboto | 28sp | 36sp | 400 | 0sp |
| `headline-small` | Roboto | 24sp | 32sp | 400 | 0sp |

### Title
| Token | font | size | line-height | weight | tracking |
|-------|------|------|------------|--------|---------|
| `title-large` | Roboto | 22sp | 28sp | 400 | 0sp |
| `title-medium` | Roboto | 16sp | 24sp | 500 | +0.15sp |
| `title-small` | Roboto | 14sp | 20sp | 500 | +0.1sp |

### Body
| Token | font | size | line-height | weight | tracking |
|-------|------|------|------------|--------|---------|
| `body-large` | Roboto | 16sp | 24sp | 400 | +0.5sp |
| `body-medium` | Roboto | 14sp | 20sp | 400 | +0.25sp |
| `body-small` | Roboto | 12sp | 16sp | 400 | +0.4sp |

### Label
| Token | font | size | line-height | weight | tracking |
|-------|------|------|------------|--------|---------|
| `label-large` | Roboto | 14sp | 20sp | 500 | +0.1sp |
| `label-medium` | Roboto | 12sp | 16sp | 500 | +0.5sp |
| `label-small` | Roboto | 11sp | 16sp | 500 | +0.5sp |

---

## H1 — Appliquer via tokens, pas en dur

**Équation :** Maintenabilité ∝ Usage de tokens (fort) + Centralisation (fort) − Valeurs hardcodées (fort)

```css
/* ✅ Correct */
.card-title {
  font: var(--md-sys-typescale-title-large-font);
  font-size: var(--md-sys-typescale-title-large-size);
  line-height: var(--md-sys-typescale-title-large-line-height);
  font-weight: var(--md-sys-typescale-title-large-weight);
  letter-spacing: var(--md-sys-typescale-title-large-tracking);
}

/* ❌ Incorrect */
.card-title {
  font-family: Roboto;
  font-size: 22px;
  line-height: 28px;
  font-weight: 400;
  letter-spacing: 0;
}
```

**Zone de bascule :** Dans un projet avec un design system CSS existant, mapper les tokens M3 aux variables CSS du DS existant plutôt que de les dupliquer — créer une couche de mapping (`--ds-heading-2: var(--md-sys-typescale-title-large-size)`) pour la transition.

**Raison généralisable :** Un changement de police ou de taille globale propagé via token coûte 2 minutes ; le même changement en valeurs hardcodées coûte des heures et laisse des incohérences résiduelles. Le token est une assurance contre la dette de design.

---

## H2 — Line-height : la valeur oubliée

**Équation :** Lisibilité ∝ Line-height correct (fort) + Taille de police (fort) − Line-height ignoré (fort)

- Le ratio line-height/font-size idéal est entre 1.2 (compact) et 1.5 (aéré) selon la taille
- M3 calibre ces ratios par style : Display (1.12–1.22), Body/Label (1.14–1.43)
- Ne jamais utiliser `line-height: normal` (valeur navigateur variable et imprédictible)
- Sur des textes multilignes (Body, Headline), le line-height a un impact majeur sur la lisibilité — une valeur trop serrée fatigue l'œil

| Style | Ratio line-height/size |
|-------|----------------------|
| Display Large | 1.12 |
| Headline Large | 1.25 |
| Title Large | 1.27 |
| Body Large | 1.50 |
| Label Large | 1.43 |
| Label Small | 1.45 |

**Zone de bascule :** Pour les très grandes tailles (Display), un ratio faible (1.12) est correct — les lettres sont grandes et lisibles même serrées. Pour les petites tailles (Label Small), un ratio élevé (1.45) est nécessaire pour éviter que les lignes se chevauchent visuellement.

**Raison généralisable :** Le line-height compense optiquement le fait que plus les caractères sont petits, plus l'œil a besoin d'espace interlinéaire pour retrouver le début de la ligne suivante sans se perdre.

---

## H3 — Letter-spacing : quand le tracking ajoute de la valeur

**Équation :** Clarté typographique ∝ Tracking positif pour petites tailles (modéré) + Tracking négatif pour grandes tailles (modéré) − Sur-tracking (fort)

- **Grandes tailles (Display)** : tracking légèrement négatif (-0.25sp) → les caractères grands ont tendance à sembler trop espacés naturellement, le tracking négatif les resserr
- **Petites tailles (Label, Body Small)** : tracking positif (+0.4–0.5sp) → améliore la lisibilité en ouvrant les formes des caractères
- **Tailles intermédiaires (Title, Body Medium)** : tracking proche de 0 ou très légèrement positif

**Zone de bascule :** Le tracking positif excessif (> 2sp) sur du texte courant crée un effet "lettres découpées" difficile à lire rapidement. Le tracking est efficace uniquement dans les plages définies dans le type scale — ne pas l'augmenter pour créer des effets décoratifs sur du texte fonctionnel.

**Raison généralisable :** La perception de l'espacement entre lettres est relative à la taille des caractères. À 57sp, -0.25sp est imperceptible mais corrige le lourd optique des grands glyphes. À 11sp, +0.5sp ouvre les formes comprimées pour restaurer la lisibilité. La direction du tracking suit donc la taille : grand → négatif, petit → positif.

---

## H4 — Weight : Medium (500) vs Regular (400)

**Équation :** Emphase UI ∝ Medium weight (modéré) pour labels et titres + Regular pour corps de texte (fort)

- **Regular (400)** : corps de texte long (Body, Display, Headline) — moins fatigant sur les longues lectures
- **Medium (500)** : labels UI, titles Medium et Small — signale visuellement la nature fonctionnelle et interactive
- Le **Bold (700)** n'apparaît pas dans le type scale M3 standard — réservé aux traitements éditoriaux (voir `typography-editorial.md`)

**Zone de bascule :** Sur des displays basse résolution (< 200 PPI), la différence entre Regular et Medium peut être imperceptible. Dans ce cas, envisager d'utiliser SemiBold (600) pour les labels à la place de Medium pour garantir la distinction visuelle.

**Raison généralisable :** Medium (500) sur des labels communique la nature interactive et fonctionnelle de l'élément — le poids est un marqueur sémantique, pas seulement esthétique. Regular (400) sur un label suggère visuellement que l'élément est informatif plutôt qu'actionnable.

---

## Traduction en application concrète

- **CSS custom properties** : définir les 75 tokens (15 styles × 5 propriétés) dans un fichier `:root {}` global — tous les composants y accèdent.
- **Compose** : `MaterialTheme.typography.titleLarge` expose directement les valeurs — ne pas créer de TextStyle manuels.
- **Test d'accessibilité** : vérifier que le type scale scale correctement avec le multiplicateur de police système (× 1.5 minimum sans perte de contenu).
- **Figma** : mapper chaque text style Figma à son token M3 correspondant dans les annotations de handoff.
