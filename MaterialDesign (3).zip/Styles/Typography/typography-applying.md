---
source: https://m3.material.io/styles/typography/applying-type
category: Styles / Typography
spec-version: v0.192
---

# Typography Applying — Heuristiques de décision

Règles d'application : hiérarchie · longueur de ligne · lisibilité · composants M3

---

## Schéma de pensée

Appliquer la typographie correctement, c'est d'abord comprendre comment le regard parcourt un écran : il suit la hiérarchie de taille (du plus grand au plus petit), puis la densité (zones plus intenses attirent l'œil), puis le contraste de couleur. Le type scale M3 est conçu pour que ces trois signaux travaillent ensemble. Rompre un de ces signaux — par exemple mettre un Body Large plus grand qu'un Title Medium dans la même vue — crée une incohérence que l'utilisateur ressent comme du "bruit", même sans pouvoir le nommer.

---

## Principes

- Un seul style typographique dominant par vue — éviter deux styles de même taille proche qui "se battent".
- La hiérarchie visuelle doit être immédiatement lisible : l'utilisateur doit comprendre en < 1 seconde ce qui est le plus important.
- La longueur de ligne optimale est entre 40 et 60 caractères pour du texte courant (Body) — au-delà, l'œil perd le fil en revenant à la ligne.
- Le contraste de couleur (rôle typographique) complète la hiérarchie de taille — `on-surface` pour le texte principal, `on-surface-variant` pour le secondaire.
- Jamais de soulignement décoratif — réservé aux liens.

---

## H1 — Construire la hiérarchie typographique d'une vue

**Équation :** Clarté de la hiérarchie ∝ Saut de taille entre niveaux (fort) + Contraste de couleur/weight (modéré) − Styles trop proches sur les niveaux adjacents (fort)

| Niveau hiérarchique | Style recommandé | Couleur recommandée |
|--------------------|-----------------|-------------------|
| Titre principal de la vue | `headline-large` ou `headline-medium` | `on-surface` |
| Sous-titre de section | `title-large` ou `title-medium` | `on-surface` |
| Corps de texte principal | `body-large` ou `body-medium` | `on-surface` |
| Métadonnées, captions | `body-small` ou `label-medium` | `on-surface-variant` |
| Labels UI (boutons, tabs, chips) | `label-large` | `on-surface` / rôle spécifique |

- Entre chaque niveau hiérarchique adjacent, il doit y avoir un saut visible de taille (minimum 4sp d'écart)
- `on-surface-variant` pour les métadonnées communique visuellement "info secondaire" sans avoir besoin d'une taille encore plus petite

**Zone de bascule :** Sur mobile compact, `display-large` (57sp) est trop imposant pour les titres de vue réguliers — descendre à `headline-large` (32sp) comme titre principal et réserver Display aux splash screens et onboarding.

**Raison généralisable :** La hiérarchie typographique est le premier signal de navigation dans une vue. Si un utilisateur ne comprend pas où regarder en premier en 500ms, l'architecture de l'information est défaillante — pas seulement la typographie.

---

## H2 — Longueur de ligne et lisibilité des blocs de texte

**Équation :** Lisibilité du texte long ∝ Longueur de ligne dans [40–60 car] (fort) + Font-size ≥ 14sp (fort) + Line-height ≥ 1.4 (modéré)

| Contexte | Longueur de ligne cible | Contrainte mobile |
|----------|------------------------|------------------|
| Corps d'article, description longue | 60–80 caractères | Accepter 35–50 sur compact |
| Cards avec résumé | 40–60 caractères | Standard |
| Labels, titres | Pas de contrainte de longueur | — |

- Sur mobile compact (360dp), une colonne unique de texte fait naturellement ~35–45 caractères avec une police de 16sp — pas besoin d'ajustement
- Sur tablette et desktop, contraindre la largeur du container de texte (`max-width: 680px`) plutôt que de laisser le texte s'étirer sur toute la largeur
- **Ne jamais** laisser du texte body s'étirer sur plus de 100 caractères — le retour à la ligne devient un effort physique pour l'œil

**Zone de bascule :** Les headers et titres n'ont pas de contrainte de longueur de ligne — ils doivent s'adapter à leur conteneur. C'est uniquement le texte multi-lignes (2 lignes+) qui nécessite la contrainte 40–80 caractères.

---

## H3 — Appariement texte/couleur de rôle

**Équation :** Accessibilité couleur texte ∝ Rôle de couleur correspondant au niveau (fort) + Contraste ≥ 4.5:1 pour texte normal (fort) + Contraste ≥ 3:1 pour grand texte (fort)

| Type de texte | Rôle couleur | Contraste garanti |
|--------------|-------------|------------------|
| Texte principal (corps, titres) | `on-surface` | 4.5:1+ sur `surface` |
| Texte secondaire (metadata, captions) | `on-surface-variant` | 3:1+ sur `surface` |
| Texte sur couleur primaire | `on-primary` | 4.5:1+ sur `primary` |
| Texte sur container | `on-primary-container` | 4.5:1+ sur `primary-container` |
| Placeholder text | `on-surface-variant` à 38% opacity | Borderline — tester |
| Texte désactivé | `on-surface` à 38% opacity | < 3:1 — normal pour désactivé |

- Le texte désactivé est volontairement sous le seuil WCAG — c'est le signal visuel que l'élément n'est pas interactif
- `on-surface-variant` offre un contraste suffisant pour du texte secondaire (3:1+) mais pas pour du texte principal (< 4.5:1) — ne jamais l'utiliser pour du texte principal de lecture

**Zone de bascule :** Sur un fond `primary-container` coloré (dynamic color), `on-primary-container` garantit le contraste. Mais si le fond est `surface-container` et non `primary-container`, utiliser `on-surface` — le mauvais appariement de rôles peut créer du texte illisible sur un dynamic scheme non-testé.

---

## H4 — Typographie dans les composants M3 : ne pas déroger

**Équation :** Cohérence système ∝ Usage des tokens typographiques prescrits par composant (fort) − Overrides locaux (modéré)

| Composant | Style typographique prescrit |
|-----------|----------------------------|
| Button (all) | `label-large` |
| Chip | `label-large` |
| Tab | `title-small` |
| Navigation Bar label | `label-medium` |
| Navigation Rail label | `label-medium` |
| Card title | `title-large` |
| Card subhead | `body-medium` |
| Dialog headline | `headline-small` |
| Dialog body | `body-medium` |
| Text Field label | `body-large` |
| Text Field helper text | `body-small` |
| Snackbar | `body-medium` |
| Tooltip | `body-small` |
| Badge | `label-small` |
| App Bar title | `title-large` |

- **Ne jamais overrider** la typographie d'un composant M3 sans raison documentée — la cohérence du type scale à travers tous les composants est ce qui crée l'homogénéité du produit
- Si la typographie d'un composant semble incorrecte pour le contexte, c'est souvent un signe que le mauvais composant est utilisé, pas que la typographie du composant doit changer

**Zone de bascule :** Sur une app avec une police de marque custom très différente de Roboto (ex : serif, condensed), certains styles peuvent nécessiter un ajustement de size ou de line-height pour rester lisibles — documenter ces exceptions comme une variante du type scale, pas comme des overrides locaux.

---

## H5 — Alignement du texte

**Équation :** Lisibilité ∝ Alignement gauche pour texte long (fort) + Alignement centré pour texte court isolé (modéré) − Justification forcée (fort)

| Cas | Alignement recommandé |
|-----|----------------------|
| Corps de texte, descriptions | Gauche (LTR), Droite (RTL) |
| Titres de page | Gauche ou centré selon le design |
| Labels dans les composants (boutons, tabs) | Centré |
| Texte dans les cards | Gauche |
| Texte d'illustration / empty state | Centré |
| Texte long justifié | ❌ Jamais — crée des "rivières" blanches |

**Zone de bascule :** Les titres de sections de page peuvent être alignés à gauche ou centrés selon la nature de l'app (apps éditoriales centrent souvent, apps d'outils alignent à gauche). L'essentiel : choisir une convention et ne jamais alterner sans raison.

---

## Traduction en application concrète

- **Architecture de la vue** : définir les 3-4 styles typographiques utilisés dans une vue en wireframe, avant d'entrer dans les détails visuels.
- **Responsive** : sur desktop, contraindre `max-width` des containers de texte body à ~680px — les textes ne doivent pas s'étirer sur toute la largeur d'un écran large.
- **Dark mode** : `on-surface` en dark theme est un blanc cassé (~90% tone) — ne pas remplacer par un blanc pur `#FFFFFF` qui crée un contraste trop fort sur fond sombre.
- **Performance** : éviter le chargement de polices non-utilisées — ne charger que les weights réellement utilisés dans le type scale (400, 500 pour Roboto M3 standard).
