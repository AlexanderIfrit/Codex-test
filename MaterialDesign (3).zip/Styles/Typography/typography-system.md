---
source: https://m3.material.io/styles/typography/overview + fonts
category: Styles / Typography
spec-version: v0.192
---

# Typography System — Heuristiques de décision

Type scale M3 : 15 styles · 5 catégories (Display, Headline, Title, Body, Label)
Police par défaut : Roboto · Variable fonts supportées : Roboto Flex, Google Sans Flex

---

## Schéma de pensée

Le type scale M3 est un système de 15 styles nommés sémantiquement — pas par taille, mais par rôle. "Display" ne veut pas dire "grand" mais "moment visuel fort". "Label" ne veut pas dire "petit" mais "étiquette fonctionnelle". Comprendre les rôles sémantiques avant les tailles est ce qui distingue une typographie qui communique d'une typographie qui décore. Les trois tailles (Large, Medium, Small) permettent des variations contextuelles au sein du même rôle.

---

## Principes

- **5 rôles sémantiques** : Display (visuels forts), Headline (titres), Title (sous-titres), Body (texte courant), Label (éléments UI fonctionnels).
- Chaque rôle a **3 tailles** (Large, Medium, Small) = 15 styles au total.
- Chaque style est défini par : font family, font weight, font size, line height, letter spacing.
- Par défaut, Roboto — remplaçable par n'importe quelle Google Font ou police propriétaire via Material Theme Builder.
- Les variable fonts (Roboto Flex, Google Sans Flex) permettent des traitements éditoriaux avancés via les axes variables.

---

## Tokens de design — type scale complète

| Style | Font Size | Line Height | Letter Spacing | Weight défaut |
|-------|----------|------------|----------------|--------------|
| **Display Large** | 57sp | 64sp | -0.25sp | Regular (400) |
| **Display Medium** | 45sp | 52sp | 0 | Regular (400) |
| **Display Small** | 36sp | 44sp | 0 | Regular (400) |
| **Headline Large** | 32sp | 40sp | 0 | Regular (400) |
| **Headline Medium** | 28sp | 36sp | 0 | Regular (400) |
| **Headline Small** | 24sp | 32sp | 0 | Regular (400) |
| **Title Large** | 22sp | 28sp | 0 | Regular (400) |
| **Title Medium** | 16sp | 24sp | +0.15sp | Medium (500) |
| **Title Small** | 14sp | 20sp | +0.1sp | Medium (500) |
| **Body Large** | 16sp | 24sp | +0.5sp | Regular (400) |
| **Body Medium** | 14sp | 20sp | +0.25sp | Regular (400) |
| **Body Small** | 12sp | 16sp | +0.4sp | Regular (400) |
| **Label Large** | 14sp | 20sp | +0.1sp | Medium (500) |
| **Label Medium** | 12sp | 16sp | +0.5sp | Medium (500) |
| **Label Small** | 11sp | 16sp | +0.5sp | Medium (500) |

*sp = scalable pixels — **différent de dp sur Android** : sp suit le multiplicateur de police système choisi par l'utilisateur (Accessibilité → Taille du texte). Une valeur de 16sp devient 20px si l'utilisateur a activé le facteur ×1.25. Sur iOS et Web, il n'y a pas d'équivalent natif de sp — utiliser em/rem ou les APIs Dynamic Type d'iOS.*

### Tokens CSS/code
```
md-sys-typescale-display-large-font
md-sys-typescale-display-large-size        → 57px
md-sys-typescale-display-large-line-height → 64px
md-sys-typescale-display-large-weight      → 400
md-sys-typescale-display-large-tracking    → -0.25px
[pattern identique pour tous les 15 styles]
```

---

## H1 — Choisir la catégorie sémantique correcte

**Équation :** Pertinence du style ∝ Rôle sémantique de l'élément (fort) + Hiérarchie dans la vue (modéré) − Taille comme critère principal (fort)

| Catégorie | Rôle sémantique | Ne pas utiliser pour |
|-----------|----------------|---------------------|
| **Display** | Titre héroïque, texte qui domine visuellement | Corps de texte, navigation |
| **Headline** | Titre de section, titre de page | Très long paragraphe, labels |
| **Title** | Sous-titre, titre de composant (card, dialog) | Corps principal, texte décoratif |
| **Body** | Texte courant, descriptions, paragraphes | Titres, labels UI |
| **Label** | Boutons, chips, tabs, badges, captions | Texte de paragraphe |

- Ne jamais choisir un style uniquement parce qu'il produit la taille voulue — mapper d'abord le rôle sémantique, puis ajuster via Large/Medium/Small
- `Label Medium` sur un bouton est canonique M3 — ne pas "upgrader" en `Body Medium` pour avoir une police plus grande sur un bouton

**Zone de bascule :** Un titre de card devrait-il être `Title Large` ou `Headline Small` ? Ils sont proches en taille (22sp vs 24sp). La règle : `Title` pour les composants, `Headline` pour les sections de page. Une card est un composant → `Title Large`.

**Raison généralisable :** La sémantique du style est visuelle, pas structurelle. La hiérarchie HTML (h1, h2, h3…) dépend du balisage, pas du style M3 appliqué. Un `Title Large` CSS sur un `<p>` n'est pas un heading pour les screen readers — le composant ou le balisage sémantique est la responsabilité du développeur, indépendamment du token typographique.

---

## H2 — Choisir entre Large, Medium, Small

**Équation :** Taille optimale ∝ Espace disponible (fort) + Densité de la vue (modéré) + Importance relative (modéré)

| Modificateur | Signal |
|-------------|--------|
| **Large** | Moment dominant, espace disponible, mobile standard |
| **Medium** | Version équilibrée, contexte standard |
| **Small** | Espace contraint, informations denses, secondaire |

- `Display Large` (57sp) : uniquement pour les vues splash ou les héros très généreux — peut dépasser la largeur mobile sur certains textes
- `Body Large` (16sp) vs `Body Medium` (14sp) : Large pour les textes longs (articles, descriptions) — la lisibilité s'améliore significativement au-delà de 300 mots
- `Label Small` (11sp) : taille minimale pour un texte fonctionnel lisible — ne jamais descendre en dessous sans test d'accessibilité

**Zone de bascule :** Sur une app responsive (compact → expanded), un `Headline Large` (32sp) sur desktop peut devenir `Headline Medium` (28sp) sur mobile. Les tokens M3 permettent cette adaptation par breakpoint — à configurer explicitement dans le theme.

---

## H3 — Sélectionner la police de caractères

**Équation :** Cohérence typographique ∝ Police unique pour tout le type scale (fort) + Harmonie avec la marque (modéré) − Combinaisons de polices sans raison (modéré)

| Police | Caractère | Disponibilité |
|--------|-----------|--------------|
| **Roboto** | Neutre, lisible, universel | Android système, Google Fonts |
| **Roboto Flex** | Variable, expressif, moderne | Google Fonts (variable font) |
| **Google Sans** | Amical, moderne | Google produits (licence spéciale) |
| **Google Sans Flex** | Variable, très expressif | Google produits + M3 Expressive |
| *Police propriétaire* | Identité marque forte | Via Material Theme Builder |

- Une seule police pour tout le type scale est la règle M3 — deux polices maximum si une sérieuse raison éditoriale le justifie (ex : serif pour le corps + sans-serif pour les labels)
- Les variable fonts (Roboto Flex, Google Sans Flex) offrent des traitements éditoriaux avancés (axes weight, width, grade, optical size) sans changer de police

**Zone de bascule :** Utiliser une police de marque propriétaire peut nécessiter de définir manuellement tout le type scale (les valeurs de line-height, tracking ne seront pas celles de Roboto). Material Theme Builder permet cette customisation.

---

## H4 — Optical size : synchroniser avec la taille d'affichage

**Équation :** Fidélité typographique ∝ opsz aligné avec font-size (fort) − Désynchronisation (modéré)

- Les polices variables avec l'axe `opsz` (optical size) adjustent automatiquement les détails des glyphes pour chaque taille
- `Display Large` (57sp) → `opsz: 57` — les traits sont plus fins, les détails plus subtils
- `Label Small` (11sp) → `opsz: 11` — les traits sont plus épais, la lisibilité prioritaire
- Sans ajustement `opsz`, une police optiquement calibrée pour 57sp utilisée à 11sp semble trop fine et illisible

**Zone de bascule :** Si la police ne supporte pas l'axe `opsz` (polices non-variables), ne pas chercher à simuler l'effet — utiliser la police telle quelle. L'optical size n'est un enjeu que pour les variable fonts.

---

## Traduction en application concrète

- **Design** : mapper chaque élément UI au token `md-sys-typescale-*` correspondant — jamais de taille hardcodée.
- **Accessibilité** : respecter le minimum de 11sp pour tout texte fonctionnel. Sur les platforms avec texte dynamique (iOS Dynamic Type, Android font scale), les tokens doivent scaler automatiquement.
- **Handoff** : livrer les 15 styles avec leurs 5 propriétés complètes (family, size, weight, line-height, tracking) — pas seulement la taille.
- **Roboto Flex** : si utilisé, définir les préréglages d'axes par style dans le design system pour éviter que les développeurs improvise les axes.
