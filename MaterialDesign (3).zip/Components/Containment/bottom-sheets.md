---
source: https://m3.material.io/components/bottom-sheets
category: Containment
spec-version: v0.192
---

# Bottom Sheets — Heuristiques de décision

Variantes : Standard · Modal
Ancré au bas de l'écran, révèle du contenu supplémentaire ou des actions.

---

## Tokens de design — valeurs de référence

### Bottom Sheet
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-low` |
| `container-elevation` | `level1` → **1dp** (Standard) |
| `container-shape` | `corner-extra-large-top` → **28px 28px 0 0** |
| `drag-handle-color` | `md-sys-color.on-surface-variant` |
| `drag-handle-height` | **4px** |
| `drag-handle-width` | **32px** |
| `drag-handle-shape` | `corner-full` → **9999px** |
| Scrim (Modal) | `md-sys-color.scrim` à **0.32** opacity |
| `container-surface-tint-layer-color` | `md-sys-color.surface-tint` |

### Mesures internes
| Zone | Valeur |
|------|--------|
| Padding top (avec drag handle) | **48px** (handle + 16px) |
| Padding horizontal | **16px** |
| Padding bottom (safe area) | `env(safe-area-inset-bottom)` + **16px** |
| Drag handle margin-top | **12px** |
| Drag handle margin-bottom | **12px** |
| Hauteur min visible (peek) | **~56px** |

---

## H1 — Standard vs Modal Bottom Sheet

**Standard Bottom Sheet :**
- Coexiste avec le contenu principal — l'utilisateur peut interagir avec les deux
- Peut être partiellement visible (peek height), révélant un aperçu du contenu
- Pas de scrim — pas de blocage du fond
- Usage : carte + détail en overlay, playlist dans un player audio

**Modal Bottom Sheet :**
- Bloque l'interaction avec le fond (scrim à `0.32`)
- L'utilisateur doit interagir avec la sheet ou la fermer
- Fermeture : swipe down, tap sur scrim, action explicite
- Usage : menu de partage, sélection d'options, filtres, confirmations légères

**Zone de bascule :** Si l'action ne nécessite pas de bloquer le fond → Standard. Si l'utilisateur doit compléter une tâche avant de continuer → Modal. Si l'action est critique → Dialog.

---

## H2 — Quand utiliser un Bottom Sheet vs Dialog vs Menu

| Composant | Quand l'utiliser |
|-----------|----------------|
| Dialog | Confirmation critique, action irréversible, message de haute priorité |
| Modal Bottom Sheet | Actions contextuelles, choix parmi options, contenu moyen-priorité |
| Standard Bottom Sheet | Contenu complémentaire persistant, coexistence avec le fond |
| Menu | Petite liste d'actions contextuelles simples (≤ 5–7 items) |

---

## H3 — Drag handle et navigation

- Drag handle (`32px × 4px`, `corner-full`) : toujours présent si la sheet est draggable
- Placer le handle à `12px` du haut du container, centré horizontalement
- Une sheet sans drag handle = pas draggable = fermeture uniquement par bouton/scrim
- Hauteurs possibles : peek / half / full — transitions animées avec spring easing

---

## H4 — Contenu adapté aux Bottom Sheets

- Idéal pour : listes d'actions (partage, options), formulaires courts, galeries d'images, filtres
- Ne pas surcharger avec des formulaires longs → Full-screen Dialog
- Contenu scrollable : la sheet peut s'étendre à full-height, contenu scroll à l'intérieur

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Modal pour les actions qui nécessitent un focus temporaire
✅ **Do :** Standard pour coexister avec le contenu principal
✅ **Do :** Toujours inclure un drag handle si la sheet est draggable
❌ **Don't :** Remplacer un Dialog par une Bottom Sheet pour des actions critiques
❌ **Don't :** Formulaires très longs dans une Bottom Sheet

---

## Traduction en application concrète

**Menu de partage :** Modal Bottom Sheet, `corner-extra-large-top 28px`, liste d'apps avec icônes, drag handle visible. Scrim `0.32`.

**Spec de remise :** `border-radius:28px 28px 0 0`, `background:var(--md-sys-color-surface-container-low)`. Handle : `width:32px`, `height:4px`, `border-radius:9999px`, `background:var(--md-sys-color-on-surface-variant)`, `margin:12px auto`.
