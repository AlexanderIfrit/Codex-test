---
source: https://m3.material.io/components/carousel
category: Containment
spec-version: v0.192
---

# Carousel — Heuristiques de décision

Layouts : Multi-browse · Uncontained · Hero · Hero centré · Full-screen
Défilement : horizontal (défaut) ou vertical (full-screen uniquement)

---

## Tokens de design — valeurs de référence

### Carousel (mesures clés)
| Token / Mesure | Valeur |
|----------------|--------|
| `container-shape` | `corner-medium` → **12px** |
| `large-item-height` | **~240px** (variable selon layout) |
| `medium-item-height` | **~56px** (Multi-browse) |
| `small-item-height` | **~40px** (Multi-browse) |
| `item-spacing` | **8px** |
| Vitesse de défilement | Scroll standard, sans snap obligatoire |
| Scrim gradient optionnel | `rgba(0,0,0,0.3–0.5)` pour lisibilité du texte sur image |

### Layouts et ratios approximatifs
| Layout | Grands items | Petits items | Usage |
|--------|-------------|-------------|-------|
| Multi-browse | ≥ 1 large, 1 medium, 1 small | Variable | Collections variées, exploration |
| Uncontained | Tous équivalents, scroll vers bord | Aucun | Albums, galeries photos |
| Hero | ≥ 1 large, 1 small | Partiel | Contenu éditorial featuté |
| Hero centré | 1 large centré, 2 small | Partiel | Recommandations, apps |
| Full-screen | 1 edge-to-edge | Aucun | Onboarding, stories |

---

## H1 — Carousel vs liste scrollable vs grille

**Équation :** Pertinence Carousel = Contenu visuel fort (fort) + Navigation par exploration (fort) + Nombre d'items ≥ 4 (modéré)

- Carousel = exploration visuelle, parcours non-linéaire
- Liste = lecture séquentielle, comparaison, sélection rapide
- Grille = scan d'ensemble, tous les items visibles
- **Ne pas utiliser si** les items sont identiques/textuels → List

---

## H2 — Choisir le layout

| Si… | Layout recommandé |
|-----|-----------------|
| Items de tailles très variées, exploration riche | Multi-browse |
| Photos, médias sans contrainte d'espace | Uncontained |
| 1 item vedette + aperçu d'items voisins | Hero |
| Onboarding, slides, stories | Full-screen |
| Recommandations centrées (app stores, streaming) | Hero centré |

---

## H3 — Texte sur images dans un carousel

- Utiliser un scrim (gradient overlay `rgba(0,0,0, 0.3–0.5)`) pour assurer le contraste du texte
- Texte bref uniquement : titre + sous-titre max, `title-medium` + `body-small`
- Ne pas ajouter de texte dense ou de boutons multiples sur les items du carousel

---

## H4 — Scroll et snap

- Scroll standard recommandé pour Uncontained (pas de snap)
- Snap optionnel pour Full-screen (un item à la fois, centré)
- Indiquer la présence d'items cachés (partial reveal de l'item suivant)

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Utiliser pour du contenu visuel riche, exploration non-linéaire
✅ **Do :** Adapter le layout à la taille de fenêtre (responsive)
❌ **Don't :** Carousel pour du contenu identique/non-visuel → List
❌ **Don't :** Trop de texte sur les items du carousel

---

## Traduction en application concrète

**Pour une app de streaming :** Hero centré pour « Recommandés pour vous », Multi-browse pour « Nouvelles sorties ».

**Spec de remise :** `border-radius:12px` sur chaque item. Gap : `8px`. Partial reveal du prochain item : `~40px` visible sur le bord droit.
