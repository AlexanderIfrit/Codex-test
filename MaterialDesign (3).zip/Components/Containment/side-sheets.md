---
source: https://m3.material.io/components/side-sheets
category: Containment
spec-version: v0.192
---

# Side Sheets — Heuristiques de décision

Variantes : Standard · Modal
Ancré sur le côté droit de l'écran (côté gauche pour des cas spéciaux RTL).

---

## Tokens de design — valeurs de référence

### Side Sheet
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-low` |
| `container-elevation` | `level1` → **1dp** (Standard) |
| `container-shape` | `corner-extra-large-start` → **28px 0 0 28px** (côté gauche arrondi) |
| Scrim (Modal) | `md-sys-color.scrim` à **0.32** opacity |

### Mesures
| Zone | Valeur |
|------|--------|
| Largeur minimale | **256dp** |
| Largeur maximale | **~400dp** ou selon breakpoint |
| Padding interne | **24px** |
| Header height | **~56px** |

---

## H1 — Side Sheet vs Bottom Sheet vs Navigation Drawer

**Équation :** Préférence Side Sheet = Fenêtre medium–expanded (fort) + Contenu complémentaire lié au contenu principal (fort) + Pas de navigation primaire (modéré)

| Composant | Orientation | Contenu | Fenêtre |
|-----------|------------|---------|---------|
| Bottom Sheet | Bas → haut | Actions contextuelles | Compact (mobile) |
| Side Sheet | Droite → gauche | Détail/propriétés | Medium–Expanded |
| Navigation Drawer | Gauche | Navigation primaire | Medium–Expanded |

**Règle clé :** Le Side Sheet est une version latérale du Bottom Sheet, adapté aux écrans larges. Sur compact/mobile → utiliser Bottom Sheet. Sur tablette/desktop → Side Sheet.

---

## H2 — Standard vs Modal (même logique que Bottom Sheet)

**Standard Side Sheet :**
- Coexiste avec le contenu principal (push ou overlay partiel)
- Pas de scrim — l'utilisateur peut interagir avec les deux zones
- Le contenu principal peut se rétrécir pour laisser place au Sheet (push layout)
- Usage : propriétés d'un élément sélectionné, panneau de filtres persistants

**Modal Side Sheet :**
- Scrim bloque le fond
- Fermeture : tap scrim ou bouton × explicite
- Usage : formulaires de détail, configs temporaires

---

## H3 — Contenu et largeur

- Largeur typique : **320–400dp** sur tablette, **~360dp** sur desktop
- Contenu : propriétés d'un objet sélectionné, filtres avancés, panneau d'annotation, détail d'une sélection
- Toujours inclure un bouton de fermeture explicite (icône `×` ou `close`) dans le header
- En mode push : le contenu principal se redimensionne → s'assurer que le layout principal supporte le rétrécissement

---

## H4 — Adaptive design

- Compact → Bottom Sheet (même contenu, orientation différente)
- Medium → Side Sheet (en modal si dense, en standard si espace suffisant)
- Expanded → Side Sheet Standard persistant possible (panneau latéral permanent)

---

## Traduction en application concrète

**Panneau de propriétés (app type Figma/tableur) :** Standard Side Sheet persistant à droite, `width:320px`, `border-radius:28px 0 0 28px`, pas de scrim, push layout.

**Spec de remise :** `border-radius:28px 0 0 28px`, `background:var(--md-sys-color-surface-container-low)`, `box-shadow:elevation-level1`. Largeur : `320–400dp`. Padding : `24px`.
