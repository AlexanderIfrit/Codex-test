---
source: https://m3.material.io/components/toolbars
category: Containment
spec-version: v0.192
---

# Toolbars — Heuristiques de décision

Principe : barre d'actions fréquentes liées au **contenu sélectionné ou à la vue actuelle** — différent de l'App Bar (navigation globale).

---

## Tokens de design — valeurs de référence

### Toolbar
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface` (standard) ou `md-sys-color.surface-container-highest` (contextuelle) |
| `container-elevation` | `level0` → **0dp** (si ancrée) ou `level2` → **3dp** (si flottante) |
| `container-height` | **64px** (standard) |
| `container-shape` | `corner-full` → **9999px** (floating toolbar) |
| Icon color | `md-sys-color.on-surface-variant` |
| Padding horizontal | **16px** |
| Espacement entre icon buttons | **8px** |

### Toolbar contextuelle (text selection)
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-highest` |
| `container-elevation` | `level2` → **3dp** |
| `container-shape` | `corner-full` → **9999px** |

---

## H1 — Toolbar vs App Bar vs FAB

**Équation :** Pertinence Toolbar = Actions liées au **contenu** de la vue (fort) + Plusieurs actions simultanées (fort) + Pas de navigation principale (modéré)

| Composant | Contient | Position |
|-----------|---------|----------|
| App Bar (Top) | Navigation, titre de page, icônes globales | Haut |
| Toolbar | Actions liées au contenu courant (edit, share, delete) | Bas ou inline |
| FAB | UNE action primaire, positive | Overlay flottant |

---

## H2 — Types de toolbars

**Toolbar ancrée (bottom) :** Fixée en bas de l'écran, persistante. Contient les actions les plus fréquentes de la vue.

**Toolbar contextuelle :** Apparaît lorsqu'un texte ou un élément est sélectionné. Remplace temporairement la toolbar normale. `corner-full` shape. Actions : Couper, Copier, Coller, Gras, etc.

**Toolbar inline :** Intégrée dans un composant (éditeur de texte, formulaire). Pas d'élévation.

---

## H3 — Contenu et nombre d'icônes

- Maximum **5 icon buttons** visibles dans une toolbar
- Actions supplémentaires : overflow menu (`⋮`) toujours en dernier
- Icônes : `24px`, couleur `on-surface-variant`
- Divider vertical optionnel entre groupes d'actions liées
- Ne pas ajouter de navigation ou de titre dans une toolbar (→ App Bar)

---

## H4 — Floating toolbar (contextuelle, sélection de texte)

- `corner-full` (9999px), `elevation level2`, `surface-container-highest`
- Apparaît en popup au-dessus de la sélection, pas ancrée
- Disparaît dès que la sélection est annulée
- Actions : Couper / Copier / Coller / Gras / Italique (selon contexte éditeur)

---

## Traduction en application concrète

**App de messagerie (bottom toolbar) :** Toolbar ancrée, `height:64px`, icônes : `attach_file`, `photo_camera`, `gif`, `mic`, overflow `⋮`.

**Éditeur de texte (formatting toolbar) :** Inline, `height:48px`, icônes B / I / U / `format_list_bulleted` / `link` / `⋮`.

**Spec de remise :** `height:64px`, `background:var(--md-sys-color-surface)`, `padding-inline:16px`. Icon buttons : `24px`, `on-surface-variant`. Gap : `8px`.
