---
source: https://m3.material.io/components/dialogs
category: Containment
spec-version: v0.192
---

# Dialogs — Heuristiques de décision

Variantes : Basic dialog · Full-screen dialog
Principe : modal, bloque tout le contenu app jusqu'à action de l'utilisateur.

---

## Tokens de design — valeurs de référence

### Dialog
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-high` |
| `container-elevation` | `level3` → **6dp** |
| `container-shape` | `corner-extra-large` → **28px** |
| `action-label-text-color` | `md-sys-color.primary` |
| `action-label-text-font` | `md-sys-typescale.label-large` |
| `action-focus-state-layer-color` | `md-sys-color.primary` |
| `headline-color` | `md-sys-color.on-surface` |
| `headline-font` | `md-sys-typescale.headline-small` |
| `headline-size` | `md-sys-typescale.headline-small-size` |
| `with-icon-icon-color` | `md-sys-color.secondary` |
| `with-icon-icon-size` | **24px** |
| Scrim color | `md-sys-color.scrim` à **0.32** opacity |

### Mesures internes
| Zone | Valeur |
|------|--------|
| Padding container | **24px** |
| Espacement headline → supporting text | **16px** |
| Espacement supporting text → boutons | **24px** |
| Padding boutons (zone d'action) | **24px** |
| Largeur max du dialog (compact) | **~312px** |
| Largeur max du dialog (expanded) | **~560px** |

---

## H1 — Dialog vs alternatives moins interruptives

**Équation :** Pertinence Dialog = Importance critique du message (fort) + Action obligatoire requise (fort) + Fréquence d'apparition (fort négatif — rares = bien)

| Composant | Importance | Action requise |
|-----------|-----------|---------------|
| Snackbar | Faible | Optionnelle ou aucune |
| Dialog | Haute | Obligatoire — bloque l'app |
| Bottom Sheet | Moyenne | Optionnelle |

**Zone de bascule :** Pour les messages informatifs de priorité faible/moyenne → Snackbar. Pour la confirmation avant action destructive irréversible (supprimer, déconnecter) → Dialog. Ne pas utiliser Dialog pour des notifications routinières → fatigue dialog.

---

## H2 — Basic vs Full-screen dialog

**Basic dialog :** Pour les confirmations, alertes, choix simples.
- 1 ou 2 boutons d'action (Text buttons en bas à droite)
- Fermeture : tap sur scrim ou bouton d'annulation
- Hauteur auto selon contenu

**Full-screen dialog :** Pour les formulaires complexes, configurations, tâches multi-étapes.
- Occupe tout l'écran sur mobile compact
- Header avec titre + bouton fermer (icône `×`) + bouton action (Text button dans la barre)
- Fermeture uniquement via les boutons (pas de tap sur scrim)

---

## H3 — Contenu et boutons d'action

- **Titre (headline) :** optionnel, max 1 ligne, `headline-small`, `on-surface`
- **Icône :** optionnelle, `24px`, `secondary-color` — pour les alertes uniquement
- **Supporting text :** obligatoire, `body-medium`, max 3–4 lignes avant scroll
- **Boutons :** max 2, Text buttons par défaut, côté droit
  - Action principale : à droite
  - Action secondaire/annuler : à gauche de la principale
  - Si 3+ actions → privilégier une liste à l'intérieur du dialog

---

## H4 — Comportement du scrim

- Scrim : `md-sys-color.scrim` à **0.32** opacity par défaut
- Basic dialog : tap scrim = fermeture (dismiss)
- Full-screen dialog : tap scrim = **aucun effet** (action requise via boutons)

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Réserver aux informations critiques nécessitant une décision
✅ **Do :** 1–2 boutons maximum (Basic) — Text buttons en bas à droite
✅ **Do :** Full-screen pour les formulaires complexes sur mobile
❌ **Don't :** Utiliser pour des priorités faibles/moyennes → Snackbar
❌ **Don't :** 3+ boutons dans un Basic dialog → restructurer

---

## Traduction en application concrète

**Confirmation de suppression :** Basic dialog, titre : « Supprimer ce fichier ? », supporting text : « Cette action est irréversible. », boutons : `Annuler` (gauche) + `Supprimer` (droite, `error-color`).

**Spec de remise :** `border-radius:28px`, `background:var(--md-sys-color-surface-container-high)`, `box-shadow:elevation-level3`. Padding : `24px`. Scrim : `rgba(0,0,0,0.32)`. Max-width : `560px`.
