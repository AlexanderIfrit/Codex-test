---
source: https://m3.material.io/components/lists
category: Containment
spec-version: v0.192
---

# Lists — Heuristiques de décision

Principe : index vertical continu de texte, icônes, images et éléments de sélection.
Hauteur d'item : déterminée par l'élément le plus haut.

---

## Tokens de design — valeurs de référence

### List (tokens composants)
| Token | Valeur |
|-------|--------|
| `list-item-container-color` | `md-sys-color.surface` |
| `list-item-container-elevation` | `level0` → **0dp** |
| `list-item-container-shape` | `corner-none` → **0px** |
| `list-item-disabled-label-text-opacity` | **0.30** |
| `list-item-disabled-leading-icon-opacity` | **0.38** |
| `list-item-disabled-trailing-icon-opacity` | **0.38** |
| `list-item-dragged-container-elevation` | `level4` → **8dp** |
| `list-item-dragged-state-layer-opacity` | `pressed-state-layer-opacity` |
| `divider-leading-space` | **16px** |
| `divider-trailing-space` | **16px** |

### Hauteurs d'items
| Contenu | Hauteur |
|---------|---------|
| Label uniquement (1 ligne) | **48dp** |
| Label + 1 ligne supporting text | **64dp** |
| Label + 2 lignes supporting text | **80dp** |
| Label + image/avatar leading | **72dp** ou plus |

### Espacements internes (list item)
| Zone | Valeur |
|------|--------|
| Padding horizontal | **16px** |
| Espacement entre leading media et texte | **16px** |
| Espacement entre texte et trailing | **16px** |
| Leading icon size | **24px** |
| Leading avatar size | **40px** |
| Leading image size | **56px** |

### Typographie des items
| Élément | Token typographique |
|---------|-------------------|
| Label text | `md-sys-typescale.body-large` |
| Supporting text | `md-sys-typescale.body-medium` |
| Trailing text | `md-sys-typescale.label-small` |

---

## H1 — List vs Card vs Table : arbitrage fondamental

**Équation :** Préférence List = Contenu linéaire homogène (fort) + Scan vertical (fort) + Sélection ou actions contextuelles (modéré)

- **List :** éléments identiques ou similaires, lecture séquentielle, sélection
- **Cards :** éléments avec contenu riche hétérogène, exploration non-linéaire
- **Table :** données comparatives avec colonnes, tri, filtrage dense

---

## H2 — Anatomie d'un list item : éléments leading et trailing

**Leading (optionnel) :**
- Icône 24px → actions/catégories
- Avatar 40px → personnes
- Image/Thumbnail 56px → médias, produits

**Corps (obligatoire) :**
- `label-text` : `body-large`, `on-surface` — toujours présent
- `supporting-text` : `body-medium`, `on-surface-variant` — optionnel, 1–2 lignes

**Trailing (optionnel) :**
- Texte court (`label-small`, `on-surface-variant`) : date, valeur
- Icône 24px : action (ex : `chevron-right`, `more-vert`)
- Icon button : action interactive
- Contrôle de sélection : Checkbox, Radio, Switch

**Règle d'alignement :** Tous les éléments leading à la même position dans la liste → facilite le scan vertical.

---

## H3 — Dividers

- Divider optionnel entre items quand la densité est haute
- `divider-leading-space` : **16px** (commence après le padding gauche)
- `divider-trailing-space` : **16px** (finit avant le padding droit)
- Inset divider (ne traverse pas toute la largeur) : améliore la lisibilité pour des listes avec leading elements

---

## H4 — Interactivité et états

- Item cliquable : hover/focus → `state-layer` sur `on-surface`, `opacity:0.08–0.12`
- Item draggable : dragged → `level4` elevation, state layer sur `on-surface`
- Item sélectionné : `container-color` → `secondary-container` ou `tertiary-container`
- Item disabled : labels à `0.30` opacity, icônes à `0.38` opacity

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Aligner les leading elements à la même position dans toute la liste
✅ **Do :** Utiliser des supporting text pour enrichir sans surcharger
❌ **Don't :** Varier la position des éléments d'un item à l'autre dans la même liste
❌ **Don't :** Utiliser des lists pour des données comparatives → Table

---

## Traduction en application concrète

**Liste de contacts :** `leading-avatar 40px` (initiales), `label-text body-large` (nom), `supporting-text body-medium` (email), `trailing-icon-button more-vert`. Hauteur item : `64dp` minimum.

**Spec de remise :** `background:var(--md-sys-color-surface)`, `padding-inline:16px`. Item height selon contenu (48/64/80dp). Divider : `1px solid var(--md-sys-color-outline-variant)`, inset `16px`.
