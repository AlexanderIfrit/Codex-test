---
source: https://m3.material.io/components/cards
category: Containment
spec-version: v0.192
---

# Cards — Heuristiques de décision

Variantes : Elevated · Filled · Outlined
Principe : le container est le seul élément obligatoire. Tout le reste (image, titre, texte, bouton) est optionnel.

---

## Tokens de design — valeurs de référence

### Elevated Card
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-low` |
| `container-elevation` | `level1` → **1dp** |
| `container-shape` | `corner-medium` → **12px** |
| `hover-container-elevation` | `level2` → **3dp** |
| `focus-container-elevation` | `level1` → **1dp** |
| `pressed-container-elevation` | `level1` → **1dp** |
| `dragged-container-elevation` | `level4` → **8dp** |
| `hover-state-layer-color` | `md-sys-color.on-surface` |
| `icon-color` | `md-sys-color.primary` |
| `icon-size` | **24px** |
| `disabled-container-opacity` | **0.38** |

### Filled Card
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-highest` |
| `container-elevation` | `level0` → **0dp** |
| `container-shape` | `corner-medium` → **12px** |
| `dragged-container-elevation` | `level3` → **6dp** |

### Outlined Card
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface` |
| `container-elevation` | `level0` → **0dp** |
| `container-shape` | `corner-medium` → **12px** |
| `outline-color` | `md-sys-color.outline-variant` |
| `outline-width` | **1px** |

### Espacements internes
| Zone | Valeur recommandée |
|------|-------------------|
| Padding container | **16px** |
| Espacement entre blocs de contenu | **8px** |
| Media (image) : aucun padding sur les bords | 0px (edge-to-edge) |
| Boutons d'action : padding bottom | **8px** |

---

## H1 — Choisir la variante selon la surface et l'emphase

**Équation :** Variante = Fond de la surface (fort) + Niveau d'emphase requis (fort) + Style visuel du produit (modéré)

| Variante | Container color | Emphase | Usage typique |
|----------|----------------|---------|--------------|
| Elevated | `surface-container-low` + ombre `1dp` | Modérée | Séparation claire du fond, contenu important |
| Filled | `surface-container-highest` | Faible | Subtile, fond uniforme, densité haute |
| Outlined | `surface` + bordure `1px` | Moyenne–haute | Formulaires, tableaux, contenu à délimiter précisément |

**Zone de bascule :** Sur un fond déjà `surface-container-low`, l'Elevated se confond → passer à Outlined. Sur un fond `surface-container-highest`, le Filled se noie → passer à Elevated.

---

## H2 — Quand utiliser une Card vs un autre conteneur

**Règle :** Une Card = **un seul sujet**. Si le contenu couvre plusieurs sujets → plusieurs cards ou changer de structure (liste, section).

- Cards appropriées : albums, contacts, articles, produits, événements
- Listes appropriées : éléments identiques, densité haute, sélection multiple
- Pas de Card si : les éléments sont de simples données tabulaires → utiliser List ou Table

---

## H3 — Composition interne et hiérarchie de contenu

- Regrouper le contenu en **blocs** (image, header, body, actions)
- Image : toujours edge-to-edge dans le card (pas de padding autour de l'image)
- Hiérarchie typographique : Headline → Subhead → Body text
  - Headline : `md-sys-typescale.title-medium` ou `title-large`
  - Subhead : `md-sys-typescale.body-medium`
  - Supporting text : `md-sys-typescale.body-small`
- Boutons d'action : dans une zone dédiée en bas du card, alignés à droite ou en pleine largeur

---

## H4 — Cards dans une collection (grille, liste, carousel)

- Aligner les éléments à la même position dans chaque card pour faciliter le scan
- Ne pas varier la position des éléments d'une card à l'autre
- Dans une grille : toutes les cards de la même ligne = même hauteur (stretch)
- Dans un carousel : cards avec tailles variables admises (Multi-browse layout)

---

## H5 — Interactivité

- Card non-interactive : élévation fixe `level0` ou `level1`
- Card cliquable : hover → `level2`, `state-layer-opacity` sur `on-surface`
- Card draggable : dragged → `level4` (8dp), `pressed-state-layer-opacity`
- Ne pas mettre plusieurs zones cliquables différentes dans une card non-interactif → utiliser des boutons explicites

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Utiliser pour du contenu sur un seul sujet
✅ **Do :** Regrouper les éléments en blocs clairs avec hiérarchie visuelle
✅ **Do :** Cards facilement scannables — alignement cohérent entre cards
❌ **Don't :** Forcer du contenu dans une card quand du texte avec dividers suffirait
❌ **Don't :** Mélanger des sujets différents dans une même card

---

## Traduction en application concrète

**Pour une grille de produits :** Elevated Cards `12px` radius, image edge-to-edge en haut, titre `title-medium`, prix `body-large`, bouton `+ Ajouter` Text ou Tonal en bas.

**Spec de remise (Elevated) :** `border-radius:12px`, `background:var(--md-sys-color-surface-container-low)`, `box-shadow:elevation-level1`. Padding interne : `16px`. Image : `border-radius:12px 12px 0 0` (top seulement).
