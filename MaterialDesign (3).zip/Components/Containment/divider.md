---
source: https://m3.material.io/components/divider
category: Containment
spec-version: v0.192
---

# Divider — Heuristiques de décision

Variants : Full-width · Inset · Middle inset
Un séparateur visuel mince pour grouper et séparer des contenus.

---

## Tokens de design — valeurs de référence

### Divider
| Token | Valeur |
|-------|--------|
| `color` | `md-sys-color.outline-variant` |
| `thickness` | **1px** |
| Inset left (Inset divider) | **16px** |
| Inset left (Middle inset) | **16px** |
| Inset right (Middle inset) | **16px** |

---

## H1 — Divider vs espacement blanc vs section header

**Équation :** Pertinence Divider = Contenu dense (fort) + Besoin de séparation sans rupture visuelle forte (modéré)

- **Divider full-width :** entre sections distinctes de même niveau hiérarchique
- **Divider inset :** entre items d'une liste (commence après le padding leading) — préserve la continuité visuelle
- **Divider middle inset :** entre items sans leading element
- **Whitespace seul** suffit si les sections sont visuellement distinctes — éviter le divider superflu

**Zone de bascule :** Dans une liste avec images/avatars leading, l'inset divider (ne traversant pas la zone leading) est plus élégant. Dans des listes denses sans leading, un full-width divider clarifie la séparation.

---

## H2 — Orientation

- **Horizontal** : entre rangées, sections, items de liste (usage principal)
- **Vertical** : entre éléments d'une rangée (tab bars, toolbars, colonnes)

---

## H3 — Quand éviter le Divider

- Éviter entre chaque item si l'espacement blanc suffit
- Ne pas utiliser dans les menus ou dropdowns → les items sont naturellement séparés par espacement
- Dans les listes : utiliser au maximum un divider tous les 2–3 groupes, pas entre chaque item

---

## Traduction en application concrète

**Listes Settings :** Full-width divider entre groupes de settings (Compte, Notifications, Apparence). Pas de divider entre chaque item individuel.

**Spec de remise :** `height:1px`, `background:var(--md-sys-color-outline-variant)`. Inset : `margin-left:16px` (inset) ou `margin-inline:16px` (middle inset).
