# Material Design 3 — Composants UI : Index de la documentation

> Documentation de référence pour la prise de décision en design M3.
> Chaque fichier = heuristiques de décision + tokens de design réels (valeurs v0.192) + règles Do/Don't officielles.
> Format : **jamais un résumé**, toujours des équations décisionnelles pondérées.

---

## Structure

```
MaterialDesign/Components/
├── Action/           → Boutons, FABs, sélecteurs d'actions
├── Containment/      → Surfaces, conteneurs, collections
├── Communication/    → Feedback, état, information
├── Navigation/       → Structure de navigation
├── Selection/        → Formulaires, choix, filtres
└── TextInput/        → Saisie de texte
```

---

## Index par catégorie

### Action
| Fichier | Composant | Cas d'usage principal |
|---------|----------|----------------------|
| `Action/buttons.md` | Buttons (5 variantes + Toggle) | Hiérarchie d'actions, emphase |
| `Action/icon-buttons.md` | Icon Buttons (4 variantes + Toggle) | Actions iconiques, barres |
| `Action/fab.md` | FAB (3 tailles) | Action primaire flottante |
| `Action/extended-fab.md` | Extended FAB (3 tailles) | Action primaire avec label |
| `Action/fab-menu.md` | FAB Menu ✨ | 2–5 sous-actions liées |
| `Action/split-button.md` | Split Button ✨ | Action principale + variantes |
| `Action/segmented-buttons.md` | Segmented Buttons | Modes, filtres 2–5 options |
| `Action/button-groups.md` | Button Groups ✨ | Groupes d'actions interactifs |

### Containment
| Fichier | Composant | Cas d'usage principal |
|---------|----------|----------------------|
| `Containment/cards.md` | Cards (3 variantes) | Contenu sur un sujet unique |
| `Containment/carousel.md` | Carousel (4 layouts) | Collections visuelles scrollables |
| `Containment/dialogs.md` | Dialogs (Basic + Full-screen) | Interruptions critiques |
| `Containment/bottom-sheets.md` | Bottom Sheets (Standard + Modal) | Contenu complémentaire mobile |
| `Containment/side-sheets.md` | Side Sheets (Standard + Modal) | Propriétés/détail tablette/desktop |
| `Containment/lists.md` | Lists | Index verticaux de données |
| `Containment/divider.md` | Divider | Séparation de sections |
| `Containment/toolbars.md` | Toolbars | Actions liées au contenu courant |

### Communication
| Fichier | Composant | Cas d'usage principal |
|---------|----------|----------------------|
| `Communication/badges.md` | Badges (Small + Large) | Compteurs de notifications |
| `Communication/progress-indicators.md` | Progress Indicators (Linear + Circular) | Progression déterminée/indéterminée |
| `Communication/loading-indicator.md` | Loading Indicator ✨ | Chargement expressif M3 |
| `Communication/snackbar.md` | Snackbar | Feedback bref non-bloquant |
| `Communication/tooltips.md` | Tooltips (Plain + Rich) | Aide contextuelle |

### Navigation
| Fichier | Composant | Cas d'usage principal |
|---------|----------|----------------------|
| `Navigation/app-bars.md` | App Bars (Top × 4 variants + Bottom) | En-tête de navigation |
| `Navigation/navigation-bar.md` | Navigation Bar | Navigation primaire compact (3–5 dest.) |
| `Navigation/navigation-drawer.md` | Navigation Drawer | Navigation primaire expanded (5+ dest.) |
| `Navigation/navigation-rail.md` | Navigation Rail | Navigation primaire medium (3–7 dest.) |
| `Navigation/search.md` | Search | Recherche contextuelle ou globale |
| `Navigation/tabs.md` | Tabs (Primary + Secondary) | Vues de même niveau |

### Selection
| Fichier | Composant | Cas d'usage principal |
|---------|----------|----------------------|
| `Selection/checkbox.md` | Checkbox | Sélection multiple, formulaires |
| `Selection/radio-button.md` | Radio Button | Choix exclusif, ≤ 5 options |
| `Selection/switch.md` | Switch | Paramètre binaire à effet immédiat |
| `Selection/chips.md` | Chips (Assist · Filter · Input · Suggestion) | Filtres, tags, raccourcis |
| `Selection/sliders.md` | Sliders (Continuous + Discrete) | Valeurs dans une plage |
| `Selection/menus.md` | Menus (Dropdown + Context + Exposed) | Listes d'options contextuelles |
| `Selection/date-pickers.md` | Date Pickers (Modal + Docked + Range) | Sélection de dates |
| `Selection/time-pickers.md` | Time Pickers (Dial + Input) | Sélection d'heure |

### TextInput
| Fichier | Composant | Cas d'usage principal |
|---------|----------|----------------------|
| `TextInput/text-fields.md` | Text Fields (Filled + Outlined) | Saisie de texte formulaire |

✨ = Nouveau composant M3 Expressive (2024–2025)

---

## Référentiel des tokens système utilisés

### md-sys-shape (border-radius)
| Token | Valeur |
|-------|--------|
| `corner-none` | **0px** |
| `corner-extra-small` | **4px** |
| `corner-small` | **8px** |
| `corner-medium` | **12px** |
| `corner-large` | **16px** |
| `corner-extra-large` | **28px** |
| `corner-full` | **9999px** |

### md-sys-elevation (dp shadow)
| Token | Valeur |
|-------|--------|
| `level0` | **0dp** |
| `level1` | **1dp** |
| `level2` | **3dp** |
| `level3` | **6dp** |
| `level4` | **8dp** |
| `level5` | **12dp** |

### md-sys-color (rôles principaux)
| Rôle | Usage |
|------|-------|
| `primary` | Couleur d'action principale |
| `on-primary` | Texte/icône sur `primary` |
| `primary-container` | Surface moins proéminente (tonal) |
| `on-primary-container` | Texte/icône sur `primary-container` |
| `secondary-container` | Indicateurs d'activation (nav, chips, segmented) |
| `on-secondary-container` | Texte/icône sur `secondary-container` |
| `surface` | Fond de base des composants |
| `surface-container-low` | Cartes élevées, drawers |
| `surface-container` | Nav bar, menus |
| `surface-container-high` | Dialogs, date pickers |
| `surface-container-highest` | Text fields filled, checkboxes inactifs |
| `on-surface` | Texte principal sur surfaces |
| `on-surface-variant` | Texte secondaire, icônes inactives |
| `outline` | Bordures standard |
| `outline-variant` | Bordures subtiles, dividers |
| `error` | États d'erreur |
| `on-error` | Texte sur `error` |
| `inverse-surface` | Snackbar, tooltips (fond inversé) |
| `inverse-on-surface` | Texte sur `inverse-surface` |
| `inverse-primary` | Action snackbar |
| `scrim` | Overlay modal (à 0.32 opacity) |
