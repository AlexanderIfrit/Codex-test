---
source: https://m3.material.io/components/tooltips
category: Communication
spec-version: v0.192
---

# Tooltips — Heuristiques de décision

Variantes : Plain tooltip · Rich tooltip
Déclencheurs : hover (web/desktop), focus clavier, long-press (mobile)

---

## Tokens de design — valeurs de référence

### Plain Tooltip
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.inverse-surface` |
| `container-shape` | `corner-extra-small` → **4px** |
| `supporting-text-color` | `md-sys-color.inverse-on-surface` |
| `supporting-text-font` | `md-sys-typescale.body-small-font` |
| `supporting-text-size` | `md-sys-typescale.body-small-size` |
| Padding horizontal | **8px** |
| Padding vertical | **4px** |
| Max-width | **~200dp** |
| Délai d'apparition | **~500ms** après hover |

### Rich Tooltip
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container` |
| `container-shape` | `corner-medium` → **12px** |
| `container-elevation` | `level2` → **3dp** |
| `supporting-text-color` | `md-sys-color.on-surface-variant` |
| `supporting-text-font` | `md-sys-typescale.body-small` |
| `title-color` | `md-sys-color.on-surface` |
| `title-font` | `md-sys-typescale.title-small` |
| `action-label-text-color` | `md-sys-color.primary` |
| Max-width | **~320dp** |
| Padding | **12px** |

---

## H1 — Plain vs Rich tooltip : arbitrage par complexité

**Équation :** Préférence Rich Tooltip = Explication > 1 ligne (fort) + Lien ou action à fournir (fort) + Contenu pédagogique (modéré)

| Variante | Contenu | Usage |
|----------|---------|-------|
| Plain | 1 ligne, label court | Nommer une icône, expliquer un abréviation |
| Rich | Titre + description + action optionnelle | Expliquer un concept, guider une fonctionnalité |

---

## H2 — Quand utiliser un tooltip

- **Plain obligatoire** pour tout icon button sans label visible (accessibilité + discoverability)
- **Rich recommandé** pour les fonctionnalités avancées qui gagneraient d'une explication contextuelle
- **Ne pas dupliquer** le label d'un bouton qui est déjà visible → tooltip inutile

---

## H3 — Déclencheurs selon plateforme

| Plateforme | Déclencheur |
|------------|-------------|
| Web/Desktop | Hover + Focus clavier |
| Mobile | Long-press uniquement |
| Touch + pointeur | Les deux selon l'input |

- **Mobile :** éviter de mettre des informations **critiques** uniquement dans un tooltip (long-press souvent ignoré)
- Délai d'apparition : **500ms** après hover — assez long pour éviter les déclenchements accidentels

---

## H4 — Positionnement

- Position par défaut : **au-dessus** de l'élément
- Si pas d'espace : en-dessous, puis à gauche/droite
- Jamais masquer le contenu interactif par le tooltip
- Animation : fade-in rapide (~150ms), fade-out après ~1500ms

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Tooltip obligatoire sur tout icon button sans label
✅ **Do :** Plain pour du texte court, Rich pour des explications
✅ **Do :** Respecter le délai de 500ms
❌ **Don't :** Mettre d'informations critiques dans un tooltip mobile
❌ **Don't :** Dupliquer un label déjà visible

---

## Traduction en application concrète

**Toolbar d'éditeur (web) :** Plain tooltip sur chaque icon button (B → « Gras », I → « Italique »). Rich tooltip optionnel sur des fonctions complexes (« Styles de paragraphe ») avec lien vers l'aide.

**Spec (Plain) :** `background:var(--md-sys-color-inverse-surface)`, `color:var(--md-sys-color-inverse-on-surface)`, `border-radius:4px`, `padding:4px 8px`, `font:var(--md-sys-typescale-body-small)`, `max-width:200px`. Apparition après `500ms`, fade `150ms`.
