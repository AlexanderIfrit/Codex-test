---
source: https://m3.material.io/components/badges
category: Communication
spec-version: v0.192
---

# Badges — Heuristiques de décision

Variantes : Small badge (point) · Large badge (avec chiffre/label)
Se superpose à un autre composant (icon button, navigation item, avatar).

---

## Tokens de design — valeurs de référence

### Badge
| Token | Valeur |
|-------|--------|
| `color` (small) | `md-sys-color.error` |
| `shape` (small) | `corner-full` → **9999px** |
| `size` (small) | **6px × 6px** |
| `large-color` | `md-sys-color.error` |
| `large-label-text-color` | `md-sys-color.on-error` |
| `large-label-text-font` | `md-sys-typescale.label-small-font` |
| `large-label-text-size` | `md-sys-typescale.label-small-size` |
| `large-shape` | `corner-full` → **9999px** |
| `large-size` | **16px × 16px** (min-width) |
| Padding horizontal (large) | **4px** de chaque côté |
| Position par défaut | Coin supérieur droit du composant hôte |

---

## H1 — Small badge vs Large badge : arbitrage par information

**Équation :** Préférence Large Badge = Nombre ou label à communiquer (fort) + Contexte nécessitant un chiffre précis (fort)

| Variante | Contenu | Usage |
|----------|---------|-------|
| Small (6px) | Rien — signal de présence seul | « Il y a quelque chose de nouveau », sans quantification |
| Large (16px) | Chiffre (1–999+) ou texte court | Nombre de notifications non lues, nombre de messages |

**Zone de bascule :** Si le nombre dépasse 999, afficher `999+`. Si le nombre est 0, masquer le badge entièrement (ne pas afficher un badge vide ou à `0`).

---

## H2 — Couleur et signification

- Couleur par défaut : `error` (rouge) — signal d'alerte, attention requise
- Couleur alternative : selon contexte, certains systèmes utilisent `primary` ou `tertiary` pour signaler des nouveautés non-urgentes
- `error` implique toujours une action requise de l'utilisateur — s'assurer que c'est bien le cas

---

## H3 — Positionnement et superposition

- Position standard : coin supérieur **droit** de l'icône hôte, légèrement en dehors du bord
- Pour les navigation items : positionner sur l'icône, pas sur le label
- Le badge ne doit pas masquer l'icône complètement → ajuster le positionnement (`translate(-50%, -50%)` sur le coin)
- Ne pas utiliser sur des éléments sans zone d'icône claire

---

## H4 — Contenu du Large badge

- Chiffres : `1` → `999`, puis `999+`
- Labels courts : `new`, `!` — uniquement si le chiffre n'est pas connu
- `label-small-font` : petite taille, illisible si badge trop petit → toujours respecter le `large-size: 16px` minimum

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Masquer le badge quand le compteur est à 0
✅ **Do :** Utiliser `999+` pour les grands nombres
✅ **Do :** Positionner sur l'icône dans les navigation bars
❌ **Don't :** Afficher un badge `0` ou vide
❌ **Don't :** Utiliser la couleur `error` si aucune action urgente n'est requise

---

## Traduction en application concrète

**Navigation Bar :** Large badge sur l'icône Messages avec le nombre de messages non lus. Small badge sur l'icône Notifications si le nombre exact n'est pas important.

**Spec de remise :** Small : `width:6px`, `height:6px`, `border-radius:9999px`, `background:var(--md-sys-color-error)`. Large : `min-width:16px`, `height:16px`, `border-radius:9999px`, `background:var(--md-sys-color-error)`, `color:var(--md-sys-color-on-error)`, `font:var(--md-sys-typescale-label-small)`, `padding-inline:4px`.
