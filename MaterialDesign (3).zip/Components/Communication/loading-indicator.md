---
source: https://m3.material.io/components/loading-indicator
category: Communication
spec-version: v0.192
note: Nouveau composant M3 Expressive (2024-2025)
---

# Loading Indicator — Heuristiques de décision

Nouveau composant M3 Expressive : indicateur de chargement expressif avec animation enrichie, distinct du Circular Progress standard.

---

## Tokens de design — valeurs de référence

### Loading Indicator
| Token | Valeur |
|-------|--------|
| `active-indicator-color` | `md-sys-color.primary` |
| `container-size` | **48px** (standard) · **24px** (small) · **64px** (large) |
| `active-indicator-width` | **4px** (stroke) |
| `container-shape` | Circulaire (animation morphing) |
| Animation type | Morphing expressif (pas simple rotation) |
| `motion-duration` | `motion-duration-extra-long4` (~700–1000ms) |

---

## H1 — Loading Indicator vs Circular Progress

**Équation :** Préférence Loading Indicator = Contexte expressif grand public (fort) + Attente indéterminée (fort) + Style M3 Expressive activé (modéré)

| Composant | Quand l'utiliser |
|-----------|----------------|
| Circular Progress (standard) | Toutes les apps M3, contexts professionnels, chargements rapides |
| Loading Indicator (Expressive) | Apps grand public expressives, onboarding, états de chargement proéminents |

- Le Loading Indicator est **toujours indéterminé** — pas de variant déterminé (contrairement à Circular Progress)
- L'animation est plus élaborée (morphing, pas simple spin) → plus coûteuse visuellement — réserver aux moments qui méritent l'attention

---

## H2 — Tailles et contextes

| Taille | Container | Usage |
|--------|-----------|-------|
| Small | **24px** | Inline dans du texte, petits composants |
| Standard | **48px** | Par défaut |
| Large | **64px** | Hero screens, chargement de page principal |

---

## H3 — Animation et accessibilité

- Respecter `prefers-reduced-motion` : remplacer l'animation morphing par une animation simple (rotation ou fade) si la préférence est activée
- Toujours associer un `aria-label` ou un texte de chargement pour les lecteurs d'écran

---

## Traduction en application concrète

**Chargement de l'écran d'accueil (app expressive) :** Loading Indicator Large (64px) centré sur fond, animation morphing. Disparaît et laisse place au contenu.

**Spec de remise :** `width:48px`, `height:48px`, `stroke:var(--md-sys-color-primary)`, `stroke-width:4px`. Animation morphing M3 Expressive (SVG path animation), `duration:~800ms`, ease-in-out.
