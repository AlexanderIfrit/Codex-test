---
source: https://m3.material.io/components/progress-indicators
category: Communication
spec-version: v0.192
---

# Progress Indicators — Heuristiques de décision

Variantes : Linear progress · Circular progress
Types : Determinate (progression connue, 0–100%) · Indeterminate (durée inconnue)

---

## Tokens de design — valeurs de référence

### Linear Progress Indicator
| Token | Valeur |
|-------|--------|
| `active-track-color` | `md-sys-color.primary` |
| `track-color` (inactive) | `md-sys-color.surface-container-highest` |
| `track-height` | **4px** |
| `track-shape` | `corner-full` → **9999px** |
| `stop-indicator-color` | `md-sys-color.primary` |
| `stop-indicator-shape` | `corner-full` |
| `stop-indicator-size` | **4px** |
| `four-color-*` | Primary, secondary, tertiary, error (mode multi-couleur) |
| `indeterminate-duration` | **~2000ms** |

### Circular Progress Indicator
| Token | Valeur |
|-------|--------|
| `active-indicator-color` | `md-sys-color.primary` |
| `inactive-indicator-color` | `md-sys-color.surface-container-highest` |
| `active-indicator-width` | **4px** (stroke-width) |
| `size` | **48px** (standard) |
| `container-size` | **48px** |
| `four-color-active-indicator-one-color` | `md-sys-color.primary` |
| `four-color-active-indicator-two-color` | `md-sys-color.primary-container` |
| `four-color-active-indicator-three-color` | `md-sys-color.tertiary` |
| `four-color-active-indicator-four-color` | `md-sys-color.tertiary-container` |

---

## H1 — Linear vs Circular : arbitrage par contexte

**Équation :** Préférence Circular = Espace limité (fort) + Chargement d'un composant isolé (fort)
**Équation :** Préférence Linear = Chargement de page entière (fort) + Processus séquentiel linéaire (modéré)

| Composant | Usage typique |
|-----------|--------------|
| Linear | Barre de chargement d'une page, téléchargement de fichier, progression d'un formulaire multi-étapes |
| Circular | Chargement d'un composant, spinner dans un bouton, chargement d'image |

---

## H2 — Determinate vs Indeterminate

**Determinate :**
- Progression connue (0–100%) — utiliser quand on peut mesurer l'avancement réel
- L'utilisateur comprend combien de temps il reste → réduit l'anxiété d'attente
- Exemples : upload de fichier (progress = bytes envoyés / total), étapes d'installation

**Indeterminate :**
- Durée inconnue — utiliser pour les requêtes réseau de durée variable, les initialisations
- Animation continue en boucle
- **Ne pas utiliser si l'attente dépasse ~10s** → informer l'utilisateur autrement (skeleton screens, message d'état)

---

## H3 — Mode 4 couleurs

- Uniquement pour les indicateurs indéterminés (pas de sens avec un progress déterminé)
- Utilise primary, secondary, tertiary en rotation sur l'indicateur actif
- Style expressif — réserver aux applications grand public, éviter dans les contextes professionnels sévères

---

## H4 — Hauteur/Épaisseur de track

- Linear : track-height standard **4px** — ne pas modifier sans raison forte
- Circular : stroke-width **4px**, taille container **48px** — peut être réduit à 24–32px pour les spinners inline (boutons, cells)

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Utiliser Determinate si la progression est mesurable
✅ **Do :** Circular pour les composants isolés, Linear pour les pages
✅ **Do :** Masquer le progress indicator une fois terminé
❌ **Don't :** Laisser un progress indicator indéterminé > 10s sans information complémentaire
❌ **Don't :** Utiliser les deux variantes simultanément pour le même processus

---

## Traduction en application concrète

**Upload de fichier :** Linear Determinate, `height:4px`, `background:surface-container-highest`, `fill:primary`. Chiffre optionnel `67 %` à côté.

**Chargement initial d'une page :** Linear Indeterminate en haut de l'écran, `height:4px`, disparaît à la fin du load.

**Spec de remise (Circular Indeterminate) :** `width:48px`, `height:48px`, `stroke-width:4px`, `stroke:var(--md-sys-color-primary)`, animation rotation `2000ms` linear infinite.
