---
source: https://m3.material.io/components/snackbar
category: Communication
spec-version: v0.192
---

# Snackbar — Heuristiques de décision

Principe : feedback bref et non-bloquant sur un processus applicatif. Apparaît en bas de l'écran, disparaît automatiquement.

---

## Tokens de design — valeurs de référence

### Snackbar
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.inverse-surface` |
| `container-elevation` | `level3` → **6dp** |
| `container-shape` | `corner-extra-small` → **4px** |
| `supporting-text-color` | `md-sys-color.inverse-on-surface` |
| `supporting-text-font` | `md-sys-typescale.body-medium-font` |
| `action-label-text-color` | `md-sys-color.inverse-primary` |
| `action-label-text-font` | `md-sys-typescale.label-large-font` |
| `action-focus-state-layer-color` | `md-sys-color.inverse-primary` |
| `icon-color` | `md-sys-color.inverse-on-surface` |
| `icon-action-color` | `md-sys-color.inverse-primary` |

### Mesures
| Zone | Valeur |
|------|--------|
| Container height (1 ligne) | **48px** |
| Container height (2 lignes) | **68px** |
| Padding horizontal | **16px** |
| Padding vertical | **14px** (1 ligne) |
| Max-width | **~600px** (tablette+) |
| Min-width | **~344px** (mobile) |
| Durée d'affichage recommandée | **4 000ms** (courte) – **10 000ms** (longue) |
| Action label max | **1 mot, 10 caractères max** |

---

## H1 — Snackbar vs Dialog vs Toast

**Équation :** Pertinence Snackbar = Importance faible–moyenne (fort) + Pas d'action obligatoire (fort) + Message bref (fort) + Disparition automatique acceptable (fort)

| Composant | Importance | Action requise | Persistence |
|-----------|-----------|---------------|-------------|
| Snackbar | Faible–Moyenne | Optionnelle | Auto-dismiss |
| Dialog | Haute | Obligatoire | Persiste jusqu'à action |
| Bottom Sheet | Moyenne | Optionnelle | Jusqu'à dismiss |

**Zone de bascule :** Si l'action dans le snackbar est critique et que l'utilisateur ne peut pas manquer → Dialog. Si l'information est purement informative sans action → Snackbar sans bouton. Si l'information doit persister → Banner ou notification persistante.

---

## H2 — Contenu : texte et action optionnelle

**Message (supporting text) :**
- **1–2 lignes maximum** — phrase courte, descriptive de ce qui s'est passé
- Exemples : « Message envoyé », « Fichier supprimé », « Modifications enregistrées »
- Pas de titre (headline) dans un snackbar

**Action optionnelle (1 seule) :**
- Text button en `inverse-primary` (couleur inversée par rapport au fond sombre)
- Label court : max 1 mot ou 2 mots courts — « Annuler », « Afficher », « OK »
- **1 action maximum** — si 2 actions nécessaires → Dialog
- Action dans la même ligne (1 ligne de texte) ou dessous (2 lignes)

**Icône de fermeture optionnelle :**
- Icon button `close` en `inverse-on-surface` — pour les snackbars de longue durée

---

## H3 — Couleur inversée : pourquoi

- `inverse-surface` (généralement sombre en light mode) → contraste élevé avec le fond clair de l'app
- `inverse-on-surface` pour le texte, `inverse-primary` pour l'action → harmonie avec la couleur inversée
- Ne pas modifier ces couleurs — elles garantissent la lisibilité sur n'importe quelle surface

---

## H4 — Position et comportement

- **Position :** bas de l'écran, centré horizontalement sur mobile, aligné à gauche sur tablette/desktop
- **Durée :** 4s pour les messages courts, jusqu'à 10s pour les messages nécessitant une action
- **Queue :** afficher un seul snackbar à la fois — mettre en queue si plusieurs arrivent simultanément
- **Dismiss :** swipe latéral ou auto-dismiss après le délai

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** 1–2 lignes de texte maximum
✅ **Do :** Une seule action optionnelle (Text button)
✅ **Do :** Auto-dismiss après 4–10s
❌ **Don't :** Afficher plusieurs snackbars simultanément
❌ **Don't :** Utiliser pour des messages critiques → Dialog
❌ **Don't :** Label d'action > 2 mots

---

## Traduction en application concrète

**Suppression avec annulation :** `« Fichier supprimé »` + bouton `Annuler` en `inverse-primary`. Auto-dismiss 5s. Si `Annuler` est cliqué, restaurer le fichier.

**Spec de remise :** `background:var(--md-sys-color-inverse-surface)`, `color:var(--md-sys-color-inverse-on-surface)`, `border-radius:4px`, `box-shadow:elevation-level3`, `padding:14px 16px`, `min-width:344px`, `max-width:600px`, `font:var(--md-sys-typescale-body-medium)`.
