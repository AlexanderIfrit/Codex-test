---
source: https://m3.material.io/components/split-button
category: Action
spec-version: v0.192
note: Nouveau composant M3 Expressive (2024-2025)
---

# Split Button — Heuristiques de décision

Anatomie : Bouton principal (action primaire, clic direct) + Bouton dropdown `▼` (variantes) — visuellement réunis en une unité.

---

## Tokens de design — valeurs de référence

### Split Button
| Token | Valeur |
|-------|--------|
| `container-height` | Même que le Button individuel correspondant (ex : **40px** pour M) |
| `container-shape` | `corner-full` → **9999px** (round) ou `corner-extra-small` → **4px** (square) |
| `divider-color` | `md-sys-color.outline` ou dérivé de `on-primary` selon variante |
| `divider-width` | **1px** vertical entre les deux zones |
| `dropdown-icon-size` | **18px** (chevron `▼`) |
| `dropdown-zone-width` | **~40px** |
| Tailles disponibles | **XS, S, M, L, XL** |
| Formes disponibles | Round (`corner-full`) · Square (`corner-extra-small`) |
| Variantes de couleur | Elevated · Filled · Tonal · Outlined · Text (même que boutons standards) |

### Dropdown Menu associé
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container` |
| `container-elevation` | `level2` → **3dp** |
| `container-shape` | `corner-extra-small` → **4px** |
| `list-item-label-text-color` | `md-sys-color.on-surface` |
| Items recommandés | **3 à 7** items |

---

## H1 — Quand utiliser un Split Button

**Équation :** Pertinence Split Button = Action principale très fréquente (fort) + Actions variantes moins fréquentes mais liées (fort) + Espace suffisant pour deux zones cliquables (modéré)

- Utiliser quand une action principale est réalisée dans **70–90 % des cas** mais que des variantes existent
  (ex : « Enregistrer » + dropdown [« Enregistrer sous… », « Exporter », « Dupliquer »])
- Côté gauche : exécute l'action **immédiatement** (pas de menu)
- Côté droit `▼` : ouvre le **menu de variantes** uniquement

**Zone de bascule :** Si toutes les variantes ont la même fréquence → Button Group ou Menu exposé. Si une seule action existe → Button standard. Si les items du dropdown sont des actions différentes (non-variantes) → Menu séparé.

---

## H2 — Cohérence visuelle du split

- Les deux parties (action + dropdown) : **même variante** (filled/tonal/outlined) et **même taille**
- Séparateur `1px` vertical — subtil, ne doit pas rendre les deux zones indépendantes visuellement
- Le chevron `▼` est **toujours à droite**, label/icône de l'action à gauche
- Forme identique des deux côtés — ne pas arrondir un côté différemment de l'autre

---

## H3 — Contenu du dropdown

- Liste les **variantes** de l'action principale uniquement — pas d'actions non-liées
- **3 à 7 items** maximum dans le dropdown
- Option : mémoriser la dernière action exécutée et la promouvoir en action principale par défaut (optionnel, pattern « last used »)

---

## H4 — Contextes recommandés

- Interfaces desktop/expanded (tablette, web, fenêtre large)
- Éditeurs, outils de productivité, gestionnaires de fichiers
- Workflows avec plusieurs modes d'export, d'envoi, ou d'enregistrement
- Rare sur mobile compact → préférer FAB + Bottom Sheet dans ce cas

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Action principale dans 70–90 % des cas + variantes dans le dropdown
✅ **Do :** Même variante et même taille pour les deux zones
✅ **Do :** 3–7 items dans le dropdown
❌ **Don't :** Mettre des actions non-liées dans le dropdown → Menu séparé
❌ **Don't :** Utiliser sur mobile compact → FAB + Bottom Sheet
❌ **Don't :** Dropdown avec une seule option → Extended FAB ou Button direct

---

## Traduction en application concrète

**Pour une app de fichiers/documents :** Split Button Filled `« Partager ▼ »` avec dropdown [« Copier le lien », « Partager par email », « Exporter en PDF »] — toutes des variantes de l'action « Partager ».

**Spec de remise (Filled M) :** `height:40px`, `border-radius:9999px`, `background:var(--md-sys-color-primary)`. Divider : `width:1px`, `color:var(--md-sys-color-on-primary)` à `0.38 opacity`. Zone dropdown : `~40px` de large. Chevron : `18px`.
