---
source: https://m3.material.io/components/icon-buttons
category: Action
spec-version: v0.192
---

# Icon Buttons — Heuristiques de décision

Variantes : Standard · Outlined · Filled · Filled Tonal
Modes : Default (action ponctuelle) | Toggle (état binaire persistant)

---

## Tokens de design — valeurs de référence

### Filled Icon Button
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.primary` |
| `container-shape` | `corner-full` → **9999px** |
| `container-size` | **40px** × **40px** |
| `icon-color` | `md-sys-color.on-primary` |
| `icon-size` | **24px** |
| `selected-container-color` | `md-sys-color.primary` |
| `unselected-container-color` | `md-sys-color.surface-container-highest` |
| `hover-container-elevation` | `level1` → **1dp** |
| `disabled-container-opacity` | **0.12** |
| `disabled-icon-opacity` | **0.38** |

### Tonal Icon Button
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.secondary-container` |
| `icon-color` | `md-sys-color.on-secondary-container` |
| `container-size` | **40px** × **40px** |

### Outlined Icon Button
| Token | Valeur |
|-------|--------|
| `container-color` | transparent |
| `outline-color` | `md-sys-color.outline` |
| `outline-width` | **1px** |
| `container-shape` | `corner-full` → **9999px** |
| `icon-color` | `md-sys-color.on-surface-variant` |
| `selected-container-color` | `md-sys-color.inverse-surface` |
| `selected-icon-color` | `md-sys-color.inverse-on-surface` |

### Standard Icon Button
| Token | Valeur |
|-------|--------|
| `container-color` | transparent |
| `icon-color` | `md-sys-color.on-surface-variant` |
| `selected-icon-color` | `md-sys-color.primary` |
| `icon-size` | **24px** |

### Zone de touche minimale (accessibility)
- Zone tactile minimum : **48dp × 48dp** même si le conteneur visuel est 40px
- C'est la taille de la zone interactive, pas du container visible

---

## H1 — Icône seule vs bouton avec label : arbitrage fondamental

**Équation :** Pertinence du Icon Button = Reconnaissance universelle de l'icône (fort) + Contrainte d'espace (modéré) + Familiarité du contexte (modéré)

- Utiliser un Icon Button UNIQUEMENT si l'icône est reconnaissable sans label dans le contexte
  (✉️ mail, ♥ favori, 🗑 supprimer, ✕ fermer, ⋮ plus d'options, ↩ retour)
- Si un doute subsiste sur la signification → ajouter un label (Button) ou un tooltip obligatoire
- Toujours fournir un `content description` / `aria-label` pour l'accessibilité

**Zone de bascule :** Dans les applications grand public non-expert, préférer le Button avec label dès que l'action n'est pas dans les 5–7 icônes universelles connues.

---

## H2 — Choisir la variante selon le contexte de surface

**Équation :** Variante appropriée = Importance de l'action (fort) + Fond de la surface (modéré) + Densité visuelle (faible)

| Variante | Emphase | Usage typique |
|----------|---------|--------------|
| Filled | Maximale | Action primaire dans un groupe, send dans chat |
| Tonal | Forte | Action importante mais pas dominante |
| Outlined | Modérée | Actions secondaires nécessitant une délimitation |
| Standard | Minimale | App bar, toolbar, actions tertiaires sur surfaces variées |

---

## H3 — Mode Toggle : signaler l'état clairement

**Équation :** Clarté du toggle = Changement couleur container (fort) + Changement icône (modéré) — ne pas reposer sur la couleur seule

- Standard toggle : `icon-color` passe de `on-surface-variant` → `primary` (selected)
- Outlined toggle : container passe de transparent → `inverse-surface` ; icône de `on-surface-variant` → `inverse-on-surface`
- Filled toggle : container passe de `surface-container-highest` → `primary`
- Préférer icônes paires sémantiques (♥ outlined off / ♥ filled on) pour double signal visuel

---

## H4 — Groupement et espacement dans les barres

- Dans une app bar ou toolbar : espacement entre icon buttons = **8px** minimum
- Au-delà de 3–4 icon buttons dans une barre → regrouper le surplus dans un menu overflow (`⋮`)
- Ne pas mélanger tailles d'icônes dans un même groupe (tout en 24px ou tout en 20px)
- Button Groups (M3 Expressive) pour les groupes d'icon buttons avec interaction inter-boutons

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Utiliser les icon buttons pour des actions communes reconnues universellement
✅ **Do :** Placer les icon buttons dans app bars, toolbars, cards
✅ **Do :** Grouper avec Button Groups pour ajouter de l'interaction entre boutons adjacents
❌ **Don't :** Utiliser un icon button pour des actions complexes ou ambiguës sans tooltip
❌ **Don't :** Ignorer l'accessibilité — `aria-label` obligatoire sur tout icon button

---

## Traduction en application concrète

**Pour auditer :** Si un icon button est pressé par un utilisateur test qui hésite → icône non universelle → ajouter tooltip ou remplacer par Button avec label.

**Spec de remise :** Container : `width:40px`, `height:40px`, `border-radius:9999px`. Zone tactile : `min-width:48px`, `min-height:48px` (padding transparent). Icône : `24px`, couleur selon variante.

**Pour les app bars :** 1–3 icon buttons maximum visibles. Actions supplémentaires → `⋮` overflow menu. Icon buttons Standard (`on-surface-variant`) par défaut, Filled ou Tonal pour l'action la plus importante seulement.
