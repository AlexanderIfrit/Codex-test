---
source: https://m3.material.io/components/extended-fab
category: Action
spec-version: v0.192
updated: M3 Expressive (3 tailles : Small, Medium, Large)
---

# Extended FABs — Heuristiques de décision

Anatomie : Icône (optionnelle, leading) + Label texte obligatoire, dans un conteneur de forme `corner-large`.

---

## Tokens de design — valeurs de référence

### Extended FAB Primary
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.primary-container` |
| `container-elevation` | `level3` → **6dp** |
| `container-shape` | `corner-large` → **16px** |
| `container-height` | **56px** (medium) |
| `icon-color` | `md-sys-color.on-primary-container` |
| `icon-size` | **24px** |
| `label-text-color` | `md-sys-color.on-primary-container` |
| `label-text-font` | `md-sys-typescale.label-large` |
| `hover-container-elevation` | `level4` → **8dp** |
| `focus-container-elevation` | `level3` → **6dp** |
| `pressed-container-elevation` | `level3` → **6dp** |
| `lowered-container-elevation` | `level1` → **1dp** |
| `lowered-hover-container-elevation` | `level2` → **3dp** |

### Tailles (M3 Expressive)
| Taille | Height | Icon size | Padding latéral |
|--------|--------|-----------|----------------|
| Small | **40px** | 20px | 16px |
| Medium ⭐ | **56px** | 24px | 20px |
| Large | **96px** | 36px | 32px |

---

## H1 — Extended FAB vs FAB : arbitrage par clarté de l'action

**Équation :** Préférence Extended FAB = Ambiguïté de l'icône seule (fort) + Importance de guider l'utilisateur (modéré) + Espace disponible horizontal (faible)

- Utiliser l'Extended FAB quand le label textuel rend l'action immédiatement compréhensible sans mémoriser l'icône
- Privilégier en onboarding, état vide (empty state), ou nouvel écran où l'utilisateur ne sait pas encore quoi faire
- Sur les surfaces larges (tablette, desktop), l'Extended FAB est préféré au FAB car son poids visuel est proportionnel à l'espace disponible

**Zone de bascule :** Si l'utilisateur connaît déjà l'application et l'icône (ex : compose dans Gmail), revenir au FAB simple pour économiser l'espace horizontal. L'Extended FAB est une aide à la **découvrabilité**.

---

## H2 — Tailles et hiérarchie visuelle

**Équation :** Taille Extended FAB = Largeur de fenêtre (fort) + Importance de l'action dans le layout (modéré) + Phase du parcours utilisateur (modéré)

- **Small (40px) :** contextes compacts, layouts chargés
- **Medium (56px) ⭐ :** par défaut, la plus polyvalente
- **Large (96px) :** hero screen, empty state, premiers pas dans une app — quand l'action doit occuper de l'espace

---

## H3 — Comportement au scroll

- L'Extended FAB **peut se rétracter** en FAB icône seule lors du scroll vers le bas (économie d'espace)
- Il **se ré-étend** au scroll vers le haut ou à l'arrêt
- Ce comportement doit être cohérent dans toute l'app — pas d'alternance entre pages qui rétractent et pages qui ne rétractent pas sans justification

---

## H4 — Contenu et label

- Label en sentence case, **1–3 mots maximum**
- Icône leading optionnelle — si présente, renforce le label sans le dupliquer visuellement
- Label > 3 mots : reformuler ou reconsidérer si l'action est assez simple pour un FAB
- Espacement icône→label : `icon-label-space` → **12px** (Medium)

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Utiliser pour l'action la plus commune ou la plus importante de l'écran
✅ **Do :** Utiliser quand le label aide à comprendre l'action
✅ **Do :** Utiliser Small/Large pour adapter à la taille de fenêtre
❌ **Don't :** Utiliser un label trop long (> 3 mots)
❌ **Don't :** Omettre l'icône si l'espace le permet — elle aide la reconnaissance

---

## Traduction en application concrète

**Pour les états vides :** Extended FAB Large centré sur la surface vide est le pattern idéal. Ex : `+ Créer un projet` en Large sur une liste vide.

**Pour l'adaptive design :**
- Compact window → Extended FAB Medium (56px) en bas à droite
- Expanded window → Extended FAB Large (96px) dans la Nav Rail ou sidebar

**Spec de remise (Medium) :** `height:56px`, `border-radius:16px`, `background:var(--md-sys-color-primary-container)`, `padding-inline:20px`, `font:var(--md-sys-typescale-label-large)`, icône `24px`.
