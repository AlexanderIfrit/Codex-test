---
source: https://m3.material.io/components/fab-menu
category: Action
spec-version: v0.192
note: Nouveau composant M3 Expressive (2024-2025)
---

# FAB Menu — Heuristiques de décision

Principe : un FAB principal qui, à l'appui, révèle un menu de **2 à 5 sous-actions** (Extended FABs ou Icon Buttons) en cascade vers le haut.

---

## Tokens de design — valeurs de référence

### FAB Menu
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.primary-container` (FAB principal) |
| `container-elevation-closed` | `level3` → **6dp** |
| `container-elevation-open` | `level3` → **6dp** (inchangé) |
| `container-shape` | `corner-large` → **16px** (Medium FAB) |
| Espacement vertical entre sous-actions | **8px** |
| Scrim (overlay fond) | `md-sys-color.scrim` à opacité **0.32** (optionnel) |
| Animation ouverture | Staggered reveal, bottom→top, `motion-duration-medium2` (~300ms) |
| Animation fermeture | Collapse top→bottom |

### Sous-actions (Extended FABs recommandés)
| Élément | Token / Valeur |
|---------|---------------|
| Container height | **56px** (Medium Extended FAB) ou **40px** (Small) |
| Container shape | `corner-large` → **16px** |
| Container color | `md-sys-color.primary-container` ou `secondary-container` |
| Icon size | **24px** |
| Label font | `md-sys-typescale.label-large` |

---

## H1 — Quand utiliser FAB Menu vs FAB seul vs actions séparées

**Équation :** Pertinence FAB Menu = Nombre d'actions primaires liées (fort) + Fréquence d'utilisation des sous-actions (modéré) + Contrainte d'espace (modéré)

- Utiliser FAB Menu quand il y a **2 à 5** actions primaires liées par un même thème
  (ex : « Créer » qui ouvre → Document, Feuille, Présentation, Formulaire)
- Ne pas utiliser pour plus de 5 sous-actions → passer à un Bottom Sheet ou Dialog
- Les sous-actions doivent être liées sémantiquement — même verbe parent possible pour chacune

**Zone de bascule :** Si une seule sous-action est utilisée dans > 70 % des cas, la promouvoir en FAB principal direct et rétrograder les autres en actions secondaires.

---

## H2 — Comportement d'ouverture / fermeture

- FAB parent : icône change à l'ouverture (ex : `+` → `×`) → signale l'état ouvert et permet la fermeture
- Sous-actions : apparaissent en **cascade** au-dessus du FAB, avec staggered animation (haut en dernier, bas en premier)
- Fermeture : tap sur overlay (scrim), tap sur `×`, swipe, ou navigation
- Scrim optionnel (`opacity:0.32`) pour focaliser sur le menu — recommandé si le fond est complexe

---

## H3 — Sous-actions : Extended FABs ou Icon Buttons

- **Extended FABs avec labels :** quand les sous-actions peuvent être inconnues de l'utilisateur ou dans les premiers jours d'usage
- **Icon Buttons :** quand l'interface est connue et l'espace est contraint
- Mélanger les deux dans un même FAB Menu : **déconseillé** — choisir un style uniforme

---

## H4 — Nombre et placement des sous-actions

- Minimum : **2** sous-actions (sinon, Extended FAB direct)
- Maximum recommandé : **5** sous-actions
- Disposition : **verticale uniquement**, du bas vers le haut
- S'assurer que les sous-actions ne sont pas masquées par la Navigation Bar → décaler le FAB si nécessaire

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Grouper 2–5 actions liées sémantiquement
✅ **Do :** Changer l'icône du FAB principal à l'ouverture (signal d'état)
✅ **Do :** Fermer au tap sur l'overlay ou à la navigation
❌ **Don't :** Utiliser pour une seule sous-action → Extended FAB direct
❌ **Don't :** Dépasser 5 sous-actions → Bottom Sheet
❌ **Don't :** Grouper des actions sans relation sémantique

---

## Traduction en application concrète

**Pour une app de création :** FAB Menu idéal pour « Nouveau… » déclinant en types : Document, Feuille, Présentation. Extended FABs Small avec icône + label pour chaque sous-action.

**Spec de remise :** FAB principal : `56px × 56px`, `border-radius:16px`, icône change au tap. Sous-actions en Extended FABs Small `40px`, `border-radius:16px`, gap vertical `8px`. Animation staggered `~300ms`. Scrim optionnel `rgba(0,0,0,0.32)`.
