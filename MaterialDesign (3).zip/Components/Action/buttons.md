---
source: https://m3.material.io/components/buttons
category: Action
spec-version: v0.192
---

# Buttons — Heuristiques de décision

Variantes M3 : Elevated · Filled · Filled Tonal · Outlined · Text
Modes : Default (action ponctuelle) | Toggle (état binaire persistant)
Tailles : XS · S · M · L · XL — Formes : Round (corner-full) | Square (corner-extra-small)

---

## Tokens de design — valeurs de référence

### Filled Button
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.primary` |
| `container-height` | **40px** |
| `container-shape` | `corner-full` → **9999px** |
| `container-elevation` | `level0` → **0dp** |
| `hover-container-elevation` | `level1` → **1dp** |
| `label-text-color` | `md-sys-color.on-primary` |
| `label-text-font` | `md-sys-typescale.label-large` |
| `disabled-container-opacity` | **0.12** |
| `disabled-label-text-opacity` | **0.38** |
| `leading-space` | **24px** |
| `trailing-space` | **24px** |
| `with-leading-icon-leading-space` | **16px** |

### Elevated Button
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-low` |
| `container-elevation` | `level1` → **1dp** |
| `hover-container-elevation` | `level2` → **3dp** |
| `container-shape` | `corner-full` → **9999px** |
| `label-text-color` | `md-sys-color.primary` |

### Outlined Button
| Token | Valeur |
|-------|--------|
| `container-color` | transparent |
| `container-elevation` | `level0` → **0dp** |
| `outline-color` | `md-sys-color.outline` |
| `outline-width` | **1px** |
| `container-shape` | `corner-full` → **9999px** |
| `label-text-color` | `md-sys-color.primary` |

### Text Button
| Token | Valeur |
|-------|--------|
| `container-color` | transparent |
| `container-elevation` | `level0` |
| `label-text-color` | `md-sys-color.primary` |
| `leading-space` | **12px** |
| `trailing-space` | **12px** |

### Filled Tonal Button
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.secondary-container` |
| `label-text-color` | `md-sys-color.on-secondary-container` |
| `container-height` | **40px** |
| `container-shape` | `corner-full` → **9999px** |

### Tailles (M3 Expressive)
| Taille | container-height |
|--------|----------------|
| XS | ~28px |
| S | ~32px |
| M | **40px** (défaut) |
| L | ~48px |
| XL | ~56px |

---

## H1 — Choisir la variante selon l'emphase requise

**Équation :** Emphase visuelle ∝ Remplissage fond (fort) + Couleur primaire (fort) + Élévation (modéré)

| Variante | Emphase | Quand l'utiliser |
|----------|---------|-----------------|
| Filled | Maximale | Action principale unique, chemin critique (Confirmer, Envoyer, Payer) |
| Filled Tonal | Forte | Action secondaire importante ; alternative au Filled sans hiérarchie unique |
| Elevated | Modérée | Actions sur surfaces colorées, légère séparation visuelle requise |
| Outlined | Faible | Actions alternatives, de moindre importance que le Filled présent |
| Text | Minimale | Tertiaires, navigation dans des dialogues, actions répétées dans des listes |

**Zone de bascule :** Si deux actions ont le même poids (« Annuler / Confirmer »), différencier : Filled pour l'action primaire, Outlined ou Text pour la secondaire. Ne jamais mettre deux Filled au même niveau de hiérarchie.

**Raison généralisable :** L'œil suit la hiérarchie chromatique avant la position. Un Filled à `md-sys-color.primary` attire l'attention mécaniquement — le réserver à l'action réalisée dans 80 %+ des cas.

---

## H2 — Taille et forme comme signal d'importance contextuelle

**Équation :** Importance contextuelle = Taille (fort) × Densité d'autres boutons (modéré) + Largeur de fenêtre (faible)

- XS–S (28–32px) : zones denses, tableaux, listes d'actions secondaires
- M (40px) : taille par défaut — standard
- L–XL (48–56px) : hero moments, onboarding, actions isolées sur grande surface
- `corner-full` (9999px) : forme par défaut, neutre, fluide
- `corner-extra-small` (4px) : structure, productivité, contextes éditoriaux — forme carré

**Zone de bascule :** Un seul bouton L–XL par vue maximum. Si plusieurs actions réclament de la visibilité, utiliser Button Groups plutôt que multiplier les grands boutons.

---

## H3 — Icônes optionnelles : quand ajouter, quand supprimer

**Équation :** Valeur de l'icône = Clarté ajoutée (fort) − Bruit visuel (modéré)

- Ajouter une icône leading si l'action est ambiguë sans elle ou en contexte multilingue
- Quand icône présente : `with-leading-icon-leading-space` → **16px** (vs 24px sans icône)
- Taille d'icône standard : **18px** dans les boutons standards, **20px** dans les XL
- Ne pas ajouter d'icône si le label est déjà 100 % clair — l'icône décore sans informer

---

## H4 — Toggle buttons : signaler l'état clairement

- État selected : changement de `container-color` + forme `corner-full` → `corner-small` ou inverse
- Préférer icônes paires (♥ outlined unselected / ♥ filled selected)
- Ne pas modifier dramatiquement la longueur du label entre états selected/unselected — perturbatif pour le layout
- `label-text-color` selected : `md-sys-color.on-secondary-container` (tonal) ou `on-primary` (filled)

---

## H5 — Labels : concision et sentence case obligatoires

**Règle forte :** Max 2–3 mots pour un label. Sentence case (1ère lettre maj, reste minuscule).
- Ne pas tronquer le container sur le label — la largeur s'adapte dynamiquement au texte
- Le container peut être responsive (s'étirer à pleine largeur sur mobile) ou compact (fit-content)

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Utiliser les boutons pour des actions discrètes
✅ **Do :** La largeur du container s'adapte dynamiquement au label
✅ **Do :** Rendre le container responsive (pleine largeur) sur mobile si besoin
❌ **Don't :** Surcharger l'UI avec trop de boutons — utiliser un menu overflow ou des icon buttons
❌ **Don't :** Rendre le container plus étroit que son label
❌ **Don't :** Modifier drastiquement la longueur du label entre les états d'un toggle

---

## Traduction en application concrète

**Choix de variante :** Identifier l'action la plus importante → Filled. Toutes les autres descendent d'un cran. S'il n'y a qu'une seule action possible, Filled Tonal ou Outlined suffisent.

**Audit d'une interface existante :** Compter les Filled visibles simultanément. Plus d'un = problème de hiérarchie. Des Text buttons répétés dans des listes sont préférables à des Outlined répétés.

**Spec de remise :** Pour un bouton Filled standard : `height:40px`, `border-radius:9999px`, `background:var(--md-sys-color-primary)`, `color:var(--md-sys-color-on-primary)`, `font:var(--md-sys-typescale-label-large)`, `padding-inline:24px`.
