---
source: https://m3.material.io/components/button-groups
category: Action
spec-version: v0.192
note: Nouveau composant M3 Expressive (2024-2025)
---

# Button Groups — Heuristiques de décision

Variantes : Standard (interaction inter-boutons dynamique) · Connected (groupe fusionné visuellement)
Principe clé : les boutons d'un groupe **réagissent les uns aux autres** lors de la sélection.

---

## Tokens de design — valeurs de référence

### Button Group — General
| Token | Valeur |
|-------|--------|
| Espacement inter-boutons (Standard) | **4px** |
| Espacement inter-boutons (Connected) | **0px** — joints |
| Taille par défaut des boutons | **M (40px)** |
| Tailles disponibles | **XS, S, M, L, XL** (même que boutons individuels) |
| Formes disponibles | Round (`corner-full`) · Square (`corner-extra-small`) |
| Forme par défaut | Même forme pour tous les boutons du groupe |
| Shape du bouton sélectionné | Peut changer momentanément lors de la sélection |

### Animation d'interaction (Standard Button Group)
- Bouton sélectionné : change de **forme** et de **largeur**
- Boutons adjacents : se déplacent et changent temporairement de largeur
- Toggle selected : change aussi de **couleur** (`secondary-container` ou `primary`)
- Durée de l'animation : dans les plages de `motion-duration-medium2` (~300ms)

---

## H1 — Quand utiliser Button Groups vs boutons individuels

**Équation :** Pertinence d'un Button Group = Relation sémantique entre actions (fort) + Bénéfice interactions inter-boutons (fort) + Besoin d'expressivité hero (modéré)

- Utiliser quand les actions sont **liées** et que leur regroupement communique cette relation (ex : Gras / Italique / Souligné dans un éditeur)
- Le Standard Button Group ajoute une animation d'interaction → signal visuel de relation entre boutons
- Ne pas utiliser pour des actions sans relation entre elles → utiliser des boutons individuels séparés

**Zone de bascule :** Si les boutons ont des hiérarchies très différentes (un primaire + des secondaires), préférer un Split Button. Si c'est uniquement pour la sélection d'une option → Segmented Button.

---

## H2 — Standard vs Connected

**Standard :** Boutons visuellement séparés (gap 4px) mais avec animation d'interaction dynamique.
→ Usage : sélection multiple, toggle, formatage, hero screens expressifs.

**Connected :** Boutons visuellement fusionnés (gap 0px), forment une unité.
→ Usage : sélection exclusive d'une seule option (radio-like), navigation inter-vues compacte.

**Zone de bascule :** Sélection multiple simultanée → Standard. Sélection exclusive → Connected (ou Segmented Button si plus approprié).

---

## H3 — Cohérence de forme et de taille dans le groupe

**Règle forte :** Même taille (XS–XL) et même forme (round/square) pour tous les boutons du groupe par défaut.

Exceptions admises :
- Taille différente pour un bouton sélectionné lors de **hero moments uniquement**
- Forme différente pour signaler une sélection active ou ajouter du contraste sémantique ponctuel
- `"Only use multiple sizes in a group for hero moments"` (guideline officielle)
- `"Avoid mixing sizes frequently"` (guideline officielle)

---

## H4 — Couleurs et hiérarchie dans le groupe

- Mixer les variantes de couleur (filled, tonal, outlined) pour souligner l'importance relative
- Un bouton filled dans un groupe de tonal/outlined ressort naturellement comme action principale
- Éviter tous les boutons filled dans le même groupe — annule la hiérarchie
- Largeurs différentes : le bouton le plus large attire l'attention sans changer d'élévation

---

## H5 — Nombre de boutons recommandé

- Standard button group : **2 à 6** boutons (au-delà, utiliser un menu ou une toolbar)
- Ne pas dépasser la largeur disponible — les boutons ne s'enveloppent pas sur plusieurs lignes

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Même forme pour tous les boutons du groupe
✅ **Do :** Varier les couleurs pour souligner l'importance relative
✅ **Do :** Utiliser pour des hero moments expressifs (welcome screen, onboarding)
❌ **Don't :** Mélanger les formes fréquemment dans un même groupe
❌ **Don't :** Mélanger les tailles fréquemment (uniquement pour hero moments)
❌ **Don't :** Grouper des actions sans relation sémantique

---

## Traduction en application concrète

**Pour les hero screens :** Standard Button Group avec boutons de couleurs mixtes (tonal primaire + tonal secondaire) et tailles légèrement différentes pour l'action principale. L'animation inter-boutons est l'élément différenciant.

**Pour un éditeur de texte :** Standard Button Group avec icon buttons toggle (B, I, U) — multi-select, même taille S ou M, même forme square ou round.

**Spec de remise (Standard, M) :** Gap entre boutons : `4px`. Boutons : `height:40px`, variantes de couleur et forme identiques par défaut. Animation : spring/easing matériel, `~300ms`.
