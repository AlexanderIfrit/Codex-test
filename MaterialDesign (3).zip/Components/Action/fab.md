---
source: https://m3.material.io/components/floating-action-button
category: Action
spec-version: v0.192
---

# FABs (Floating Action Buttons) — Heuristiques de décision

Tailles : FAB · Medium FAB ⭐ (recommandé) · Large FAB
Note : le Small FAB n'est plus recommandé en M3.

---

## Tokens de design — valeurs de référence

### FAB Primary (taille standard)
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.primary-container` |
| `container-elevation` | `level3` → **6dp** |
| `container-shape` | `corner-large` → **16px** |
| `container-height` | **56px** (medium FAB) |
| `container-width` | **56px** (medium FAB) |
| `icon-color` | `md-sys-color.on-primary-container` |
| `icon-size` | **24px** |
| `hover-container-elevation` | `level4` → **8dp** |
| `focus-container-elevation` | `level3` → **6dp** |
| `pressed-container-elevation` | `level3` → **6dp** |
| `lowered-container-elevation` | `level1` → **1dp** |
| `lowered-hover-container-elevation` | `level2` → **3dp** |

### Tailles disponibles
| Taille | Container | Icon | Shape |
|--------|-----------|------|-------|
| FAB (small) | **40px × 40px** | 24px | `corner-medium` → 12px |
| Medium FAB ⭐ | **56px × 56px** | 24px | `corner-large` → 16px |
| Large FAB | **96px × 96px** | 36px | `corner-extra-large` → 28px |

### FAB Secondary
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.secondary-container` |
| `icon-color` | `md-sys-color.on-secondary-container` |

### FAB Tertiary
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.tertiary-container` |
| `icon-color` | `md-sys-color.on-tertiary-container` |

---

## H1 — Quand utiliser un FAB vs un Button standard

**Équation :** Pertinence du FAB = Priorité absolue de l'action (fort) + Fréquence d'utilisation (fort) + Besoins de persistance visuelle au scroll (modéré)

- Réserver le FAB à L'action la plus importante de l'écran — **une seule**, jamais deux FABs visibles simultanément
- Actions FAB idéales : constructives ou transformatives (créer, composer, ajouter, éditer)
- Éviter pour les actions destructives (supprimer, archiver), les alertes/erreurs, les actions de contrôle (volume, couleur)

**Zone de bascule :** Si l'écran n'a qu'une seule action possible (formulaire avec un seul bouton), un Filled Button en bottom app bar suffit — le FAB est superflu. Si l'écran affiche des images comme actions primaires (galerie), le FAB peut être omis.

---

## H2 — Choisir la taille selon la fenêtre

**Équation :** Taille FAB = Largeur de fenêtre (fort) + Hiérarchie visuelle du layout (modéré)

| Taille | Fenêtre | Breakpoint | Usage |
|--------|---------|-----------|-------|
| FAB (40px) | Compact | < 600dp | Fenêtre compacte, autres actions présentes |
| Medium FAB ⭐ (56px) | Compact + Medium | 600–839dp | **Par défaut dans la majorité des cas** |
| Large FAB (96px) | Tous (surtout Expanded) | ≥ 840dp | Action très proéminente, layout spacieux |

---

## H3 — Surface color et container color

- FAB Primary : `primary-container` / `on-primary-container` — couleur proéminente par design
- FAB Secondary : `secondary-container` / `on-secondary-container` — moins proéminent
- FAB Tertiary : `tertiary-container` / `on-tertiary-container` — troisième niveau
- Le FAB supporte le **Dynamic Color** (adaptatif au wallpaper) — s'assurer que le contraste reste ≥ 3:1

---

## H4 — Positionnement et comportement

- Position par défaut : coin inférieur droit, `elevation level3` (6dp)
- S'élève à `level4` (8dp) au hover ; reste `level3` au focus et au pressed
- Peut être imbriqué dans la Bottom App Bar (nested FAB) — container descend à `level0`
- Prévoir un `padding-bottom` sur le contenu scrollable pour éviter que le FAB couvre les derniers éléments
- L'icône doit être claire et universelle — utiliser une icône filled (pas outlined)
- Tooltip requis sur web au hover : texte descriptif de l'action

---

## H5 — Adaptive design

- Compact : FAB coin inférieur droit (ou centré si Bottom App Bar présente)
- Medium : Medium FAB (56px), peut migrer dans la Navigation Rail
- Expanded : Large FAB ou Extended FAB dans le Rail ou la Sidebar

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Utiliser le FAB pour l'action principale, positive, fréquente
✅ **Do :** Utiliser une icône claire et simple (add, edit, compose)
✅ **Do :** Adapter la taille à la taille de fenêtre
❌ **Don't :** Utiliser plusieurs FABs sur le même écran
❌ **Don't :** Utiliser pour des actions mineures, destructives, ou trouvables en toolbar
❌ **Don't :** Utiliser des icônes confuses ou ambiguës

---

## Traduction en application concrète

**Signal d'erreur :** Plus d'un FAB visible simultanément = problème d'architecture des actions → résoudre par FAB Menu ou revoir la hiérarchie.

**Spec de remise (Medium FAB Primary) :** `width:56px`, `height:56px`, `border-radius:16px`, `background:var(--md-sys-color-primary-container)`, `box-shadow: elevation-level3`, icône `24px` `var(--md-sys-color-on-primary-container)`.
