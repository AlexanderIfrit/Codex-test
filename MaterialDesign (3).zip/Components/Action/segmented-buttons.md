---
source: https://m3.material.io/components/segmented-buttons
category: Action
spec-version: v0.192
---

# Segmented Buttons — Heuristiques de décision

Types : Single-select (radio-like) · Multi-select (checkbox-like)
Anatomie : 2 à 5 segments avec label et/ou icône, dans un conteneur unique partagé.

---

## Tokens de design — valeurs de référence

### Segmented Button (Outlined variant — seule variante M3)
| Token | Valeur |
|-------|--------|
| `container-height` | **40px** |
| `shape` | `corner-full` → **9999px** |
| `outline-color` | `md-sys-color.outline` |
| `outline-width` | **1px** |
| `selected-container-color` | `md-sys-color.secondary-container` |
| `unselected-container-color` | transparent |
| `selected-label-text-color` | `md-sys-color.on-secondary-container` |
| `unselected-label-text-color` | `md-sys-color.on-surface` |
| `label-text-font` | `md-sys-typescale.label-large` |
| `icon-size` | **18px** |
| `selected-with-icon-icon-color` | `md-sys-color.on-secondary-container` |
| `unselected-with-icon-icon-color` | `md-sys-color.on-surface` |
| `disabled-label-text-opacity` | **0.38** |
| `disabled-container-opacity` | **0.12** |
| `focus-outline-color` | `md-sys-color.secondary` |

---

## H1 — Segmented Buttons vs autres composants de sélection

**Équation :** Préférence Segmented = Options limitées toutes visibles simultanément (fort) + Changement de vue/mode (fort) + Pas de hiérarchie entre les options (modéré)

| Composant | Quand l'utiliser |
|-----------|-----------------|
| Segmented Buttons | 2–5 options, toutes visibles, même niveau d'importance, changement de mode ou filtre visible |
| Tabs | Navigation entre vues avec contenu différent, > 5 catégories |
| Chips (Filter) | Filtres multiples, options nombreuses, surface de recherche |
| Radio Buttons | Options dans un formulaire, contexte de saisie structuré |
| Switch | État binaire unique (on/off) |

**Zone de bascule :** Si les options dépassent 5 → Tabs ou Chips. Si l'action change le contenu de la page entière → Tabs. Si l'action filtre une liste inline → Chips ou Segmented selon l'espace.

---

## H2 — Single-select vs Multi-select

**Single-select :** Une seule option active. Signal visuel : icône de check sur le segment sélectionné + `container-color` → `secondary-container`.
**Multi-select :** Plusieurs options simultanées. Signal visuel : check + couleur sur chaque option sélectionnée.

**Règle :** Toujours avoir au moins une option sélectionnée par défaut en single-select (jamais d'état vide).

---

## H3 — Contenu des segments

**Équation :** Clarté du segment = Label texte (fort) + Icône leading si utile (modéré) — jamais icône seule sans label dans un Segmented Button

- Labels courts : **1–2 mots max**, sentence case
- Icônes optionnelles en **leading position uniquement** (pas trailing)
- Tous les segments : même type de contenu (tous avec label OU tous avec label+icône — ne pas mélanger)
- Icône de check (`✓`) : toujours affichée sur l'état sélectionné même si segment sans icône de base

---

## H4 — Largeur et disposition responsive

- Par défaut : segments s'étendent équitablement sur la largeur disponible (flex:1)
- Hauteur fixe : **40px** (pas de variantes de taille en M3 baseline, XS–XL en M3 Expressive)
- Sur fenêtre étroite : tronquer les labels plutôt que passer en multi-ligne
- Nb min de segments : **2** — max recommandé : **5**

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Utiliser pour 2–5 options de même importance, toutes visibles
✅ **Do :** Toujours une option sélectionnée par défaut (single-select)
✅ **Do :** Labels courts, sentence case
❌ **Don't :** Utiliser plus de 5 segments — passer à Tabs ou Chips
❌ **Don't :** Mélanger icône+label dans certains segments et label seul dans d'autres
❌ **Don't :** Remplacer les Tabs de navigation principale par des Segmented Buttons

---

## Traduction en application concrète

**Pour le changement de vue (liste/grille/carte) :** Segmented Button avec icônes uniquement (list, grid_view, map) — 2–3 options.

**Pour les filtres de temps (Jour/Semaine/Mois) :** Single-select Segmented Button, plus adapté que des Tabs — pas de changement de route, seulement de données affichées.

**Spec de remise :** `height:40px`, `border-radius:9999px`, `border:1px solid var(--md-sys-color-outline)`. Segment selected : `background:var(--md-sys-color-secondary-container)`, `color:var(--md-sys-color-on-secondary-container)`. Icône check : `18px`.
