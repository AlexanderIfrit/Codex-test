---
source: https://m3.material.io/components/menus
category: Selection
spec-version: v0.192
---

# Menus — Heuristiques de décision

Variantes : Dropdown menu · Context menu (long press / right click) · Exposed dropdown menu (select)
Principe : liste temporaire d'actions ou d'options sur une surface élevée.

---

## Tokens de design — valeurs de référence

### Menu
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container` |
| `container-elevation` | `level2` → **3dp** |
| `container-shape` | `corner-extra-small` → **4px** |
| `item-label-text-color` | `md-sys-color.on-surface` |
| `item-label-text-font` | `md-sys-typescale.body-large` |
| `item-hover-state-layer-color` | `md-sys-color.on-surface` |
| `item-hover-state-layer-opacity` | **0.08** |
| `item-focus-state-layer-color` | `md-sys-color.on-surface` |
| `item-leading-icon-color` | `md-sys-color.on-surface-variant` |
| `item-leading-icon-size` | **24px** |
| `item-trailing-icon-color` | `md-sys-color.on-surface-variant` |
| `divider-color` | `md-sys-color.outline-variant` |
| `item-height` | **48dp** |
| Padding horizontal items | **12px** (leading) — **16px** (label) — **12px** (trailing) |
| Padding vertical menu | **8dp** top et bottom |
| Min-width | **112dp** |
| Max-width | **280dp** |

---

## H1 — Dropdown Menu vs Dialog vs Bottom Sheet

**Équation :** Pertinence Menu = Actions courtes peu prioritaires (fort) + Pas de blocage de l'app (fort) + Déclenchement depuis un bouton/icon (`⋮`) (modéré)

| Composant | Blocage | Actions | Durée |
|-----------|---------|---------|-------|
| Dropdown Menu | Aucun (overlay léger) | 2–7 items | Temporaire |
| Dialog | Total (modal) | 1–2 actions critiques | Jusqu'à décision |
| Bottom Sheet | Partiel (modal ou non) | Actions contextuelles riches | Jusqu'à dismiss |

---

## H2 — Nombre d'items

- **Minimum :** 2 items (sinon, bouton direct)
- **Maximum recommandé :** **7 items** avant de chercher une alternative
- Si > 7 items : Bottom Sheet avec liste ou Search dans le menu
- Divider entre groupes logiques d'items (pas entre chaque item)

---

## H3 — Items et icônes

- Items avec icône leading (optionnel) : `24px`, `on-surface-variant`
- Items avec shortcut trailing (desktop) : `label-small`, `on-surface-variant`
- Items avec sous-menu (`chevron_right` trailing) : le sous-menu s'ouvre sur le côté
- Items destructifs (Supprimer) : `error-color` pour label et icône
- Items disabled : `on-surface` à `0.38` opacity

---

## H4 — Exposed Dropdown Menu (Select)

- Ressemble à un Text Field avec icône `expand_more`
- Ouvre un menu déroulant classique à la sélection
- Utilisé dans les formulaires pour choisir parmi une liste (ex : pays, catégorie)
- Container : `corner-extra-small-top` + underline active indicator (filled) ou outline (outlined)

---

## H5 — Positionnement du menu

- S'ouvre en cascade au-dessous (défaut) ou au-dessus si pas d'espace
- Ne dépasse jamais les bords de l'écran → s'aligne en miroir si nécessaire
- Animation : fade + scale origin depuis l'élément déclencheur
- Se ferme : tap hors du menu, navigation, action sélectionnée, Escape (web)

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** 2–7 items clairs et distincts
✅ **Do :** Grouper avec dividers pour > 5 items
✅ **Do :** Items destructifs avec couleur `error`
❌ **Don't :** Menus de > 7 items sans structure → Bottom Sheet
❌ **Don't :** Actions primaires dans un menu → bouton visible
❌ **Don't :** Sous-menus > 2 niveaux de profondeur

---

## Traduction en application concrète

**Menu « ⋮ » dans une liste :** Modifier / Dupliquer / Partager / divider / Supprimer (en `error`). Container `surface-container`, `border-radius:4px`, `elevation-level2`.

**Spec de remise :** `background:var(--md-sys-color-surface-container)`, `border-radius:4px`, `box-shadow:elevation-level2`. Items : `height:48px`, `padding:0 12px`. Label : `var(--md-sys-typescale-body-large)`, `on-surface`. Icon : `24px`, `on-surface-variant`.
