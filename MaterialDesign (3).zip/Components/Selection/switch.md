---
source: https://m3.material.io/components/switch
category: Selection
spec-version: v0.192
---

# Switch — Heuristiques de décision

Principe : bascule binaire (on/off) avec **effet immédiat** — sans action de soumission.
Anatomie : Track (fond) + Handle (curseur circulaire) + Icône optionnelle dans le handle.

---

## Tokens de design — valeurs de référence

### Switch
| Token | Valeur |
|-------|--------|
| `track-color` (selected) | `md-sys-color.primary` |
| `track-color` (unselected) | `md-sys-color.surface-container-highest` |
| `track-outline-color` (unselected) | `md-sys-color.outline` |
| `track-outline-width` | **2px** |
| `track-width` | **52dp** |
| `track-height` | **32dp** |
| `track-shape` | `corner-full` → **9999px** |
| `handle-color` (selected) | `md-sys-color.on-primary` |
| `handle-color` (unselected) | `md-sys-color.outline` |
| `handle-shape` | `corner-full` → **9999px** |
| `handle-height` | **24dp** (default) / **28dp** (pressed) |
| `handle-width` | **24dp** (default) / **28dp** (pressed) |
| `pressed-handle-height` | **28dp** |
| `pressed-handle-width` | **28dp** |
| `disabled-track-opacity` | **0.12** |
| `disabled-selected-handle-color` | `md-sys-color.surface` |
| `selected-icon-color` | `md-sys-color.on-primary-container` |
| `unselected-icon-color` | `md-sys-color.surface-container-highest` |
| State layer size | **40dp** |

---

## H1 — Switch vs Checkbox vs Toggle Button

**Équation :** Pertinence Switch = Effet immédiat (fort) + Paramètre binaire persistant (fort) + Settings/Préférences (modéré)

| Composant | Multi-select | Effet | Contexte |
|-----------|-------------|-------|----------|
| Switch | Non (binaire) | **Immédiat** | Paramètres, notifications activées/désactivées |
| Checkbox | Oui | Différé (submit) | Formulaires, sélection de liste |
| Toggle Button (icon) | Optionnel | Immédiat | Toolbar, action binaire contextuelle |

**Zone de bascule :** Si l'effet n'est pas immédiat (formulaire avec submit) → Checkbox. Si la préférence est dans un écran Settings qui s'applique en temps réel → Switch.

---

## H2 — Handle : taille et animation

- Handle size par défaut : **24dp × 24dp**
- Handle size pressed : **28dp × 28dp** (grandit à la pression → feedback tactile)
- Animation : translation horizontale du handle (on → off et vice-versa)
- Handle color OFF : `outline` (neutre)
- Handle color ON : `on-primary` (blanc sur fond primary)

---

## H3 — Icône optionnelle dans le handle

- Icône `check` (selected) ou `close` (unselected) — renforce le signal visuel au-delà de la couleur seule
- Recommandé pour l'accessibilité (ne pas reposer uniquement sur la couleur)
- `selected-icon-color` : `on-primary-container`
- `unselected-icon-color` : `surface-container-highest`
- Icône : **16px**

---

## H4 — Track et states

- **ON :** track `primary`, handle `on-primary`, translation à droite
- **OFF :** track `surface-container-highest` + outline `outline 2px`, handle `outline`, à gauche
- **Hover :** state layer `40dp` autour du handle, opacity `0.08`
- **Disabled ON :** track opacity `0.12`, handle `surface`
- **Disabled OFF :** track outline opacity `0.12`

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Utiliser pour des paramètres à effet immédiat
✅ **Do :** Icône dans le handle pour renfore l'accessibilité
✅ **Do :** Label à droite du switch, toujours visible
❌ **Don't :** Utiliser dans un formulaire avec submit → Checkbox
❌ **Don't :** Plusieurs switches contrôlant une seule action → Radio

---

## Traduction en application concrète

**Page Paramètres :** Switch pour chaque notification individuelle. Label à droite, état sauvegardé immédiatement.

**Spec de remise :** Track : `width:52px`, `height:32px`, `border-radius:9999px`. ON : `background:var(--md-sys-color-primary)`. OFF : `background:var(--md-sys-color-surface-container-highest)`, `border:2px solid var(--md-sys-color-outline)`. Handle : `width:24px`, `height:24px`, `border-radius:9999px`. Pressed → `28px × 28px`.
