---
source: https://m3.material.io/components/chips
category: Selection
spec-version: v0.192
---

# Chips — Heuristiques de décision

4 variantes : Assist · Filter · Input · Suggestion
Anatomie commune : container compact + label + icône leading optionnelle + icône trailing optionnelle.

---

## Tokens de design — valeurs de référence

### Assist Chip
| Token | Valeur |
|-------|--------|
| `container-color` | transparent |
| `container-elevation` | `level0` → **0dp** |
| `container-shape` | `corner-small` → **8px** |
| `container-height` | **32dp** |
| `label-text-color` | `md-sys-color.on-surface` |
| `label-text-font` | `md-sys-typescale.label-large` |
| `outline-color` | `md-sys-color.outline` |
| `outline-width` | **1px** |
| `icon-color` | `md-sys-color.primary` |
| `icon-size` | **18px** |
| `elevated-container-elevation` | `level1` → **1dp** |
| `elevated-container-color` | `md-sys-color.surface-container-low` |
| `disabled-label-text-opacity` | **0.38** |
| `disabled-container-opacity` | **0.12** |

### Filter Chip
| Token | Valeur |
|-------|--------|
| `container-color` | transparent (unselected) |
| `selected-container-color` | `md-sys-color.secondary-container` |
| `container-shape` | `corner-small` → **8px** |
| `container-height` | **32dp** |
| `label-text-color` | `md-sys-color.on-surface-variant` (unselected) |
| `selected-label-text-color` | `md-sys-color.on-secondary-container` |
| `outline-color` | `md-sys-color.outline` |
| `selected-outline-width` | **0px** (pas d'outline sur sélectionné) |
| `selected-icon-color` | `md-sys-color.on-secondary-container` |
| Icône check leading (sélectionné) | **18px** |

### Input Chip
| Token | Valeur |
|-------|--------|
| `container-color` | transparent |
| `selected-container-color` | `md-sys-color.secondary-container` |
| `container-shape` | `corner-small` → **8px** |
| `container-height` | **32dp** |
| Icône leading (avatar/icône) | **24px** leading, shape `corner-full` pour avatar |
| Icône trailing (×) | **18px** — pour supprimer le chip |
| `trailing-icon-color` | `md-sys-color.on-surface-variant` |

### Suggestion Chip
| Token | Valeur |
|-------|--------|
| `container-color` | transparent |
| `container-shape` | `corner-small` → **8px** |
| `container-height` | **32dp** |
| `label-text-color` | `md-sys-color.on-surface-variant` |
| Icône leading optionnelle | **18px** |

---

## H1 — Choisir la variante de Chip

**Équation :** Variante = Rôle du chip (fort) + Interactivité attendue (fort)

| Variante | Rôle | Interactivité |
|----------|------|--------------|
| Assist | Raccourcis d'actions contextuelles | Déclenche une action (non sélectionnable) |
| Filter | Filtrer du contenu, multi-select | Toggle on/off, sélectable |
| Input | Représenter une entrée utilisateur (tags, personnes) | Sélectionnable, supprimable (`×`) |
| Suggestion | Proposer des complétions/suggestions | Déclenche une action ou auto-complète |

---

## H2 — Chips vs Buttons : différence fondamentale

**Équation :** Chips ≠ Boutons — les chips représentent des **entités ou des filtres**, pas des actions primaires

- Chips : entités dans un contexte (tags, filtres, personnes), réponses rapides
- Buttons : actions utilisateur (créer, envoyer, confirmer)
- Ne pas remplacer les boutons par des chips pour des actions primaires
- Ne pas remplacer les chips par des boutons pour des filtres

---

## H3 — Filter Chips : état sélectionné

- **Non sélectionné :** outlined, `on-surface-variant`, transparent background
- **Sélectionné :** filled, `secondary-container` background, `on-secondary-container` text, icône check leading, pas d'outline
- Multiple filter chips sélectionnables simultanément
- Toujours afficher l'état actif clairement — l'utilisateur doit savoir quels filtres sont actifs

---

## H4 — Input Chips : gestion des tags

- Apparaissent dans les champs de saisie (ex : destinataires dans un email, tags dans un formulaire)
- Icône `×` trailing pour supprimer
- Icône leading : avatar (personnes) ou icône générique
- Cliquable pour voir le détail (ex : cliquer sur un contact → ouvre sa fiche)

---

## H5 — Hauteur et espacement

- Hauteur standard : **32dp** (compact)
- Gap entre chips dans un groupe : **8dp**
- Padding horizontal : **8dp** (sans icône) ou **8dp** leading + **8dp** trailing (avec icône)

---

## Traduction en application concrète

**Filtres de recherche :** Filter Chips horizontaux scrollables (Tout · Récent · Populaire · Près de moi). Sélectionné = `secondary-container` + check.

**Destinataires email :** Input Chips avec avatars dans le champ « À : ». Icône `×` pour retirer. Sélectionnés = `secondary-container`.

**Spec (Filter Chip) :** `height:32px`, `border-radius:8px`. Unselected : `border:1px solid var(--md-sys-color-outline)`, `background:transparent`. Selected : `background:var(--md-sys-color-secondary-container)`, no border. Label : `var(--md-sys-typescale-label-large)`.
