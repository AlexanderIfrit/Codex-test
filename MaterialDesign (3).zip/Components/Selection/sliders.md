---
source: https://m3.material.io/components/sliders
category: Selection
spec-version: v0.192
---

# Sliders — Heuristiques de décision

Variantes : Continuous · Discrete (avec tick marks)
Types : Single handle · Range slider (deux handles)

---

## Tokens de design — valeurs de référence

### Slider
| Token | Valeur |
|-------|--------|
| `active-track-color` | `md-sys-color.primary` |
| `active-track-height` | **4px** |
| `active-track-shape` | `corner-full` → **9999px** |
| `inactive-track-color` | `md-sys-color.surface-container-highest` |
| `inactive-track-height` | **4px** |
| `inactive-track-shape` | `corner-full` → **9999px** |
| `handle-color` | `md-sys-color.primary` |
| `handle-height` | **20px** |
| `handle-width` | **20px** |
| `handle-shape` | `corner-full` → **9999px** |
| `handle-elevation` | `level1` → **1dp** |
| `focus-handle-color` | `md-sys-color.primary` |
| `hover-handle-color` | `md-sys-color.primary` |
| `pressed-handle-color` | `md-sys-color.primary` |
| `state-layer-size` | **40px** |
| `label-container-color` | `md-sys-color.primary` |
| `label-container-height` | **28px** |
| `label-label-text-color` | `md-sys-color.on-primary` |
| `disabled-active-track-color` | `md-sys-color.on-surface` |
| `disabled-active-track-opacity` | **0.38** |
| `disabled-handle-color` | `md-sys-color.on-surface` |
| `disabled-handle-opacity` | **0.38** |
| `disabled-inactive-track-opacity` | **0.12** |
| `with-tick-marks-container-size` | **2px** |
| Stop indicator (fin de track) | **4px**, `corner-full`, `primary` |

---

## H1 — Continuous vs Discrete

**Équation :** Préférence Discrete = Nombre de valeurs limitées (fort) + L'utilisateur bénéficie de points d'ancrage (fort)

| Type | Quand l'utiliser |
|------|-----------------|
| Continuous | Volume, luminosité, zoom — valeur précise pas nécessaire |
| Discrete (tick marks) | Nombre de personnes (1–10), niveau de qualité (1–5), tout ce qui a des valeurs entières prédéfinies |

---

## H2 — Single vs Range slider

- **Single :** un seul handle, valeur de 0 à N
- **Range :** deux handles, définit une plage min–max (ex : filtrer un prix entre 50€ et 200€)
- Sur mobile, s'assurer que les deux handles d'un range slider ont **40dp de zone tactile** séparée (éviter la collision des zones)

---

## H3 — Label de valeur (tooltip-like)

- Label popup au-dessus du handle lors du drag
- `label-container-color` : `primary`, `label-text-color` : `on-primary`, height `28px`
- Afficher uniquement pendant l'interaction (drag / focus) — masqué au repos
- Pour les sliders discrets : valeur entière claire dans le label

---

## H4 — Valeur affichée et accessibilité

- Toujours afficher la valeur actuelle à côté ou au-dessus du slider (pas uniquement dans le label popup)
- Valeur en `body-medium` ou `label-large`, `on-surface-variant`
- Attributs ARIA : `aria-valuenow`, `aria-valuemin`, `aria-valuemax`, `aria-valuetext`

---

## H5 — Disposition dans les formulaires

- Slider horizontal : minimum **200dp** de largeur utile
- Valeur min à gauche, max à droite (LTR)
- Labels d'extrémités optionnels (`body-small`, `on-surface-variant`) : « Lent » / « Rapide »

---

## Traduction en application concrète

**Volume (audio) :** Continuous Slider, icône `volume_down` à gauche, `volume_up` à droite. Handle `primary`, track `primary` / `surface-container-highest`.

**Filtrage de prix :** Range Slider `50€`–`500€`. Label popup au drag. Valeurs des deux handles affichées en permanence au-dessus.

**Spec de remise :** Track : `height:4px`, `border-radius:9999px`. Active : `var(--md-sys-color-primary)`. Inactive : `var(--md-sys-color-surface-container-highest)`. Handle : `width:20px`, `height:20px`, `border-radius:9999px`, `background:var(--md-sys-color-primary)`, `box-shadow:elevation-level1`.
