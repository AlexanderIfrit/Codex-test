---
source: https://m3.material.io/components/checkbox
category: Selection
spec-version: v0.192
---

# Checkbox — Heuristiques de décision

Principe : sélection multiple dans un groupe OU état indépendant on/off dans un formulaire.
États : Unselected · Selected · Indeterminate (parent partiel)

---

## Tokens de design — valeurs de référence

### Checkbox
| Token | Valeur |
|-------|--------|
| `container-shape` | **2px** (carré légèrement arrondi) |
| `container-size` | **18px × 18px** |
| `icon-size` | **18px** |
| `selected-container-color` | `md-sys-color.primary` |
| `selected-icon-color` | `md-sys-color.on-primary` |
| `selected-focus-container-color` | `md-sys-color.primary` |
| `selected-hover-container-color` | `md-sys-color.primary` |
| `selected-pressed-container-color` | `md-sys-color.primary` |
| `selected-disabled-container-opacity` | **0.38** |
| `selected-disabled-container-color` | `md-sys-color.on-surface` |
| `unselected-outline-color` | `md-sys-color.on-surface-variant` |
| `unselected-outline-width` | **2px** |
| `unselected-hover-outline-color` | `md-sys-color.on-surface` |
| `error-focus-state-layer-color` | `md-sys-color.error` |
| `selected-error-container-color` | `md-sys-color.error` |

### Zone de touche (accessibilité)
| Élément | Valeur |
|---------|--------|
| Touch target minimum | **48dp × 48dp** |
| State layer size | **40dp × 40dp** (centré sur le container 18px) |

---

## H1 — Checkbox vs Radio vs Switch : arbitrage fondamental

**Équation :** Pertinence Checkbox = Sélection multiple possible (fort) + Formulaire/liste structurée (fort) + État persistant non-immédiat (modéré)

| Composant | Multi-select | Action | Contexte |
|-----------|-------------|--------|----------|
| Checkbox | ✅ Oui | Différée (submit) | Formulaires, filtres en liste |
| Radio | ❌ Non (exclusif) | Différée | Choix unique obligatoire |
| Switch | ❌ Non (binaire) | Immédiate | Paramètre activé/désactivé en temps réel |
| Filter Chip | ✅ Oui | Immédiate | Filtres visuels inline |

---

## H2 — Checkbox indéterminé

- État **indéterminé** (`-`) : parent d'un groupe dont certains enfants sont cochés et d'autres non
- Cliquer sur un indéterminé → passe à « tout coché » (puis « tout décoché » au click suivant)
- L'icône indéterminée est un tiret horizontal (−) dans le container `primary`

---

## H3 — Checkbox en erreur

- `selected-error-container-color` → `md-sys-color.error`
- `selected-error-icon-color` → `md-sys-color.on-error`
- `error-focus-state-layer-color` → `md-sys-color.error`
- Accompagner d'un texte d'erreur sous le champ/groupe

---

## H4 — Placement et alignement

- Checkbox toujours à gauche du label (ou à droite pour RTL)
- Label cliquable : la zone de touche du label étend la zone de tap du checkbox
- Dans des listes : aligner les checkboxes verticalement (tout à la même position)
- Padding top/bottom entre items de liste checkbox : **4–8dp**

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Utiliser pour sélection multiple dans des formulaires ou listes
✅ **Do :** Checkbox parent indéterminé pour groupes partiellement sélectionnés
✅ **Do :** Zone de touche 48dp minimum
❌ **Don't :** Utiliser pour un choix exclusif → Radio button
❌ **Don't :** Checkbox pour activer/désactiver un paramètre immédiatement → Switch

---

## Traduction en application concrète

**Liste de tâches :** Checkbox sélectionné → `primary` container, coche `on-primary`. Non sélectionné → outline `on-surface-variant 2px`. Touch target : `48dp`.

**Spec de remise :** Container : `width:18px`, `height:18px`, `border-radius:2px`. Sélectionné : `background:var(--md-sys-color-primary)`, icône check `white`. Non sélectionné : `border:2px solid var(--md-sys-color-on-surface-variant)`. Zone tactile : `padding:15px` autour → `48dp`.
