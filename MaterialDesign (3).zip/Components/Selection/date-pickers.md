---
source: https://m3.material.io/components/date-pickers
category: Selection
spec-version: v0.192
---

# Date Pickers — Heuristiques de décision

Variantes : Modal date picker · Modal date input · Docked date picker · Date range picker
Anatomie : Header + Calendar grid + Navigation controls + Action buttons

---

## Tokens de design — valeurs de référence

### Date Picker Modal
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-high` |
| `container-elevation` | `level3` → **6dp** |
| `container-shape` | `corner-extra-large` → **28px** |
| `header-container-color` | `md-sys-color.surface-container-high` |
| `header-headline-color` | `md-sys-color.on-surface-variant` |
| `header-headline-font` | `md-sys-typescale.label-small` |
| `date-today-container-outline-color` | `md-sys-color.primary` |
| `date-today-container-outline-width` | **1px** |
| `date-today-label-text-color` | `md-sys-color.primary` |
| `date-selected-container-color` | `md-sys-color.primary` |
| `date-selected-label-text-color` | `md-sys-color.on-primary` |
| `date-hover-state-layer-color` | `md-sys-color.on-surface` |
| `date-label-text-font` | `md-sys-typescale.body-large` |
| `day-of-week-label-text-color` | `md-sys-color.on-surface` |
| `day-of-week-label-text-font` | `md-sys-typescale.title-small` |
| Container min-width | **~360dp** |
| Container max-width | **~560dp** |
| Scrim | `md-sys-color.scrim` à **0.32** |

### Date Range Picker
| Token | Valeur |
|-------|--------|
| `date-in-range-container-color` | `md-sys-color.primary-container` |
| `date-in-range-label-text-color` | `md-sys-color.on-primary-container` |
| `date-start-container-color` | `md-sys-color.primary` |
| `date-end-container-color` | `md-sys-color.primary` |

---

## H1 — Modal vs Docked vs Input

**Équation :** Modal = Besoin du calendrier visuel (fort) + Mobile (modéré)

| Variant | Quand l'utiliser |
|---------|-----------------|
| Modal date picker | Sélection d'une date avec calendrier complet, mobile |
| Modal date input | Saisie clavier directe (accessibilité, dates précises) — icon bascule vers calendar |
| Docked date picker | Desktop/tablette, calendrier intégré dans la page sans modal |
| Date range picker | Sélectionner une plage de dates (voyage, filtre de période) |

---

## H2 — Single date vs Date range

**Single date :**
- Sélection d'un jour → mise en valeur `primary`
- Aujourd'hui : outline `primary 1px` (non sélectionné) ou rempli `primary` (sélectionné)

**Date range :**
- Date de début + date de fin
- Plage intermédiaire : `primary-container` background
- Extrémités : `primary` filled (début/fin)
- Header affiche les deux dates sélectionnées

---

## H3 — Bascule Calendrier / Saisie clavier

- Bouton icône `edit`/`calendar_today` dans le header pour basculer entre les deux modes
- **Mode saisie clavier :** champ texte formaté (JJ/MM/AAAA) + validation
- Obligatoire pour l'accessibilité (clavier + lecteurs d'écran)

---

## H4 — Navigation dans le calendrier

- Flèches `‹` `›` pour naviguer mois par mois
- Clic sur le mois/année en titre → sélecteur de mois/année en liste
- Boutons d'action : Text button `Annuler` + Text button `OK`

---

## Traduction en application concrète

**Réservation de voyage :** Date Range Picker Modal. Header affiche « 12 jan – 19 jan ». Plage soulignée en `primary-container`. Deux boutons : `Annuler` et `Enregistrer`.

**Spec de remise :** Modal container : `border-radius:28px`, `background:var(--md-sys-color-surface-container-high)`. Date sélectionnée : `background:var(--md-sys-color-primary)`, `color:var(--md-sys-color-on-primary)`, `border-radius:9999px`. Aujourd'hui : `border:1px solid var(--md-sys-color-primary)`.
