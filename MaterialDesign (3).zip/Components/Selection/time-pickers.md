---
source: https://m3.material.io/components/time-pickers
category: Selection
spec-version: v0.192
---

# Time Pickers — Heuristiques de décision

Variantes : Dial (cadran analogique) · Input (saisie clavier)
Les deux variants sont dans le même dialog, avec bascule possible.

---

## Tokens de design — valeurs de référence

### Time Picker Modal
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-high` |
| `container-elevation` | `level3` → **6dp** |
| `container-shape` | `corner-extra-large` → **28px** |
| `clock-dial-container-color` | `md-sys-color.surface-container-highest` |
| `clock-dial-container-shape` | `corner-full` → cercle complet |
| `clock-dial-container-size` | **~256dp** de diamètre |
| `clock-dial-hand-color` | `md-sys-color.primary` |
| `clock-dial-selector-center-container-color` | `md-sys-color.primary` |
| `clock-dial-selector-handle-container-color` | `md-sys-color.primary` |
| `clock-dial-selected-time-label-color` | `md-sys-color.on-primary` |
| `clock-dial-unselected-time-label-color` | `md-sys-color.on-surface` |
| `time-selector-container-color` | `md-sys-color.surface-container-highest` |
| `time-selector-container-shape` | `corner-small` → **8px** |
| `time-selector-label-text-color` (selected) | `md-sys-color.on-tertiary-container` |
| `time-selector-container-color` (selected) | `md-sys-color.tertiary-container` |
| `time-selector-separator-color` | `md-sys-color.on-surface` |
| `period-selector-container-shape` | `corner-small` → **8px** |
| `period-selector-container-color` | `md-sys-color.surface-container-highest` |
| `period-selector-selected-button-container-color` | `md-sys-color.tertiary-container` |

### Input (saisie clavier)
| Token | Valeur |
|-------|--------|
| Champs heure/minute | Text fields outlined ou filled |
| Container height | **72dp** |
| Séparateur `:` | `on-surface`, `display-medium` |

---

## H1 — Dial vs Input

**Équation :** Préférence Dial = Interface tactile mobile (fort) + Sélection rapide de créneau approximatif (modéré)

| Variant | Quand l'utiliser |
|---------|-----------------|
| Dial (cadran) | Mobile tactile, sélection rapide d'heure approximative |
| Input (clavier) | Heure précise, desktop, accessibilité, saisie rapide pour les utilisateurs expérimentés |

- Toujours proposer la bascule entre les deux via icône `keyboard` / `schedule`

---

## H2 — Sélecteurs d'heure et de minutes

- **Header :** deux zones cliquables — HEURES et MINUTES (`tertiary-container` pour la zone active)
- **Dial heures :** 12 positions (1–12) ou 24 positions (0–23)
- **Dial minutes :** 60 positions (0–59)
- Cliquer sur une zone du header active le cadran correspondant

---

## H3 — AM/PM (format 12h)

- Sélecteur AM/PM : deux boutons (`corner-small`) — sélectionné en `tertiary-container`
- Format 24h : pas de sélecteur AM/PM — disponible via paramètres système

---

## H4 — Boutons d'action

- `Annuler` (Text button gauche) + `OK` (Text button droit)
- Pas de fermeture au tap hors du dialog (même comportement que Dialog)

---

## Traduction en application concrète

**Alarme sur mobile :** Time Picker Dial, format 12h avec AM/PM. Bascule vers Input via icône `keyboard` pour les utilisateurs qui préfèrent taper l'heure.

**Spec de remise :** Container : `border-radius:28px`, `background:var(--md-sys-color-surface-container-high)`. Cadran : `width:256px`, `height:256px`, cercle, `background:var(--md-sys-color-surface-container-highest)`. Zone active header : `background:var(--md-sys-color-tertiary-container)`, `border-radius:8px`.
