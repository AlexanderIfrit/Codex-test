---
source: https://m3.material.io/components/radio-button
category: Selection
spec-version: v0.192
---

# Radio Button — Heuristiques de décision

Principe : sélection **exclusive** (une seule option dans un groupe). Toujours utilisé en groupe de ≥ 2.

---

## Tokens de design — valeurs de référence

### Radio Button
| Token | Valeur |
|-------|--------|
| `selected-icon-color` | `md-sys-color.primary` |
| `unselected-icon-color` | `md-sys-color.on-surface-variant` |
| `disabled-selected-icon-color` | `md-sys-color.on-surface` |
| `disabled-selected-icon-opacity` | **0.38** |
| `disabled-unselected-icon-color` | `md-sys-color.on-surface` |
| `disabled-unselected-icon-opacity` | **0.38** |
| `selected-focus-icon-color` | `md-sys-color.primary` |
| `selected-hover-icon-color` | `md-sys-color.primary` |
| `selected-pressed-icon-color` | `md-sys-color.primary` |
| `unselected-focus-icon-color` | `md-sys-color.on-surface` |
| `unselected-hover-icon-color` | `md-sys-color.on-surface` |
| `focus-state-layer-color` | `md-sys-color.primary` (selected) |
| Icône outer size | **20px** |
| Icône inner dot size | **10px** |
| State layer size | **40dp** |
| Touch target | **48dp × 48dp** |

---

## H1 — Radio vs Checkbox vs Select Dropdown

**Équation :** Pertinence Radio = Choix exclusif (fort) + ≤ 5 options toutes visibles (fort) + Formulaire structuré (modéré)

| Composant | Options | Multi-select | Visibilité |
|-----------|---------|-------------|-----------|
| Radio Button | ≤ 5 | Non (exclusif) | Toutes visibles |
| Select Dropdown | > 5 | Selon | Cachées |
| Segmented Button | 2–5 | Optionnel | Tous visibles |

**Zone de bascule :** > 5 options → Select Dropdown (menu déroulant). ≤ 2 options → envisager Switch ou Segmented Button. Si les options doivent toutes être visibles simultanément → Radio.

---

## H2 — Toujours une option pré-sélectionnée

**Règle forte :** Un groupe de radio buttons doit toujours avoir **une option sélectionnée par défaut**. Un état où aucun radio n'est sélectionné est une erreur de conception.
- Exception : si aucune valeur par défaut n'est acceptable, préférer un Select Dropdown (peut avoir un placeholder).

---

## H3 — Disposition : vertical vs horizontal

- **Vertical (recommandé) :** une option par ligne → scan facile, labels longs admis
- **Horizontal :** uniquement si 2–3 options très courtes (Oui / Non / Maybe)
- Espacement vertical entre items : **8dp**

---

## H4 — Labels et aide textuelle

- Labels courts et distincts entre eux (éviter les formulations trop proches)
- Description optionnelle sous chaque label (`body-small`, `on-surface-variant`)
- Supporting text du groupe : en-dessous du groupe entier, pas de chaque item

---

## Traduction en application concrète

**Choix de fréquence (Jamais / Parfois / Toujours) :** Groupe vertical, Radio. Pré-sélectionner la valeur la plus commune.

**Spec de remise :** Outer circle : `width:20px`, `height:20px`. Sélectionné : bordure `primary` + point central `primary 10px`. Non sélectionné : bordure `on-surface-variant`. Zone tactile : `48dp`. Espacement label : `12px` à droite du radio.
