# Routage — Besoin → Fichier de documentation

> Tableau de décision rapide : quel composant M3 pour quel besoin ?
> Une fois le composant identifié, ouvrir le fichier correspondant pour les heuristiques complètes et les tokens.

---

## Par type d'action utilisateur

| Besoin / Question | Fichier |
|-------------------|---------|
| L'utilisateur doit déclencher l'action principale de la page | `Action/fab.md` ou `Action/extended-fab.md` |
| L'utilisateur doit choisir parmi plusieurs actions du même niveau | `Action/buttons.md` |
| L'utilisateur doit exécuter une action iconique (toolbar, app bar) | `Action/icon-buttons.md` |
| L'utilisateur doit choisir parmi 2–5 modes/filtres visibles simultanément | `Action/segmented-buttons.md` |
| L'utilisateur doit choisir une action principale avec des variantes | `Action/split-button.md` |
| L'utilisateur doit choisir parmi 2–5 actions liées (avec animation inter-boutons) | `Action/button-groups.md` |
| L'utilisateur doit accéder à l'une de 2–5 actions liées depuis un FAB | `Action/fab-menu.md` |

---

## Par type de contenu à afficher

| Besoin / Question | Fichier |
|-------------------|---------|
| Afficher du contenu sur un seul sujet (carte) | `Containment/cards.md` |
| Afficher une collection d'items scrollables horizontalement | `Containment/carousel.md` |
| Afficher une liste verticale d'éléments homogènes | `Containment/lists.md` |
| Séparer visuellement des sections | `Containment/divider.md` |
| Afficher des actions liées au contenu courant de la vue | `Containment/toolbars.md` |

---

## Par type de navigation

| Besoin / Question | Fichier |
|-------------------|---------|
| Navigation entre 3–5 destinations sur mobile (compact) | `Navigation/navigation-bar.md` |
| Navigation entre 3–7 destinations sur tablette/desktop (medium+) | `Navigation/navigation-rail.md` |
| Navigation entre 5+ destinations avec hiérarchie (desktop) | `Navigation/navigation-drawer.md` |
| Navigation entre vues de même niveau au sein d'un écran | `Navigation/tabs.md` |
| Titre de page, bouton retour, icônes globales | `Navigation/app-bars.md` |
| Trouver du contenu par mot-clé | `Navigation/search.md` |

---

## Par type de feedback ou communication

| Besoin / Question | Fichier |
|-------------------|---------|
| Indiquer qu'il y a des éléments non lus / notifications | `Communication/badges.md` |
| Indiquer qu'un processus est en cours | `Communication/progress-indicators.md` |
| Indicateur de chargement expressif (M3 Expressive) | `Communication/loading-indicator.md` |
| Confirmer ou signaler le résultat d'une action (brève) | `Communication/snackbar.md` |
| Expliquer une icône ou fonctionnalité au survol | `Communication/tooltips.md` |

---

## Par type de sélection / formulaire

| Besoin / Question | Fichier |
|-------------------|---------|
| Sélection de plusieurs éléments dans une liste/formulaire | `Selection/checkbox.md` |
| Choix exclusif parmi ≤ 5 options visibles | `Selection/radio-button.md` |
| Activer/désactiver un paramètre en temps réel | `Selection/switch.md` |
| Filtres, tags, suggestions, raccourcis contextuels | `Selection/chips.md` |
| Sélectionner une valeur dans une plage continue ou discrète | `Selection/sliders.md` |
| Liste d'options dans un dropdown (actions ou formulaire select) | `Selection/menus.md` |
| Sélectionner une date ou une plage de dates | `Selection/date-pickers.md` |
| Sélectionner une heure | `Selection/time-pickers.md` |
| Saisir du texte dans un formulaire | `TextInput/text-fields.md` |

---

## Par type de contenu temporaire / overlay

| Besoin / Question | Fichier |
|-------------------|---------|
| Demander une confirmation ou décision critique | `Containment/dialogs.md` |
| Afficher du contenu complémentaire depuis le bas (mobile) | `Containment/bottom-sheets.md` |
| Afficher des propriétés / détails depuis le côté (tablette/desktop) | `Containment/side-sheets.md` |
| Proposer une liste d'actions contextuelles légères (< 7 items) | `Selection/menus.md` |

---

## Arbitrages courants (questions fréquentes)

| Question | Réponse |
|----------|---------|
| Switch vs Checkbox ? | Switch = effet immédiat (settings). Checkbox = formulaire avec submit. |
| Segmented Button vs Tabs ? | Segmented = mode/filtre inline (pas de routing). Tabs = navigation entre vues (routing). |
| FAB vs Extended FAB ? | FAB si icône universelle connue. Extended FAB si label nécessaire pour comprendre l'action. |
| Dialog vs Snackbar ? | Dialog si action obligatoire et critique. Snackbar si information ou action optionnelle. |
| Navigation Bar vs Navigation Rail ? | Bar = compact (mobile < 600dp). Rail = medium/expanded (tablette 600dp+). |
| Chips vs Buttons ? | Chips = entités, filtres, tags. Buttons = actions primaires de l'utilisateur. |
| Menu vs Bottom Sheet ? | Menu ≤ 7 items simples. Bottom Sheet si contenu riche ou nombreuses options. |
| Cards vs Lists ? | Cards si contenu hétérogène riche. Lists si éléments homogènes, lecture séquentielle. |
| Radio vs Select Dropdown ? | Radio si ≤ 5 options toutes visibles. Dropdown si > 5 options. |
| Filled vs Outlined Text Field ? | Filled pour formulaires courts/dialogs. Outlined pour formulaires longs. |
