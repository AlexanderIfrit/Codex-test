---
source: https://m3.material.io/components/text-fields
category: TextInput
spec-version: v0.192
---

# Text Fields — Heuristiques de décision

Variantes : Filled · Outlined
Principe : saisie de texte utilisateur dans des formulaires et des dialogues.

---

## Tokens de design — valeurs de référence

### Filled Text Field
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-highest` |
| `container-shape` | `corner-extra-small-top` → **(4px 4px 0 0)** |
| `active-indicator-height` (rest) | **1px** |
| `active-indicator-height` (focus) | **2px** |
| `active-indicator-color` (rest) | `md-sys-color.on-surface-variant` |
| `active-indicator-color` (focus) | `md-sys-color.primary` |
| `active-indicator-color` (error) | `md-sys-color.error` |
| `hover-active-indicator-color` | `md-sys-color.on-surface` |
| `hover-active-indicator-height` | **1px** |
| `caret-color` | `md-sys-color.primary` |
| `input-text-color` | `md-sys-color.on-surface` |
| `input-text-font` | `md-sys-typescale.body-large-font` |
| `input-text-size` | `md-sys-typescale.body-large-size` |
| `input-text-weight` | `md-sys-typescale.body-large-weight` |
| `label-text-color` (rest) | `md-sys-color.on-surface-variant` |
| `label-text-color` (focus) | `md-sys-color.primary` |
| `label-text-color` (populated) | `md-sys-color.on-surface-variant` |
| `label-text-font` | `md-sys-typescale.body-large-font` |
| `error-label-text-color` | `md-sys-color.error` |
| `supporting-text-color` | `md-sys-color.on-surface-variant` |
| `supporting-text-font` | `md-sys-typescale.body-small-font` |
| `error-supporting-text-color` | `md-sys-color.error` |
| `leading-icon-color` | `md-sys-color.on-surface-variant` |
| `trailing-icon-color` | `md-sys-color.on-surface-variant` |
| `error-trailing-icon-color` | `md-sys-color.error` |
| `leading-icon-size` | **24px** |
| `trailing-icon-size` | **24px** |
| `disabled-container-opacity` | **0.04** |
| `disabled-input-text-opacity` | **0.38** |
| `disabled-label-text-opacity` | **0.38** |
| Container height | **56dp** |
| Padding horizontal | **16px** |

### Outlined Text Field
| Token | Valeur |
|-------|--------|
| `container-shape` | `corner-extra-small` → **4px** |
| `outline-color` (rest) | `md-sys-color.outline` |
| `outline-color` (focus) | `md-sys-color.primary` |
| `outline-color` (error) | `md-sys-color.error` |
| `outline-width` (rest) | **1px** |
| `outline-width` (focus) | **2px** |
| `hover-outline-color` | `md-sys-color.on-surface` |
| `hover-outline-width` | **1px** |
| `caret-color` | `md-sys-color.primary` |
| `input-text-color` | `md-sys-color.on-surface` |
| `input-text-font` | `md-sys-typescale.body-large-font` |
| `label-text-color` (rest) | `md-sys-color.on-surface-variant` |
| `label-text-color` (focus) | `md-sys-color.primary` |
| `error-label-text-color` | `md-sys-color.error` |
| `error-outline-color` | `md-sys-color.error` |
| `supporting-text-color` | `md-sys-color.on-surface-variant` |
| `error-supporting-text-color` | `md-sys-color.error` |
| `disabled-outline-opacity` | **0.12** |
| `disabled-input-text-opacity` | **0.38** |
| `disabled-label-text-opacity` | **0.38** |
| `disabled-outline-width` | **1px** |
| Container height | **56dp** |
| Padding horizontal | **16px** |

---

## H1 — Filled vs Outlined : choisir la variante

**Équation :** Préférence Filled = Dialogs et formulaires courts (fort) + Style matériel plus prononcé (modéré)
**Équation :** Préférence Outlined = Formulaires longs (fort) + Contenu dense (fort) + Pages avec fond coloré (modéré)

| Variante | Emphase visuelle | Fond | Contexte idéal |
|----------|----------------|------|---------------|
| Filled | Plus forte | `surface-container-highest` + indicator | Dialogs, formulaires courts, settings |
| Outlined | Moins forte | Transparent + border | Formulaires longs, pages de signup/login |

**Règle de cohérence :** Ne pas mélanger Filled et Outlined dans le même formulaire ou la même section. Choisir l'un, l'appliquer uniformément.

---

## H2 — Label flottant (floating label)

**Comportement :**
1. **Vide, sans focus :** label au centre du champ (`body-large`, `on-surface-variant`)
2. **Focus OU rempli :** label monte → s'affiche en haut du container (`body-small`), change de couleur (`primary` si focus)
3. **Rempli, sans focus :** label reste en haut (`body-small`), couleur `on-surface-variant`

**Erreur :** label en `error` + indicateur de bordure en `error`

---

## H3 — Supporting text et erreur

- **Supporting text :** toujours visible sous le champ, aide contextuelle (`body-small`, `on-surface-variant`)
- **Texte d'erreur :** remplace le supporting text, `body-small`, `error-color`
- **Compteur de caractères :** trailing dans le supporting text (`body-small`, `on-surface-variant`)
- Hauteur du supporting text : **16px** de hauteur minimum (un ligne `body-small`)

---

## H4 — Icônes leading et trailing

- **Leading icon (optionnelle) :** `24px`, `on-surface-variant` — pour la clarté du champ (ex : `search`, `email`, `phone`)
- **Trailing icon (optionnelle) :** `24px`, `on-surface-variant` — pour les actions contextuelles
  - Filled : `visibility_off` (mot de passe), `clear` (effacer), `error` (erreur)
  - `error-trailing-icon-color` : `error` en état d'erreur

---

## H5 — Multi-line text fields

- Hauteur auto-expandable selon le contenu (pas de scroll interne par défaut)
- Hauteur minimum : **56dp** (1 ligne) ; pas de maximum défini
- `resize-handle` optionnel en trailing bottom pour les areas manuellement redimensionnables

---

## H6 — Préfixes et suffixes

- Préfixe (ex : `€`, `+33`) : inline dans l'input, `body-large`, `on-surface-variant`
- Suffixe (ex : `kg`, `.com`) : idem en trailing
- Ne pas ajouter préfixe + icône leading simultanément (trop chargé)

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Un seul type (Filled ou Outlined) par formulaire
✅ **Do :** Labels toujours présents (pas uniquement placeholder)
✅ **Do :** Supporting text pour l'aide ou les erreurs
✅ **Do :** Focus indicator clairement visible (`primary`, `2px`)
❌ **Don't :** Mélanger Filled et Outlined dans la même section
❌ **Don't :** Remplacer le label par un placeholder — le placeholder disparaît et l'utilisateur oublie le champ
❌ **Don't :** Champ désactivé sans explication visuelle du pourquoi

---

## Traduction en application concrète

**Formulaire de connexion (Outlined) :** Email + Mot de passe, icône `visibility_off` trailing, supporting text « Au moins 8 caractères ». Focus → outline `primary 2px`. Erreur → outline + label + supporting text en `error`.

**Spec (Filled) :** `height:56px`, `background:var(--md-sys-color-surface-container-highest)`, `border-radius:4px 4px 0 0`. Active indicator : rest `1px on-surface-variant`, focus `2px primary`. Label float : `body-large` → `body-small` à la saisie. Padding : `16px`.

**Spec (Outlined) :** `height:56px`, `border-radius:4px`. Border : rest `1px outline`, focus `2px primary`, error `2px error`. Label float avec notch dans la bordure au focus.
