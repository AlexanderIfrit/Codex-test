---
source: https://m3.material.io/components/app-bars
category: Navigation
spec-version: v0.192
---

# App Bars — Heuristiques de décision

Variantes : Top App Bar (Small · Center-aligned · Medium · Large) · Bottom App Bar
Principe : navigation globale et titre de la vue courante.

---

## Tokens de design — valeurs de référence

### Top App Bar
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface` |
| `container-elevation` (on-scroll) | `level2` → **3dp** |
| `headline-color` | `md-sys-color.on-surface` |
| `headline-font` (Small) | `md-sys-typescale.title-large` |
| `headline-font` (Medium) | `md-sys-typescale.headline-small` |
| `headline-font` (Large) | `md-sys-typescale.headline-medium` |
| `leading-icon-color` | `md-sys-color.on-surface` |
| `trailing-icon-color` | `md-sys-color.on-surface-variant` |
| `icon-size` | **24px** |

### Hauteurs des variants Top App Bar
| Variante | Hauteur collapsed | Hauteur expanded |
|----------|-----------------|-----------------|
| Small | **64dp** | — |
| Center-aligned | **64dp** | — |
| Medium | **112dp** | **112dp** → collapse to **64dp** |
| Large | **152dp** | **152dp** → collapse to **64dp** |

### Bottom App Bar
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container` |
| `container-elevation` | `level2` → **3dp** |
| `container-height` | **80dp** |
| `icon-color` | `md-sys-color.on-surface-variant` |
| FAB intégré | FAB position : trailing (right), taille standard 56px |

---

## H1 — Choisir le variant de Top App Bar

**Équation :** Variant = Longueur du titre (fort) + Importance du titre dans la navigation (fort) + Densité du contenu sous la barre (modéré)

| Variant | Titre | Quand l'utiliser |
|---------|-------|-----------------|
| Small | Court (1 ligne) | Navigation standard, titre de page court |
| Center-aligned | Court, centré | Vues simples, onboarding, pages solo |
| Medium | Moyen, expand/collapse | Titre descriptif (ex : « Paramètres de compte ») |
| Large | Long, expand/collapse | Vues principales, dashboards, titres longs |

**Zone de bascule :** Si le titre dépasse 2 mots → Medium ou Large. Center-aligned uniquement si la vue est isolée et simple (pas de navigation arrière complexe).

---

## H2 — Top App Bar vs Bottom App Bar

**Top App Bar :**
- Navigation arrière (`arrow_back`), titre de la vue, 1–3 icon buttons d'actions courantes
- Sticky (reste en haut en scrollant) par défaut
- Au scroll → `container-elevation` monte à `level2` (shadow apparaît)

**Bottom App Bar :**
- Compact uniquement (mobile) — pas sur tablette/desktop
- Actions les plus fréquentes + FAB optionnel intégré
- La navigation reste en Top App Bar — la Bottom App Bar complète avec les actions
- `container-height: 80dp`

---

## H3 — Contenu d'une Top App Bar

**Leading (gauche) :**
- Navigation : `arrow_back`, `menu` (hamburger), ou rien si racine
- 1 seul icon button leading

**Centre :**
- Titre de la vue (non cliquable)
- Texte ou logo pour les racines (home screens)

**Trailing (droite) :**
- Max **3 icon buttons** (`on-surface-variant`)
- Débordement → `more_vert` (`⋮`) overflow menu

---

## H4 — Comportement au scroll (Medium / Large)

- Scroll vers le bas → collapse : titre remonte dans le header compact (Small)
- Scroll vers le haut → expand : titre revient en position large
- L'animation utilise les tokens de motion M3 (easing standard)
- `container-elevation` passe de `0` à `level2` quand le contenu commence à défiler sous la barre

---

## H5 — Search App Bar

Variante spéciale de Top App Bar pour la recherche globale :
- Container shape : `corner-full` (9999px) → forme pill
- Couleur : `md-sys-color.surface-container-highest`
- Persistent en haut de l'écran comme entry point de recherche
- [Voir composant Search]

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** 1–3 actions trailing maximum dans la Top App Bar
✅ **Do :** Bottom App Bar + FAB uniquement sur compact/mobile
✅ **Do :** Medium/Large pour les titres longs ou les vues importantes
❌ **Don't :** Mettre de la navigation principale dans la Top App Bar (→ Nav Bar/Rail)
❌ **Don't :** Dépasser 3 icon buttons trailing → overflow menu

---

## Traduction en application concrète

**App de messagerie :** Small Top App Bar, `arrow_back` + titre de la conversation, trailing : `call`, `video_call`, `more_vert`.

**Dashboard :** Large Top App Bar avec titre « Tableau de bord » qui collapse en Small au scroll.

**Spec (Small) :** `height:64px`, `background:var(--md-sys-color-surface)`. Titre : `font:var(--md-sys-typescale-title-large)`, `color:on-surface`. Icons : `24px`, `on-surface-variant`.
