---
source: https://m3.material.io/components/navigation-rail
category: Navigation
spec-version: v0.192
---

# Navigation Rail — Heuristiques de décision

Usage : navigation primaire entre **3–7 destinations** sur **medium** (tablette) et **expanded** (desktop) quand l'espace horizontal est disponible.

---

## Tokens de design — valeurs de référence

### Navigation Rail
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface` |
| `container-elevation` | `level0` → **0dp** |
| `container-width` | **80dp** |
| `container-shape` | `corner-none` → **0px** |
| `indicator-color` | `md-sys-color.secondary-container` |
| `indicator-shape` | `corner-full` → **9999px** |
| `indicator-height` | **32dp** |
| `indicator-width` | **56dp** |
| `active-icon-color` | `md-sys-color.on-secondary-container` |
| `inactive-icon-color` | `md-sys-color.on-surface-variant` |
| `active-label-text-color` | `md-sys-color.on-surface` |
| `inactive-label-text-color` | `md-sys-color.on-surface-variant` |
| `active-label-text-weight` | prominent |
| `label-text-font` | `md-sys-typescale.label-medium` |
| `icon-size` | **24px** |
| FAB position | Top du Rail (leading edge) |

---

## H1 — Navigation Rail vs Navigation Bar vs Navigation Drawer

**Équation :** Préférence Rail = Fenêtre medium–expanded (fort) + 3–7 destinations (fort) + Contenu principal large horizontalement (modéré)

| Composant | Fenêtre | Destinations | Largeur |
|-----------|---------|-------------|---------|
| Nav Bar | Compact | 3–5 | Bas, pleine largeur |
| Nav Rail | Medium + | 3–7 | **80dp** côté gauche |
| Nav Drawer | Medium + Expanded | 5+ | **360dp** côté gauche |

---

## H2 — FAB dans le Rail

- Le Rail peut contenir un **FAB en haut**, au-dessus des destinations
- Pratique pour exposer l'action primaire au même endroit que la navigation
- Taille FAB dans le Rail : **56dp** (Medium FAB)
- Séparation FAB → items : **8dp**

---

## H3 — Labels dans le Rail

- Deux comportements de labels :
  - **Labels toujours visibles** (recommandé) : label sous l'icône, indicator pilule sur l'icône
  - **Labels au hover/focus** (compact Rail) : label apparaît uniquement au survol
- Labels 1 mot max, tronqués si nécessaire
- Icône outlined (inactif) → filled (actif) si paire existe

---

## H4 — Adaptive design (passer de Nav Bar à Rail)

- Compact (<600dp) → Nav Bar (bas de l'écran)
- Medium (600–840dp) → Nav Rail (gauche, `80dp`)
- Expanded (840dp+) → Nav Rail ou Nav Drawer selon le nombre de destinations

**Animation de transition :**
- Nav Bar disparaît, Rail apparaît en glissant depuis la gauche
- Le contenu principal s'adapte en margin-left (push layout)

---

## H5 — Destinations secondaires

- Si destinations > 7 → combiner Rail + Drawer Modal pour les destinations supplémentaires
- Section additionnelle en bas du Rail pour Paramètres, Aide (optionnel)

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** 3–7 destinations, labels toujours visibles
✅ **Do :** FAB optionnel en haut du Rail
✅ **Do :** Adapter de Nav Bar (compact) à Rail (medium+)
❌ **Don't :** Nav Rail sur compact → Nav Bar
❌ **Don't :** > 7 destinations sans Drawer complémentaire

---

## Traduction en application concrète

**App tablette (medium) :** Rail de 80dp avec FAB « Composer » en haut, 5 destinations : Accueil, Messages, Agenda, Fichiers, Paramètres.

**Spec de remise :** `width:80px`, `background:var(--md-sys-color-surface)`. Indicator : `width:56px`, `height:32px`, `border-radius:9999px`, `background:var(--md-sys-color-secondary-container)`. Label : `var(--md-sys-typescale-label-medium)`.
