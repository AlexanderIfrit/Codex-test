---
source: https://m3.material.io/components/navigation-bar
category: Navigation
spec-version: v0.192
---

# Navigation Bar — Heuristiques de décision

Usage : navigation primaire entre 3–5 destinations principales sur **compact** (mobile) et parfois medium.

---

## Tokens de design — valeurs de référence

### Navigation Bar
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container` |
| `container-elevation` | `level2` → **3dp** |
| `container-height` | **80dp** |
| `container-shape` | `corner-none` → **0px** |
| `indicator-color` | `md-sys-color.secondary-container` |
| `indicator-shape` | `corner-full` → **9999px** |
| `indicator-height` | **32dp** |
| `indicator-width` | **64dp** |
| `icon-size` | **24px** |
| `active-icon-color` | `md-sys-color.on-secondary-container` |
| `inactive-icon-color` | `md-sys-color.on-surface-variant` |
| `active-label-text-color` | `md-sys-color.on-surface` |
| `inactive-label-text-color` | `md-sys-color.on-surface-variant` |
| `active-label-text-weight` | `label-medium-weight-prominent` |
| `label-text-font` | `md-sys-typescale.label-medium` |
| `item-width` | **80px** min (variable, fill) |

### Safe area
- Padding bottom : `env(safe-area-inset-bottom)` (iOS home indicator)
- Height totale avec safe area : **80dp + safe-area-inset-bottom**

---

## H1 — Navigation Bar vs Navigation Rail vs Navigation Drawer

**Équation :** Préférence Nav Bar = Fenêtre compact (fort) + 3–5 destinations (fort) + Accessibilité immédiate au pouce (modéré)

| Composant | Fenêtre | Destinations | Position |
|-----------|---------|-------------|---------|
| Navigation Bar | Compact | **3–5** | Bas de l'écran |
| Navigation Rail | Medium | **3–7** | Latérale gauche |
| Navigation Drawer | Medium + Expanded | **5+** | Latérale gauche (modal ou permanent) |

**Zone de bascule :** < 3 destinations → Tabs. > 5 destinations → Drawer. Sur medium, Nav Rail est généralement préféré.

---

## H2 — Indicateur actif et états

- **Actif :** indicator pill (`secondary-container`), icône `on-secondary-container`, label `on-surface` (prominent weight)
- **Inactif :** pas d'indicator, icône `on-surface-variant`, label `on-surface-variant`
- **Hover (web) :** state layer `on-surface` à `0.08` opacity
- **Focus :** outline `secondary` autour de l'item
- **Badge :** placer en haut droit de l'icône (voir composant Badge)

---

## H3 — Labels et icônes

- Labels obligatoires — toujours visibles (pas de mode « icône seule » en Nav Bar)
- Icône : outlined (inactif) → filled (actif) quand paire disponible
- Labels : 1 mot maximum, tronqués avec `…` si trop longs
- Tous les items : même largeur (flex-grow:1)

---

## H4 — Positions et safe areas

- La Nav Bar est toujours en bas de l'écran, **sticky**
- Respecter `env(safe-area-inset-bottom)` pour les iPhones
- Contenu scrollable : padding-bottom = hauteur Nav Bar pour éviter que le dernier item soit caché

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** 3–5 destinations, labels toujours visibles
✅ **Do :** Icône filled/outlined selon état actif/inactif
✅ **Do :** Respecter les safe areas
❌ **Don't :** < 3 ou > 5 destinations dans une Nav Bar
❌ **Don't :** Navigation secondaire dans la Nav Bar (→ Tabs ou autre)
❌ **Don't :** Faire disparaître la Nav Bar au scroll vers le bas → mauvaise UX

---

## Traduction en application concrète

**App standard (4 destinations) :** Accueil · Messages · Notifications · Profil — chacun avec icône outlined/filled et label 1 mot.

**Spec de remise :** `height:80px`, `background:var(--md-sys-color-surface-container)`. Indicator : `width:64px`, `height:32px`, `border-radius:9999px`, `background:var(--md-sys-color-secondary-container)`. Icon : `24px`. Label : `var(--md-sys-typescale-label-medium)`.
