---
source: https://m3.material.io/components/navigation-drawer
category: Navigation
spec-version: v0.192
---

# Navigation Drawer — Heuristiques de décision

Variantes : Standard (permanent) · Modal
Usage : navigation primaire avec **5+ destinations** ou hiérarchie de navigation.

---

## Tokens de design — valeurs de référence

### Navigation Drawer
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-low` |
| `container-elevation` | `level0` (standard/permanent) ou `level1` (modal) |
| `container-shape` | `corner-large-end` → **(0px 16px 16px 0px)** (côté droit) |
| `container-width` | **360dp** |
| `active-indicator-color` | `md-sys-color.secondary-container` |
| `active-indicator-shape` | `corner-full` → **9999px** |
| `active-indicator-height` | **56dp** |
| `active-indicator-width` | stretch (full-width - 24px padding) |
| `active-icon-color` | `md-sys-color.on-secondary-container` |
| `inactive-icon-color` | `md-sys-color.on-surface-variant` |
| `active-label-text-color` | `md-sys-color.on-secondary-container` |
| `inactive-label-text-color` | `md-sys-color.on-surface-variant` |
| `label-text-font` | `md-sys-typescale.label-large` |
| `icon-size` | **24px** |
| Scrim (modal) | `md-sys-color.scrim` à **0.32** opacity |
| Header height | **~72dp** (optionnel) |
| Padding sections | **12px** vertical, **28px** horizontal |

---

## H1 — Standard vs Modal Drawer

**Standard (permanent) :**
- Toujours visible, pushes ou overlays le contenu principal
- Fenêtre **expanded uniquement** (desktop, grandes tablettes ≥ 1200dp)
- Pas de scrim, l'utilisateur peut interagir avec les deux

**Modal :**
- S'ouvre sur le contenu (overlay) avec scrim `0.32`
- Toutes fenêtres — mais surtout sur **compact et medium** quand le Drawer est une option
- Fermeture : tap scrim ou bouton `×`/`menu`

**Règle adaptive :**
- Compact → Navigation Bar (pas de Drawer par défaut)
- Medium → Navigation Rail ou Modal Drawer
- Expanded → Navigation Drawer permanent ou Rail

---

## H2 — Structure interne du Drawer

**Header optionnel (72dp) :**
- Logo ou nom de l'app, avatar utilisateur, section branding
- Pas d'actions dans le header du Drawer (→ App Bar)

**Sections de navigation :**
- Items : `indicator-height:56dp`, icône `24px` + label `label-large`
- Groupes de destinations séparés par dividers ou section headers (`label-medium`, `on-surface-variant`)
- Padding items : `padding-inline:28px`

**Items secondaires / profil :**
- Destinations moins importantes ou administratives → en bas du Drawer
- Lien vers Paramètres, Aide, Feedback en bas

---

## H3 — Indicator actif

- Indicator pill : `secondary-container`, `corner-full`, `height:56dp`, largeur = largeur du drawer - marges
- Icône active : `on-secondary-container` (filled si paire existe)
- Icône inactive : `on-surface-variant` (outlined)
- Label actif : `on-secondary-container`

---

## H4 — Adaptive design

| Fenêtre | Solution nav |
|---------|-------------|
| Compact (< 600dp) | Navigation Bar |
| Medium (600–840dp) | Navigation Rail (+ Modal Drawer pour les destinations secondaires) |
| Expanded (840dp+) | Navigation Drawer permanent |

---

## Règles Do / Don't (guidelines officielles)

✅ **Do :** Drawer permanent sur expanded uniquement
✅ **Do :** Modal pour compact/medium si Drawer nécessaire
✅ **Do :** Grouper les destinations avec headers et dividers
❌ **Don't :** Drawer comme navigation principale sur compact → Nav Bar
❌ **Don't :** Plus de ~15 destinations sans sous-navigation

---

## Traduction en application concrète

**App desktop (expanded) :** Drawer permanent, `width:360dp`, sections : « Principal » (5 items) + divider + « Gestion » (3 items) + divider + « Paramètres » (2 items en bas).

**Spec de remise :** `width:360px`, `background:var(--md-sys-color-surface-container-low)`, `border-radius:0 16px 16px 0`. Item indicator : `height:56px`, `border-radius:9999px`, `background:var(--md-sys-color-secondary-container)`. Label : `var(--md-sys-typescale-label-large)`.
