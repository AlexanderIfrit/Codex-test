---
source: https://m3.material.io/components/tabs
category: Navigation
spec-version: v0.192
---

# Tabs — Heuristiques de décision

Variantes : Primary tabs · Secondary tabs
Principe : navigation entre des vues de même niveau hiérarchique au sein d'un même écran.

---

## Tokens de design — valeurs de référence

### Primary Tabs
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface` |
| `container-elevation` | `level0` → **0dp** |
| `container-height` | **48dp** |
| `active-indicator-color` | `md-sys-color.primary` |
| `active-indicator-height` | **3dp** |
| `active-indicator-shape` | `corner-full` → **9999px** |
| `active-label-text-color` | `md-sys-color.primary` |
| `inactive-label-text-color` | `md-sys-color.on-surface-variant` |
| `active-icon-color` | `md-sys-color.primary` |
| `inactive-icon-color` | `md-sys-color.on-surface-variant` |
| `label-text-font` | `md-sys-typescale.title-small` |
| `icon-size` | **24px** |
| Divider (en bas des tabs) | `md-sys-color.surface-variant`, `1px` |

### Secondary Tabs
| Token | Valeur |
|-------|--------|
| `active-indicator-color` | `md-sys-color.primary` |
| `active-indicator-height` | **2dp** |
| `active-label-text-color` | `md-sys-color.on-surface` |
| `inactive-label-text-color` | `md-sys-color.on-surface-variant` |
| `label-text-font` | `md-sys-typescale.title-small` |
| Container height | **48dp** |

---

## H1 — Primary vs Secondary Tabs

**Équation :** Préférence Primary Tabs = Navigation de niveau supérieur (fort) + Contenu distinct entre tabs (fort) + Pas d'autre composant de navigation primaire au même niveau (modéré)

| Variant | Quand l'utiliser |
|---------|-----------------|
| Primary | Navigation principale entre sections distinctes (Accueil, Tendances, Abonnements) |
| Secondary | Sous-catégories au sein d'une même section déjà naviguée par Primary Tabs |

**Zone de bascule :** Ne pas imbriquer deux niveaux de Primary Tabs. Si sous-catégories nécessaires → Secondary Tabs dans le contenu. Tabs et Navigation Bar = ne pas utiliser les deux pour la même navigation.

---

## H2 — Tabs vs Segmented Buttons vs Navigation Bar

| Composant | Destinations | Position | Contenu |
|-----------|-------------|----------|---------|
| Tabs | 2+ | Dans la page, sous l'app bar | Vues différentes, même écran |
| Segmented Button | 2–5 | Inline | Modes/filtres, pas de routing |
| Nav Bar | 3–5 | Bas | Destinations principales avec routing |

---

## H3 — Contenu des tabs

- Labels obligatoires (Primary et Secondary)
- Icônes optionnelles (Primary uniquement, au-dessus du label ou seules si labels trop longs)
- Labels : 1–2 mots, tronqués avec `…` si nécessaire, **jamais sur 2 lignes**
- Tous les tabs : même hauteur, même largeur (fixed ou scrollable)

**Fixed vs Scrollable :**
- Fixed : tous les tabs visibles simultanément, même largeur — recommandé pour ≤ 4 tabs
- Scrollable : tabs plus nombreux, défilement horizontal — pour ≥ 5 tabs

---

## H4 — Indicateur actif

- Primary : indicateur `3dp` en bas, couleur `primary`, arrondi `corner-full`
- Secondary : indicateur `2dp` en bas, couleur `primary`, plus discret
- Animation de l'indicateur : glisse entre tabs lors du changement (motion easing standard)

---

## H5 — Interaction avec le contenu

- Swipe horizontal sur le contenu change le tab actif (et vice-versa) — synchronisation obligatoire
- Le contenu suit le même rythme de scroll que la page (tabs sticky sous l'app bar)

---

## Traduction en application concrète

**App actualités :** Primary Tabs : « À la une » · « Tech » · « Sport » · « Culture ». Fixed si ≤ 4, scrollable si > 4.

**Spec (Primary) :** `height:48px`, `background:var(--md-sys-color-surface)`. Active indicator : `height:3px`, `border-radius:9999px`, `background:var(--md-sys-color-primary)`. Label : `var(--md-sys-typescale-title-small)`, active : `primary`, inactive : `on-surface-variant`.
