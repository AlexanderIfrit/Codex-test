---
source: https://m3.material.io/components/search
category: Navigation
spec-version: v0.192
---

# Search — Heuristiques de décision

Variants : Search bar (persistante) · Search app bar (entry point global) · Search icon button
Comportements : passive (pre-search) · focused (typing) · results

---

## Tokens de design — valeurs de référence

### Search Bar
| Token | Valeur |
|-------|--------|
| `container-color` | `md-sys-color.surface-container-highest` |
| `container-elevation` | `level0` → **0dp** |
| `container-shape` | `corner-full` → **9999px** |
| `container-height` | **56dp** |
| `input-text-color` | `md-sys-color.on-surface` |
| `input-text-font` | `md-sys-typescale.body-large` |
| `supporting-text-color` | `md-sys-color.on-surface-variant` |
| `leading-icon-color` | `md-sys-color.on-surface` |
| `trailing-icon-color` | `md-sys-color.on-surface-variant` |
| `avatar-shape` | `corner-full` |
| `avatar-size` | **30dp** |

### Search Suggestions / Results (panel)
| Élément | Valeur |
|---------|--------|
| Container color | `md-sys-color.surface-container` |
| Container elevation | `level2` → **3dp** |
| Shape | `corner-extra-large-bottom` → **(0 0 28px 28px)** |
| List item height | **48–64dp** |
| Divider | `outline-variant`, `1px` |

---

## H1 — Choisir le variant de Search

**Équation :** Variant = Importance de la recherche dans le produit (fort) + Espace disponible (modéré)

| Variant | Quand l'utiliser |
|---------|-----------------|
| Search bar (persistante) | Recherche est fonctionnalité principale/fréquente, barre toujours visible |
| Search app bar | Recherche globale prioritaire — remplace la top app bar |
| Search icon button | Recherche secondaire ou peu fréquente — accès via icône |

---

## H2 — États de la Search bar

**Passive (avant focus) :**
- Icône `search` en leading, avatar ou icône `mic` optionnel en trailing
- Placeholder text : `on-surface-variant`

**Focused (lors de la saisie) :**
- Icône `arrow_back` en leading (pour retourner à l'état passif)
- Icône `×` (clear) en trailing si texte saisi
- Liste de suggestions apparaît sous la barre

**Résultats :**
- Résultats remplacent le contenu de la page ou apparaissent dans un panel
- La barre reste en focus avec le texte saisi

---

## H3 — Suggestions et résultats

- **Suggestions récentes** (`history` icon) : premières suggestions avant saisie
- **Suggestions dynamiques** (correspondance texte) : apparaissent lors de la frappe
- Panel sous la Search bar : `surface-container`, `elevation level2`, `corner-extra-large` en bas
- Items de suggestions : `body-large`, hauteur `48–64dp`
- Highlighting du texte correspondant dans les suggestions

---

## H4 — Search App Bar (variante spéciale)

- Remplace la Top App Bar sur l'écran où la recherche est la fonction principale
- Forme pill (`corner-full`) + shadow légère (`level1`)
- Container color : `surface-container-highest` (même que Search Bar standard)
- Icône `menu` en leading (si Drawer) ou `arrow_back`

---

## H5 — Adaptive design

- Compact : Search bar pleine largeur sous le top app bar, ou search icon button dans l'app bar
- Medium/Expanded : Search bar dans la sidebar ou en haut du contenu

---

## Traduction en application concrète

**App e-commerce :** Search bar persistante sous la Top App Bar, placeholder « Rechercher des produits… ». Suggestions : historique + suggestions dynamiques.

**Spec (Search bar) :** `height:56px`, `border-radius:9999px`, `background:var(--md-sys-color-surface-container-highest)`. Input : `body-large`, `on-surface`. Leading/trailing icons : `24px`, `on-surface-variant`.
