---
source: https://m3.material.io/foundations/usability/overview
category: Foundations / Usability
spec-version: v0.192
---

# Usability — Vue d'ensemble & Tactiques

Périmètre : hiérarchie visuelle · tactiques expressives · charge cognitive · itération · design orienté objectifs

---

## Schéma de pensée

L'utilisabilité n'est pas l'absence d'erreurs de conception — c'est la capacité d'une interface à guider activement l'utilisateur vers ses objectifs en réduisant la charge cognitive à chaque étape. M3 Expressive repositionne l'utilisabilité : la forme, la couleur, la taille et la typographie ne sont pas des choix esthétiques neutres — ce sont des leviers fonctionnels qui créent ou détruisent la hiérarchie visuelle. Une interface sans hiérarchie visuelle forte oblige l'utilisateur à scanner l'ensemble pour identifier ce qu'il peut faire — chaque seconde de scan est de la friction.

---

## Principes

- **Hiérarchie visuelle = guide d'action** : les éléments les plus importants doivent être perceptivement saillants (taille, contraste, forme) — l'œil doit trouver l'action primaire sans effort conscient.
- **5 tactiques expressives M3** : conteneur, taille, forme, couleur, typographie — chacune peut amplifier ou réduire l'importance perçue d'un élément.
- **Ne pas saturer** : trop d'éléments visuellement importants = aucun ne l'est. L'expressivité est relative — elle ne fonctionne que par contraste.
- **Design basé sur les objectifs primaires** : identifier les 1-2 actions que l'utilisateur est le plus susceptible de vouloir accomplir → les rendre visuellement dominantes → tout le reste est secondaire.
- **Tester et itérer** : les hypothèses d'utilisabilité doivent être validées avec de vrais utilisateurs — ce qui semble évident au concepteur peut être opaque à l'utilisateur.

---

## Les 5 tactiques expressives M3

| Tactique | Levier | Effet sur la hiérarchie |
|----------|--------|------------------------|
| **Conteneur** | Surface délimitée vs non délimitée | Isole et élève un composant, crée du focus |
| **Taille** | Grandes vs petites cibles | Grand = important ; petit = secondaire |
| **Forme** | Coins arrondis, formes organiques | Communique la catégorie et l'importance relative |
| **Couleur** | Couleur de marque vs surface neutre | Attire l'attention sur l'action primaire |
| **Typographie** | Poids, taille, style | Hiérarchise l'information textuelle |

---

## Heuristiques

**H1 — Hiérarchie visuelle : règle des niveaux**

Guidage efficace ∝ Différentiation visuelle entre niveaux [poids: fort] + Nombre restreint de niveaux [poids: fort] − Éléments de même poids visuel en compétition [poids: très fort, négatif]

- **Sens de chaque variable** : une interface avec 1 élément clairement dominant et 2-3 éléments secondaires distincts guide naturellement ; une interface avec 5 éléments du même poids visuel force l'utilisateur à analyser avant d'agir.
- **Règle pratique** : maximum 3 niveaux de hiérarchie visuelle par vue — primaire (1 élément), secondaire (2-3 éléments), tertiaire (tout le reste).
- **Zone de bascule** : vues avec multiples actions légitimement importantes (tableau de bord, marketplace) — grouper les actions par contexte plutôt que d'essayer de toutes les mettre au même niveau d'importance.
- **Raison généralisable** : la perception humaine fonctionne par figure/fond — l'élément dominant n'est perçu comme tel que s'il existe un fond moins saillant.

---

**H2 — Saturation expressive : le piège de l'amplification uniforme**

Clarté perçue ∝ Contraste entre éléments expressifs et neutres [poids: très fort] − Expressivité appliquée à tous les éléments [poids: fort, négatif]

- **Sens de chaque variable** : un bouton expressif (grande taille, couleur primaire, forme distinctive) ressort sur fond de composants neutres ; si tous les composants sont expressifs, aucun ne ressort.
- **Zone de bascule** : vues marketing vs vues fonctionnelles — les vues marketing peuvent supporter plus d'expressivité visuelle car l'objectif est l'impact, pas l'action rapide. Les vues fonctionnelles (formulaires, settings) doivent favoriser la clarté sur l'expressivité.
- **Raison généralisable** : l'expressivité est un langage de contraste — elle communique "ceci est important par rapport à cela". Supprimez le relatif, et le signal disparaît.

---

**H3 — Design basé sur les objectifs : identifier avant de concevoir**

Pertinence du design ∝ Alignement avec les objectifs primaires de l'utilisateur [poids: fort] + Clarté des objectifs identifiés [poids: modéré] − Design basé sur les capacités du produit [poids: fort, négatif]

- **Méthode** : pour chaque vue, poser "quelle est la 1 chose que l'utilisateur vient faire ici ?" avant de commencer la disposition. Cet objectif primaire détermine l'élément visuellement dominant.
- **Zone de bascule** : vues multi-usage (dashboard, profil) — identifier les 2 objectifs les plus fréquents et les distinguer visuellement ; accepter que les objectifs moins fréquents soient moins proéminents.
- **Cas d'inversion** : onboarding et tutoriels — l'objectif est l'exploration, pas l'action directe ; réduire la saillance des actions pour encourager la découverte progressive.
- **Raison généralisable** : un produit conçu autour de ce qu'il peut faire plutôt que de ce que l'utilisateur veut faire produit une interface "complète" mais déroutante.

---

**H4 — Charge cognitive : seuils de complexité**

Utilisabilité ∝ Nombre d'éléments interactifs visibles [poids: fort, négatif si élevé] + Clarté des labels [poids: fort] − Ambiguïté des actions disponibles [poids: fort, négatif]

- **Seuil pratique** : > 7 ± 2 éléments interactifs distincts dans le champ de vision immédiat → risque de surcharge. Grouper, masquer dans un overflow, ou distribuer sur plusieurs vues.
- **Zone de bascule** : vues d'experts (outils pro, dashboards de données) — les experts tolèrent plus de densité car ils connaissent le système. Vues grand public → préférer la progressivité (reveal sur action).
- **Raison généralisable** : la mémoire de travail humaine est limitée à 4-7 éléments simultanés — au-delà, le coût de navigation mentale augmente et les erreurs augmentent.

---

**H5 — Itération : valider avant de figer**

Qualité d'utilisabilité réelle ∝ Nombre d'itérations testées [poids: fort] + Diversité des testeurs [poids: modéré] − Confiance dans l'intuition du designer [poids: modéré, négatif]

- **Sens de chaque variable** : même un designer expérimenté a des angles morts sur sa propre création — 5 utilisateurs suffisent pour révéler 85% des problèmes d'utilisabilité majeurs (règle de Jakob Nielsen).
- **Zone de bascule** : délai vs qualité — quand tester n'est pas possible avant la release, prioriser les tests sur les flux critiques (onboarding, action primaire, gestion d'erreur) et laisser les flux secondaires pour plus tard.
- **Raison généralisable** : l'utilisabilité est une qualité émergente — elle ne peut pas être entièrement prédite à partir des specs, elle se révèle dans l'usage réel.

---

## Règles Do / Don't

✅ **Do :** Identifier l'objectif primaire de chaque vue avant de commencer la disposition.
✅ **Do :** Limiter à 3 niveaux de hiérarchie visuelle par vue.
✅ **Do :** Utiliser les 5 tactiques expressives par contraste, pas uniformément.
✅ **Do :** Tester avec 5 utilisateurs réels minimum avant de valider un flux critique.
✅ **Do :** Grouper les actions secondaires (overflow, sheet) pour préserver la clarté principale.
❌ **Don't :** Rendre tous les composants expressifs — l'expressivité uniformisée devient du bruit.
❌ **Don't :** Concevoir en partant des capacités du produit plutôt que des objectifs utilisateur.
❌ **Don't :** Ignorer le coût cognitif de chaque élément ajouté à une vue.
❌ **Don't :** Traiter un flux comme "utilisable" sans test utilisateur réel.

---

## Traduction en application concrète

- **En cadrage de vue** : commencer chaque vue par 1 phrase : "L'utilisateur vient ici pour ___." → cela définit l'élément visuellement dominant.
- **En revue de design** : identifier le FAB ou le CTA primaire, puis vérifier : est-il perceptivement le plus saillant ? Sinon, quels éléments lui font concurrence et pourquoi ?
- **En test** : effectuer un test de "5 secondes" (montrer la vue 5s, demander ce que l'utilisateur peut faire) — si la réponse ne nomme pas l'action primaire, la hiérarchie est à retravailler.
