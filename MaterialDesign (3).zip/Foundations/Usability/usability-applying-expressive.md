---
source: https://m3.material.io/foundations/usability/applying-m-3-expressive
category: Foundations / Usability
spec-version: v0.192
---

# Usability — Appliquer M3 Expressive

Périmètre : application concrète des tactiques expressives · flux complets · best practices · exemple Aura

---

## Schéma de pensée

Appliquer M3 Expressive à l'utilisabilité n'est pas un exercice de style — c'est une méthode itérative pour que chaque décision visuelle serve un objectif utilisateur précis. L'exemple de l'app Aura (app de respiration) illustre comment les 5 tactiques (conteneur, taille, forme, couleur, typographie) s'enchaînent à travers un flux complet pour guider l'utilisateur d'une étape à l'autre sans ambiguïté. Le principe directeur : chaque écran a un seul objectif → une seule chose visuellement dominante → tout le reste est support.

---

## Principes

- **Un objectif par écran, une dominante visuelle** : l'expressivité sert l'objectif de l'écran, pas la personnalité visuelle du produit.
- **Progression de l'expressivité** : l'intensité visuelle peut varier selon l'étape du flux — forte pour attirer l'attention sur une action nouvelle, réduite pour les étapes répétitives ou de focus.
- **Cohérence des tactiques à travers le flux** : utiliser les mêmes leviers visuels pour les mêmes types d'actions → l'utilisateur apprend le langage visuel de l'app.
- **Les états d'interface sont des narratifs visuels** : l'interface en cours d'action (breathing session active) doit être visuellement distincte de l'interface en attente — la forme, la couleur et la taille changent pour communiquer l'état.
- **Tester à chaque étape, pas seulement à la fin** : l'expressivité qui semble évidente au designer peut perturber l'utilisateur — valider à chaque nœud décisionnel du flux.

---

## Heuristiques

**H1 — Mapper chaque tactique expressive à un objectif de flux**

Cohérence expressive ∝ Alignement tactique-objectif [poids: fort] + Cohérence inter-écrans [poids: fort] − Application décorative des tactiques [poids: fort, négatif]

| Objectif de l'écran | Tactique principale recommandée | Pourquoi |
|--------------------|--------------------------------|---------|
| Démarrer une action (CTA primaire) | Couleur + taille | Attirer l'attention sur le point d'entrée |
| Action en cours (état actif) | Forme + animation | Communiquer que quelque chose se passe |
| Résultat / confirmation | Typographie + conteneur | Mettre en avant l'information-clé reçue |
| Navigation entre états | Taille relative | Signaler ce qui est actif vs inactif |
| Saisie d'information | Conteneur | Délimiter la zone d'interaction |

- **Zone de bascule** : quand plusieurs tactiques s'appliquent légitimement — choisir la plus lisible à distance (taille > forme > couleur > typographie en termes de lisibilité à faible attention).
- **Raison généralisable** : chaque tactique a un "coût" d'attention différent — la taille est perçue en vision périphérique, la couleur nécessite plus de focus, la typographie requiert la lecture.

---

**H2 — Transitions d'état expressives : signaler le changement**

Compréhension de l'état ∝ Différentiation visuelle entre états [poids: fort] + Fluidité de la transition [poids: modéré] − Changement d'état silencieux [poids: fort, négatif]

- **Sens de chaque variable** : une interface qui change d'état sans signal visuel (ou sonore) clair laisse l'utilisateur incertain de ce qui s'est passé — surtout critique pour les états actifs (session en cours, traitement en cours).
- **Leviers de signalement d'état** : changement de couleur de surface (inactif → `primary-container`), changement de forme (carré → rounded), animation de contenu (pulsation, progression).
- **Zone de bascule** : états de courte durée (< 1s) — une animation est suffisante. États prolongés (session active, chargement long) — maintenir un indicateur visuel persistant tout au long de l'état.
- **Raison généralisable** : l'utilisateur doit pouvoir répondre à "où en suis-je dans le flux ?" en un regard — sans cela, l'anxiété d'interface augmente et les abandons aussi.

---

**H3 — Best practices : séquencer les tactiques sur un flux**

Fluidité du flux ∝ Progression logique des tactiques [poids: fort] + Réduction de l'expressivité aux étapes familières [poids: modéré] − Expressivité maximale à toutes les étapes [poids: modéré, négatif]

- **Pattern éprouvé** :
  1. **Entrée dans le flux** → forte expressivité (couleur vive, taille grande, forme distinctive) — attirer, rassurer sur l'action disponible
  2. **Exécution du flux** → expressivité réduite → focus sur le contenu ou l'état en cours, pas sur les CTAs
  3. **Confirmation/résultat** → expressivité ciblée sur l'information-clé du résultat
  4. **Navigation vers la suite** → signal clair de la prochaine étape possible
- **Zone de bascule** : flux très courts (< 3 étapes) — l'expressivité peut rester constante. Flux longs (> 5 étapes) — nécessairement réduire entre les étapes pour éviter la fatigue visuelle.
- **Raison généralisable** : l'expressivité maximale permanente n'est plus expressive — elle devient le nouveau baseline et perd son pouvoir signalétique.

---

**H4 — Test d'utilisabilité des choix expressifs**

Validation de l'expressivité ∝ Tests réels avec utilisateurs [poids: fort] + Mesure comportementale (temps de réaction, erreurs) [poids: fort] − Évaluation interne uniquement [poids: fort, négatif]

- **Ce qu'il faut mesurer** : temps pour identifier l'action primaire, taux d'erreur de navigation, compréhension de l'état actif (demander "que se passe-t-il là maintenant ?").
- **Signal d'alarme** : si > 30% des testeurs ratent l'action primaire au premier regard → la hiérarchie visuelle est insuffisante.
- **Zone de bascule** : test de 5 secondes vs test de parcours complet — le test 5s valide la hiérarchie de l'écran individuel ; le parcours complet valide la cohérence du flux.
- **Raison généralisable** : l'expressivité qui "fonctionne" en review de design (contexte de création, pleine attention) peut échouer en usage réel (distraction, contexte mobile, vitesse).

---

## Checklist d'application par écran

Pour chaque écran d'un flux, valider :

| Question | Réponse attendue |
|----------|-----------------|
| L'objectif de cet écran est-il clair en une phrase ? | Oui → définir la dominante visuelle |
| L'action primaire est-elle le plus grand / le plus coloré élément interactif ? | Oui |
| Y a-t-il plus de 3 niveaux de hiérarchie visuelle ? | Non |
| L'état actuel du flux est-il visible sans chercher ? | Oui |
| La transition vers l'état suivant est-elle clairement signalée ? | Oui |
| L'expressivité de cet écran a-t-elle été testée avec des utilisateurs ? | Oui (ou planifié) |

---

## Règles Do / Don't

✅ **Do :** Mapper chaque tactique expressive à un objectif utilisateur précis, pas à un effet visuel.
✅ **Do :** Réduire l'expressivité aux étapes d'exécution d'un flux — le focus doit être sur le contenu.
✅ **Do :** Tester la lisibilité de la hiérarchie avec le test des 5 secondes.
✅ **Do :** Signaler visuellement (et/ou auditivement) tout changement d'état de l'interface.
❌ **Don't :** Maintenir une expressivité forte sur toutes les étapes d'un long flux.
❌ **Don't :** Utiliser les tactiques expressives comme décoration sans objectif utilisateur attaché.
❌ **Don't :** Valider l'expressivité uniquement en review interne — les biais de concepteur sont trop forts.

---

## Traduction en application concrète

- **En design de flux** : créer un tableau avec les colonnes [Écran, Objectif utilisateur, Tactique principale, Indicateur de succès] avant de commencer les maquettes.
- **En critique de design** : pour chaque choix expressif visible, demander "quelle action/état cela aide-t-il l'utilisateur à identifier ?" Si la réponse est "c'est joli", reconsidérer.
- **En test** : mener un test de parcours en demandant aux testeurs de "penser à voix haute" à chaque écran — les moments de silence ou d'hésitation révèlent les ruptures d'expressivité.
