---
source: https://m3.material.io/foundations/writing
category: Foundations / Accessibility
spec-version: v0.192
---

# Accessibility — Texte & Écriture accessible

Périmètre : alt text, légendes, texte intégré aux images, couleur du texte, redimensionnement

---

## Schéma de pensée

Le texte accessible est la couche de traduction entre le visuel et l'auditif : chaque image doit pouvoir être "lue" par un lecteur d'écran avec la même densité d'information que ce qu'elle communique visuellement. Les règles de rédaction d'alt text, de légendes et de labels combinent économie de mots et précision sémantique — deux exigences qui s'opposent si on ne comprend pas le rôle de chaque type de texte.

---

## Principes

- **Alt text = traduction, pas description** : l'objectif est de communiquer le sens et le contexte de l'image, pas d'en inventorier les détails visuels.
- **Décoration vs information** : une image sans apport informationnel reçoit `alt=""` (masqué aux AT) — exposer du bruit aux lecteurs d'écran est aussi néfaste que de masquer de l'information.
- **Contexte adjacent prime** : l'alt text s'écrit en fonction du texte environnant — la même image aura un alt text différent dans un article de mode vs dans un tutoriel technique.
- **Texte intégré aux images** : les AT ne peuvent pas lire le texte rendu dans une image — tout texte essentiel intégré visuellement doit figurer dans l'alt text ou le contenu adjacent.
- **Redimensionnement** : le texte doit rester lisible et fonctionnel jusqu'à 200% de zoom sans perte d'information ni défilement horizontal (WCAG 1.4.4).

---

## Heuristiques

**H1 — Décider si une image nécessite un alt text**

Nécessité d'alt text ∝ Information perdue si l'image est retirée [poids: très fort] − Redondance avec le texte adjacent [poids: modéré]

- **Sens de chaque variable** : si supprimer l'image n'enlève aucune information, c'est décoratif → `alt=""`. Si l'image apporte une information absente du texte, un alt text est requis.
- **Zone de bascule** : les images ambiguës (ni purement décoratives, ni pleinement informatives) — poser la question : "Un utilisateur aveugle manquerait-il quelque chose d'utile sans cette image ?" Si oui, écrire l'alt text.
- **Raison généralisable** : exposer un alt text vide (`alt=""`) est une décision active et correcte — l'absence totale d'attribut `alt` est une erreur (le lecteur d'écran lit alors le nom du fichier).

---

**H2 — Rédiger un alt text efficace**

Qualité d'alt text ∝ Précision sémantique [poids: fort] + Économie de mots [poids: fort] + Cohérence avec le contexte adjacent [poids: modéré] − Redondance avec la légende [poids: fort, négatif]

- **Règle de longueur** : ≤ 140 caractères — certains lecteurs d'écran tronquent au-delà.
- **Ne pas commencer par "image de"** : les AT annoncent déjà "image" — double annonce = expérience dégradée.
- **Formule chart/graphe** : "Résumé de [type de données] + [raison de l'afficher]" — capturer l'insight principal, pas énumérer les points de données.
- **Zone de bascule** : deux images identiques peuvent avoir des alt texts différents si leur contexte differ (shopping app vs article de déco) — l'alt text suit le contexte, pas l'image.
- **Raison généralisable** : l'alt text est une reformulation de l'intention de l'image dans son contexte, pas une description photographique.

---

**H3 — Couleur du texte et contraste**

Lisibilité du texte ∝ Rapport de contraste fond/texte [poids: très fort] − Usage de couleur seule pour distinguer les éléments essentiels [poids: fort, négatif]

- **Seuils** : texte standard → ≥ 4.5:1 ; grand texte (≥18pt ou 14pt bold) → ≥ 3:1 ; éléments fonctionnels → ≥ 3:1.
- **Éléments non-essentiels** : séparateurs décoratifs, ombres, arrière-plans de surface — pas de seuil WCAG, mais rester vigilant sur la perception.
- **Zone de bascule** : les états disabled M3 réduisent délibérément l'opacité (38%) pour signaler l'inactivité — c'est une exception documentée où le contraste sous le seuil est intentionnel et acceptable car l'élément n'est pas interactif.
- **Raison généralisable** : un texte insuffisamment contrasté est inutilisable dans un contexte difficile (soleil, fatigue, basse vision) — le contraste WCAG est le minimum, pas l'optimum.

---

**H4 — Texte redimensionnable**

Robustesse au zoom ∝ Usage d'unités relatives (rem, em, %) [poids: fort] + Layouts fluides [poids: modéré] − Conteneurs de hauteur fixe avec overflow:hidden [poids: fort, négatif]

- **Cible** : texte lisible et fonctionnel jusqu'à 200% de zoom navigateur sans défilement horizontal.
- **Zone de bascule** : les composants M3 avec des hauteurs fixes (chips à 32px, buttons à 40px) peuvent tronquer le texte à grande taille — tester avec les préférences de grande taille de texte OS activées.
- **Raison généralisable** : les utilisateurs basse vision utilisent le zoom navigateur ET la mise à l'échelle OS simultanément — les layouts qui ne gèrent qu'un des deux échouent dans le cas réel.

---

## Règles Do / Don't

✅ **Do :** Écrire l'alt text en fonction du contexte adjacent (pas de l'image seule).
✅ **Do :** Utiliser `alt=""` pour les images décoratives (décision active, pas un oubli).
✅ **Do :** Limiter l'alt text à 140 caractères.
✅ **Do :** Pour les graphes éditoriaux : capturer l'insight principal dans l'alt text.
❌ **Don't :** Commencer l'alt text par "image de" ou "photo de".
❌ **Don't :** Répéter la légende mot pour mot dans l'alt text — double annonce.
❌ **Don't :** Omettre l'attribut `alt` — le lecteur d'écran lit alors le nom du fichier.
❌ **Don't :** Intégrer du texte essentiel uniquement dans une image.

---

## Traduction en application concrète

- **En UX writing** : pour chaque image dans les specs, rédiger l'alt text recommandé directement dans la documentation — ne pas laisser ce choix aux développeurs.
- **En review** : vérifier que toutes les `<img>` ont `alt` (même vide), que les SVG interactifs ont `aria-label`, que les textes dans les images critiques sont dupliqués en texte.
- **En test d'accessibilité** : activer TalkBack/VoiceOver et naviguer visuellement fermé — l'alt text doit suffire pour comprendre la page sans voir les images.
