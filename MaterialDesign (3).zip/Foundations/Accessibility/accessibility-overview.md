---
source: https://m3.material.io/foundations/overview
category: Foundations / Accessibility
spec-version: v0.192
---

# Accessibility — Vue d'ensemble & Principes

Périmètre : principes directeurs d'accessibilité · assistive technology · design inclusif

---

## Schéma de pensée

L'accessibilité dans M3 n'est pas une couche optionnelle ajoutée après coup — c'est une valeur fondatrice intégrée dès la conception des composants. Anticiper la diversité des utilisateurs (motricité, vue, audition, cognition, situations temporaires) coûte moins cher que de corriger après, et produit des interfaces meilleures pour tous. La norme WCAG est le seuil minimal, pas le plafond.

---

## Principes

- **Honorer l'individu** : les expériences universelles ne satisfont personne pleinement — intégrer des options de personnalisation (taille de texte, contraste, préférences motion) dans le flux par défaut.
- **Apprendre avant d'agir** : la recherche inclusive avant de concevoir évite les biais de représentation et ouvre des solutions inattendues (dark mode, TTS, STT sont nés de contraintes d'accessibilité).
- **Les exigences comme tremplin** : WCAG pose un plancher ; les contraintes d'accessibilité ont historiquement produit des fonctionnalités plébiscitées par tous (sous-titres, raccourcis clavier).
- **Conditions changeantes** : une personne peut être valide le matin et en situation de handicap situationnel (bras cassé, soleil dans les yeux) l'après-midi — concevoir pour un spectre d'états, pas pour un profil fixe.
- **Accessibilité par défaut dans M3** : les composants Material embarquent le markup sémantique, les rôles ARIA et les cibles tactiles — ne pas reconstruire ce qui est déjà fourni.

---

## Heuristiques

**H1 — Accessibilité par défaut vs sur-mesure**

Qualité d'accessibilité ∝ Utilisation de composants natifs [poids: fort] + Markup sémantique [poids: fort] − Composants custom non testés [poids: fort, négatif]

- **Sens de chaque variable** : un composant natif (Button, Dialog, Switch M3) embarque automatiquement les rôles, états et interactions clavier/AT ; un composant custom ne bénéficie d'aucun de ces acquis sans effort explicite.
- **Zone de bascule** : si un composant custom est inévitable (besoin fonctionnel non couvert par M3), le coût en tests AT (TalkBack, VoiceOver, JAWS) doit être planifié — pas ignoré.
- **Raison généralisable** : chaque point de divergence par rapport au natif crée une dette d'accessibilité invisible jusqu'au test réel.

---

**H2 — Personnalisation comme levier d'accessibilité**

Impact sur l'inclusivité ∝ Nombre d'adaptations utilisateur possibles [poids: fort] + Profondeur de chaque adaptation [poids: modéré] − Complexité de la configuration [poids: modéré, négatif]

- **Sens de chaque variable** : plus un utilisateur peut adapter l'interface (taille police, thème sombre, réduction de motion), plus il peut compenser ses limitations propres ; si la configuration est trop complexe, l'adaptation reste théorique.
- **Zone de bascule** : entre personnalisation riche et surcharge cognitive de la configuration — préférer des adaptations qui s'appliquent au niveau système (respecter `prefers-reduced-motion`, `prefers-color-scheme`, mise à l'échelle du texte OS) plutôt que de recréer ces options in-app.
- **Raison généralisable** : les paramètres système représentent les préférences stables de l'utilisateur ; les ignorer force à dupliquer et à maintenir des réglages in-app qui divergeront.

---

**H3 — Anticipation vs réaction**

Coût total de mise en accessibilité ∝ Phase d'intégration [poids: très fort] − Nombre d'itérations de correction [poids: modéré]

- **Sens de chaque variable** : intégrer l'accessibilité en phase de conception coûte une fraction du coût d'un retrofit post-lancement ; chaque sprint de correction post-launch découvre en cascade d'autres problèmes.
- **Zone de bascule** : sur les écrans secondaires (settings, onboarding, pages de données), la tentation est de "faire l'accessibilité plus tard" — c'est là où la dette s'accumule silencieusement.
- **Raison généralisable** : l'accessibilité n'est pas un test final, c'est une contrainte de conception ; la traiter comme un test produit des interfaces techniquement conformes mais cognitiement hostiles.

---

## Règles Do / Don't

✅ **Do :** Utiliser les composants natifs M3 — ils embarquent le markup AT.
✅ **Do :** Respecter les préférences système (motion réduit, contraste élevé, taille de texte).
✅ **Do :** Inclure des utilisateurs handicapés dans les tests utilisateurs.
❌ **Don't :** Créer des composants custom pour des tâches standard — risque d'accessibilité élevé.
❌ **Don't :** Traiter WCAG comme un plafond — c'est un seuil minimal.
❌ **Don't :** Reporter l'accessibilité à la phase de QA — coût 5–10× plus élevé qu'en conception.

---

## Traduction en application concrète

- **Audit d'une interface** : pour chaque composant interactif custom, vérifier : rôle sémantique correct ? État communiqué aux AT ? Navigation clavier possible ? Cible tactile ≥ 48×48dp ?
- **Spec de conception** : annoter chaque livrable avec le nom du composant M3 natif utilisé, son rôle ARIA, et les états (disabled, focused, selected) et leur traduction textuelle pour les AT.
- **Décision de composant** : si un besoin semble justifier un composant custom, poser d'abord : "Quel composant M3 standard est le plus proche ?" et documenter pourquoi il ne suffit pas avant de partir en custom.
