---
source: https://m3.material.io/foundations/designing
category: Foundations / Accessibility
spec-version: v0.192
---

# Accessibility — Concevoir pour l'accessibilité

Périmètre : structure, contraste couleur, flux de navigation, markup sémantique

---

## Schéma de pensée

Rendre une interface accessible visuellement suppose trois traductions successives : transformer une UI visuelle en expérience linéaire textuelle (pour les AT), garantir que la couleur et le contraste supportent la navigation, et s'assurer que la structure logique correspond à la structure de code. Ignorer l'une de ces trois traductions produit une interface accessible "sur le papier" mais inutilisable en pratique.

---

## Principes

- **Trois axes de conception accessible** : Structure (logique de navigation), Couleur & contraste (lisibilité), Flux (ordre de focus et de lecture).
- **Le markup d'accessibilité est une livrables de design** : annoter les specs avec les rôles, labels et états — pas uniquement les visuels.
- **Natif avant custom** : les éléments HTML sémantiques et les contrôles platform-natifs embarquent automatiquement le support AT sans effort supplémentaire.
- **Contraste couleur** : minimum 4.5:1 pour le texte standard, 3:1 pour les grands textes (≥18pt / ≥14pt bold) et les composants d'interface fonctionnels (icônes, bordures de champs).

---

## Heuristiques

**H1 — Structure : traduire le visuel en linéaire**

Lisibilité AT de l'interface ∝ Cohérence entre ordre visuel et ordre de focus [poids: fort] + Hiérarchie de titres correcte [poids: fort] − Éléments décoratifs exposés aux AT [poids: modéré, négatif]

- **Sens de chaque variable** : un utilisateur de lecteur d'écran navigue linéairement ; si l'ordre de tab/focus ne correspond pas à l'ordre visuel logique, il se retrouve dans des sections hors contexte. Les éléments purement décoratifs exposés créent du bruit.
- **Zone de bascule** : les grids et layouts flexbox créent souvent un ordre DOM différent de l'ordre visuel (reorder CSS) — tester avec un lecteur d'écran réel, pas seulement en inspectant le DOM.
- **Raison généralisable** : la structure linéaire est le modèle mental des AT ; tout reordering visuel crée une divergence à gérer explicitement.

---

**H2 — Contraste couleur : seuils WCAG vs perception**

Accessibilité chromatique ∝ Rapport de contraste [poids: très fort] − Usage de la couleur seule comme seul vecteur d'information [poids: fort, négatif]

- **Seuils opérationnels** :
  - Texte normal : contraste ≥ **4.5:1** (AA)
  - Grand texte (≥ 18pt ou ≥ 14pt bold) : ≥ **3:1**
  - Composants fonctionnels (boutons, champs, icônes actives) : ≥ **3:1**
  - Éléments décoratifs : aucun seuil
- **Zone de bascule** : les states M3 (hover, pressed, focused) utilisent des overlays à opacité variable — vérifier que le contraste reste conforme même dans l'état hover/focused/disabled.
- **Cas d'inversion** : en mode "contraste élevé" activé par l'utilisateur, les composants M3 basculent automatiquement vers un schéma à fort contraste — ne pas écraser ce comportement avec des couleurs fixes.
- **Raison généralisable** : la couleur est le vecteur d'information le plus rapidement détruit (daltonisme, écran en plein soleil) — toujours doubler avec forme, icône ou texte.

---

**H3 — Flux de focus : indicateur visible et logique**

Qualité du flux clavier ∝ Visibilité de l'indicateur de focus [poids: fort] + Cohérence de l'ordre de tab [poids: fort] − Trappes de focus non intentionnelles [poids: fort, négatif]

- **Indicateur de focus M3** : `md-sys-color.secondary` outline visible par défaut sur tous les composants interactifs — ne pas le supprimer via `outline: none` sans fournir un équivalent visible.
- **Zone de bascule** : les dialogs et sheets modales doivent capturer le focus à l'ouverture et le restaurer au composant déclencheur à la fermeture (focus trap intentionnel).
- **Raison généralisable** : un utilisateur clavier perd complètement le contexte si l'indicateur de focus n'est pas visible — c'est aussi grave que de supprimer le curseur souris.

---

**H4 — Markup : annotation de spec comme livrable**

Couverture AT d'une interface ∝ Annotations de spec complètes [poids: fort] − Implémentation "au jugé" du développeur [poids: modéré, négatif]

- **Contenu minimal d'une annotation accessible** : rôle sémantique, label textuel (si pas de texte visible), états (disabled, selected, expanded, checked) et leur traduction AT.
- **Zone de bascule** : les icônes seules sans label visible nécessitent impérativement un label AT — un bouton d'icône sans `aria-label` est muet pour un lecteur d'écran.
- **Raison généralisable** : ce que le designer ne spécifie pas, le développeur l'implémente de façon aléatoire — le markup AT doit être aussi précis que les tokens de couleur.

---

## Règles Do / Don't

✅ **Do :** Utiliser les éléments natifs (platform dialog vs custom banner) — AT support inclus.
✅ **Do :** Vérifier le contraste dans tous les états d'interaction (hover, disabled, focus).
✅ **Do :** Annoter les specs avec les rôles, labels et états AT.
✅ **Do :** Tester l'ordre de focus avec Tab uniquement (sans souris).
❌ **Don't :** Supprimer `outline` sans équivalent de focus visible.
❌ **Don't :** Véhiculer une information par la couleur seule — toujours doubler.
❌ **Don't :** Utiliser un composant non-standard pour une tâche couverte par un natif.

---

## Traduction en application concrète

- **En spec** : livrer chaque écran avec une annotation AT layer : rôles, labels, ordre de focus numéroté, états et leurs descriptions verbales.
- **En review de code** : vérifier systématiquement que `outline: none` n'apparaît pas sans `:focus-visible` alternatif ; que les images ont `alt` ; que les champs ont `<label>` ou `aria-label`.
- **En test** : effectuer un parcours clavier complet (Tab, Shift+Tab, Enter, Space, Escape) sur chaque flux critique avant chaque release.
