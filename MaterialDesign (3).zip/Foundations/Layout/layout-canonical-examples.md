---
source: https://m3.material.io/foundations/layout/canonical-examples
category: Foundations / Layout
spec-version: v0.192
---

# Canonical Examples — Heuristiques de décision

Périmètre : layouts canoniques M3 · feed · list-detail · supporting pane · layouts custom · adaptation aux breakpoints

---

## Schéma de pensée

Les layouts canoniques M3 sont des patterns de disposition éprouvés qui résolvent les problèmes d'adaptation aux breakpoints pour les trois types de contenu les plus courants : collections (feed), navigation entre éléments (list-detail) et contenu avec contexte (supporting pane). Utiliser un layout canonique comme point de départ — plutôt que de concevoir from scratch — garantit que l'adaptation Compact → Medium → Expanded est correctement gérée et que les composants de navigation se trouvent aux bons endroits. Ce sont des gabarits de départ, pas des contraintes — ils peuvent être combinés et étendus.

---

## Principes

- **3 layouts canoniques** : Feed (collections), List-Detail (navigation entre items), Supporting Pane (contenu + contexte).
- **Gabarit, pas contrainte** : utiliser comme point de départ pour créer des layouts custom — pas besoin de les implémenter à l'identique.
- **Chaque layout répond à un type de contenu** : le choix du layout dépend de la nature des données, pas de l'espace disponible.
- **L'adaptation aux breakpoints est intégrée** : chaque layout canonique a sa déclinaison Compact / Medium / Expanded.
- **Layering pour les layouts custom** : superposer des composants scaffold (sheets, dialogs) sur des layouts canoniques pour créer des expériences complexes.

---

## Vue d'ensemble des 3 layouts canoniques

| Layout | Type de contenu | Compact | Medium | Expanded |
|--------|----------------|---------|--------|---------|
| **Feed** | Collections homogènes (cards, items) | 1 colonne | 2 colonnes | 3-4 colonnes |
| **List-Detail** | Items exploitables avec détail | Liste plein écran, détail sur nav | Liste + détail 50/50 | Liste étroite + détail large |
| **Supporting Pane** | Contenu principal + contexte | Pane unique + overlay | Contenu + pane latéral visible | 2/3 contenu + 1/3 contexte |

---

## Heuristiques

**H1 — Choisir le bon layout canonique**

Adéquation layout-contenu ∝ Nature des données à afficher [poids: très fort] + Comportement de navigation attendu [poids: fort] − Choix basé sur l'espace disponible [poids: modéré, négatif]

| Si le contenu est… | Layout recommandé |
|-------------------|------------------|
| Une collection d'éléments homogènes à parcourir (articles, produits, images) | **Feed** |
| Une liste d'items dont chacun a un détail à explorer | **List-Detail** |
| Un contenu principal accompagné d'informations contextuelles ou d'actions liées | **Supporting Pane** |
| Un flux de travail multi-étapes ou un outil avec panneaux | **Custom (layering)** |

- **Zone de bascule** : apps dont le contenu combine plusieurs types (ex: liste d'emails + preview + liste de dossiers) — commencer par le layout dominant et enrichir avec des panneaux supplémentaires.
- **Raison généralisable** : le layout façonne le modèle mental de l'utilisateur sur comment naviguer le contenu — choisir selon la nature des données garantit l'alignement avec les comportements naturels de navigation.

---

**H2 — Feed : adaptation par colonnes**

Densité d'information ∝ Nombre de colonnes [poids: fort] + Taille des cards [poids: modéré] − Cards trop petites pour être lisibles [poids: fort, négatif]

| Breakpoint | Colonnes | Taille de card |
|------------|---------|----------------|
| Compact (< 600dp) | 1 | Pleine largeur |
| Medium (600–839dp) | 2 | ~270–300dp |
| Expanded (840dp+) | 3–4 | ~200–250dp |

- **Règle de lisibilité** : une card doit rester lisible (titre visible, image reconnaissable) à toutes les tailles — si le contenu devient illisible à 2 colonnes en medium, réduire à 1.
- **Zone de bascule** : contenu hétérogène (différentes hauteurs de cards) — utiliser `StaggeredGrid` / Masonry pour éviter les espaces vides dans la grille.
- **Raison généralisable** : le feed est une invitation à l'exploration visuelle — la densité augmente avec l'espace mais la lisibilité de chaque item doit toujours être préservée.

---

**H3 — List-Detail : ratio et navigation**

Efficacité de la navigation ∝ Visibilité simultanée liste+détail [poids: fort] + Ratio adapté à l'espace [poids: modéré] − Navigation série sur grand écran (liste → détail → retour) [poids: fort, négatif]

| Breakpoint | Comportement |
|------------|-------------|
| Compact | Liste et détail sur des écrans séparés (navigation classique) |
| Medium | Liste (40%) + Détail (60%) côte à côte |
| Expanded | Liste (30%) + Détail (70%) côte à côte |

- **Sélection par défaut** : sur Medium/Expanded, toujours pré-sélectionner le premier item de la liste pour éviter l'état "pane de détail vide".
- **Zone de bascule** : si la liste est courte (< 5 items) ou si le détail est très long → envisager Supporting Pane plutôt que List-Detail.
- **Raison généralisable** : le pattern List-Detail reproduit le comportement naturel de "choisir puis examiner" — sur grand écran, voir les deux simultanément réduit les allers-retours et accélère les décisions.

---

**H4 — Supporting Pane : ratios et dismissal**

Équilibre contenu/contexte ∝ Importance relative des deux panneaux [poids: fort] + Accès au pane secondaire [poids: modéré] − Pane secondaire qui écrase le contenu principal [poids: fort, négatif]

| Configuration | Ratio | Cas d'usage |
|--------------|-------|------------|
| Standard | 2/3 contenu + 1/3 contexte | Contenu principal dominant (article + notes) |
| Étendu | 1/2 + 1/2 | Collaboration, edition simultanée |
| Compact (pane secondaire modal) | 100% + overlay | Informations contextuelles optionnelles |

- **Pane secondaire optionnel** : sur Compact, le pane secondaire apparaît en bottom sheet ou side sheet modal — il ne remplace pas l'écran principal.
- **Zone de bascule** : si le contenu du pane secondaire est aussi important que le principal → utiliser List-Detail plutôt que Supporting Pane.
- **Raison généralisable** : "supporting" est le mot-clé — le pane secondaire supporte le contenu principal, il ne le concurrence pas.

---

**H5 — Layouts custom : layering sur les canoniques**

Flexibilité du layout ∝ Construction sur base canonique [poids: fort] + Layering ciblé de composants scaffold [poids: modéré] − Layouts entièrement custom from scratch [poids: modéré, négatif]

- **Stratégies de layering** :
  - **Levitate** : un pane flotte au-dessus du contenu (ex : panier d'achat sur une page produit)
  - **Sheet contextuelle** : bottom sheet ou side sheet ajoutée sur un feed ou list-detail
  - **Panneau supplémentaire** : third pane pour les apps très denses (email avec liste de dossiers + liste de mails + preview)
- **Zone de bascule** : > 3 panes simultanés → risque de surcharge sur Expanded. Réserver aux applications professionnelles avec utilisateurs avancés.
- **Raison généralisable** : partir d'un layout canonique garantit que la navigation et les composants scaffold sont correctement positionnés — le custom se construit sur cette fondation, il ne la remplace pas.

---

## Références d'implémentation

| Type | Ressource |
|------|----------|
| Design | M3 Design Kit (Figma) |
| Android Compose | `Jetpack Compose: Canonical layouts` |
| Android Views | `MDC-Android: Canonical layouts` (GitHub) |

---

## Règles Do / Don't

✅ **Do :** Choisir le layout canonique selon la nature du contenu, pas selon l'espace disponible.
✅ **Do :** Pré-sélectionner un item par défaut dans List-Detail sur Medium/Expanded.
✅ **Do :** Utiliser les layouts canoniques comme point de départ puis les enrichir.
✅ **Do :** Implémenter les 3 breakpoints (Compact, Medium, Expanded) pour chaque layout.
❌ **Don't :** Utiliser List-Detail sur Compact sans navigation séparée (liste → détail).
❌ **Don't :** Laisser le pane de détail vide sans sélection par défaut.
❌ **Don't :** Forcer 3-4 panneaux simultanés sur des apps grand public.
❌ **Don't :** Construire un layout custom from scratch sans vérifier si un canonique ne couvre pas le besoin.

---

## Traduction en application concrète

- **En architecture d'information** : classifier chaque écran principal selon Feed / List-Detail / Supporting Pane avant de commencer les maquettes.
- **En spec** : livrer les 3 variantes breakpoint de chaque layout canonique utilisé — Compact, Medium, Expanded.
- **En Compose** : utiliser `ListDetailPaneScaffold`, `NavigationSuiteScaffold` — les composants Compose Material3 Adaptive implémentent les canoniques nativement.
