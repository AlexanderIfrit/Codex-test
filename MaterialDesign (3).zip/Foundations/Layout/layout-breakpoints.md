---
source: https://m3.material.io/foundations/layout/breakpoints
category: Foundations / Layout
spec-version: v0.192
---

# Breakpoints — Heuristiques de décision

Périmètre : 5 breakpoints M3 · appareils · orientations · fenêtres dynamiques · adaptation de layout

---

## Schéma de pensée

Les breakpoints M3 ne correspondent pas à des appareils — ils correspondent à des tailles de fenêtre disponible. Un même téléphone peut passer de Compact (portrait) à Expanded (landscape) ; une tablette en mode split-screen peut être Compact même si l'écran physique est grand. La fenêtre est la vérité, pas l'appareil. Cette distinction est fondamentale pour les apps qui vivent dans des environnements multi-window (Android, desktop).

---

## Les 5 breakpoints M3

| Breakpoint | Largeur (dp) | Appareils typiques |
|------------|-------------|-------------------|
| **Compact** | < 600dp | Téléphone portrait |
| **Medium** | 600–839dp | Tablette portrait · Foldable portrait (déplié) |
| **Expanded** | 840–1199dp | Téléphone landscape · Tablette landscape · Foldable landscape · Desktop |
| **Large** | 1200–1599dp | Desktop |
| **Extra-large** | ≥ 1600dp | Desktop · Ultra-wide monitors |

> ⚠️ Concevoir pour les breakpoints, pas pour les appareils — l'espace de fenêtre est dynamique (multi-window, split-screen, orientation).

---

## Navigation recommandée par breakpoint

| Breakpoint | Navigation primaire | Navigation secondaire |
|------------|--------------------|-----------------------|
| Compact | Navigation Bar (bas) | Bottom Sheet |
| Medium | Navigation Rail (gauche) | Navigation Bar (certains cas) |
| Expanded | Navigation Drawer modal | Navigation Rail |
| Large | Navigation Drawer permanent | Navigation Rail |
| Extra-large | Navigation Drawer permanent | Tabs ou panneau supplémentaire |

---

## Contenu par breakpoint

| Breakpoint | Colonnes de grille | Panes typiques |
|------------|-------------------|----------------|
| Compact | 4 colonnes | 1 pane |
| Medium | 12 colonnes | 1–2 panes |
| Expanded | 12 colonnes | 2 panes |
| Large | 12 colonnes | 2–3 panes |
| Extra-large | 12 colonnes | 3 panes |

---

## Heuristiques

**H1 — Fenêtre vs appareil : toujours utiliser la fenêtre**

Adaptabilité correcte ∝ Détection de la taille de fenêtre [poids: très fort] − Détection du type d'appareil [poids: fort, négatif]

- **Cas problématiques** : un téléphone en landscape est en Expanded (840dp+) — si le code détecte "téléphone", il applique Compact incorrectement.
- **Foldables** : un foldable déplié portrait peut être Medium ; le même en landscape est Expanded — la même session peut traverser plusieurs breakpoints.
- **Zone de bascule** : multi-window Android — une app en split-screen à 50% d'un écran 1080p est en Compact (540dp) même si l'écran physique est grand.
- **Raison généralisable** : la fenêtre est la seule vérité — les APIs `WindowSizeClass` (Android) et les media queries CSS (width) sont les sources correctes, pas `Build.MODEL` ou `navigator.userAgent`.

---

**H2 — Transitions entre breakpoints : quoi changer**

Qualité de l'adaptation ∝ Changements significatifs au bon moment [poids: fort] − Trop de changements simultanés [poids: modéré, négatif]

**Au passage Compact → Medium :**
- Swap Navigation Bar → Navigation Rail
- Révéler un panneau latéral si contenu list-detail
- Passer de 4 colonnes à 12 colonnes de grille

**Au passage Medium → Expanded :**
- Swap Navigation Rail → Navigation Drawer (modal → permanent progressivement)
- Diviser en 2 panes si le contenu le permet
- Augmenter les marges et la largeur max du contenu

**Au passage Expanded → Large/XL :**
- Navigation Drawer devient permanent (toujours visible)
- 3 panes possibles pour des apps très denses en contenu
- Marges augmentées pour éviter les lignes de texte trop longues

- **Zone de bascule** : Large et Extra-large ont les mêmes composants qu'Expanded — les différences sont de densité, de marges et de longueur de ligne, pas de navigation.
- **Raison généralisable** : changer trop d'éléments simultanément à un breakpoint perturbe l'utilisateur — prioriser les changements structurels (navigation, panes) et laisser le contenu s'adapter progressivement.

---

**H3 — Breakpoints de hauteur (vertical)**

Usage des height breakpoints ∝ Contenu sensible à la hauteur [poids: modéré] − Layouts verticalement scrollables [poids: fort, négatif]

- **Compact height** : < 480dp — clavier virtuel ouvert en mode paysage sur téléphone.
- **Medium height** : 480–899dp — standard.
- **Expanded height** : ≥ 900dp — grand écran vertical.
- **Usage rare** : la plupart des contenus scrollent verticalement → la hauteur est rarement une contrainte. S'y intéresser uniquement pour : dialogs (ne pas dépasser la hauteur disponible), bottom sheets (hauteur max), claviers (repositionner le contenu).
- **Zone de bascule** : en Compact height (clavier ouvert paysage), les éléments fixes (App Bar + Bottom Nav + clavier) peuvent ne laisser que 100–150dp de hauteur — réduire ou masquer les éléments non-essentiels.

---

**H4 — Largeur maximale du contenu**

Lisibilité ∝ Largeur du corps de texte [poids: fort] − Lignes de texte trop longues [poids: fort, négatif]

- **Longueur de ligne optimale** : 45–75 caractères — au-delà, le retour à la ligne fatigue le regard.
- **Sur Large/XL (1200dp+)** : ne pas étirer le contenu sur toute la largeur — centrer avec des marges augmentées ou des colonnes max.
- **Valeur max recommandée** : `max-width: 1440px` pour le contenu principal centré sur XL.
- **Zone de bascule** : grids de cards — peuvent profiter de toute la largeur (4–5 colonnes sur XL). Le texte long ne doit jamais.
- **Raison généralisable** : un écran très large avec du texte pleine largeur n'est pas plus lisible — les grands écrans révèlent plus de contenu en parallèle, ils ne rendent pas le contenu existant plus large.

---

## Comportements aux breakpoints — Composants clés

| Composant | Compact | Medium | Expanded |
|-----------|---------|--------|---------|
| FAB | Bas droite | Bas droite | Centre (canonical) ou bas |
| App Bar | Small (collapsing) | Medium | Large |
| Navigation | Bottom Nav Bar | Rail | Drawer |
| Dialog | Pleine largeur (-16dp) | Max 560dp centré | Max 560dp centré |
| Bottom Sheet | Pleine largeur | Max 640dp centré | Side Sheet ou max 640dp |

---

## Règles Do / Don't

✅ **Do :** Détecter la taille de fenêtre (WindowSizeClass / media query width), pas le device.
✅ **Do :** Swap Navigation Bar → Rail → Drawer aux bons breakpoints.
✅ **Do :** Augmenter les marges et limiter la largeur max du texte sur Large/XL.
✅ **Do :** Tester avec multi-window et foldables en différentes orientations.
❌ **Don't :** Détecter l'appareil (téléphone/tablette) pour choisir le layout.
❌ **Don't :** Garder Navigation Bar sur Medium et Expanded.
❌ **Don't :** Étirer le texte long sur toute la largeur d'un grand écran.
❌ **Don't :** Ignorer les breakpoints de hauteur quand le clavier est ouvert.

---

## Traduction en application concrète

- **En Android/Compose** : utiliser `WindowSizeClass` de Jetpack Compose pour détecter le breakpoint actif.
- **En web** : media queries `@media (min-width: 600px)`, `(min-width: 840px)`, `(min-width: 1200px)`.
- **En spec** : livrer un tableau par écran avec les 3 variantes Compact/Medium/Expanded annotées.
- **En test** : vérifier les 5 breakpoints + orientation + multi-window + foldable déplié/replié.
