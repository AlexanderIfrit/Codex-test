---
source: https://m3.material.io/foundations/layout/bidirectionality-rtl
category: Foundations / Layout
spec-version: v0.192
---

# Bidirectionality & RTL — Heuristiques de décision

Périmètre : layouts miroir · éléments qui basculent vs qui restent · icônes directionnelles · texte & typographie · implémentation

---

## Schéma de pensée

La bidirectionnalité n'est pas un problème de traduction — c'est un problème de logique spatiale. Dans une interface RTL (arabe, hébreu, persan, ourdou…), le flux de lecture va de droite à gauche, ce qui signifie que la hiérarchie spatiale est inversée : l'élément de départ est à droite, la progression va vers la gauche. Les composants dont la position ou la direction encode un sens (retour arrière, avance, début/fin) doivent être miroirs. Les éléments dont la position est arbitraire (logo, horloge) ne changent pas. Distinguer ces deux catégories est la compétence centrale de la bidirectionnalité.

---

## Principes

- **Mirroring = inverser la logique spatiale, pas tout l'écran** : seuls les éléments dont la position encode un sens directionnel basculent.
- **Le texte gère son propre bidi** : Android, iOS et le Web ont un support natif du bidi textuel (Unicode Bidi Algorithm) — ne pas le reconstruire manuellement.
- **Les icônes directionnelles basculent, les icônes universelles restent** : une flèche "retour" bascule en RTL ; une icône de téléphone ou de poignée de main ne bascule pas.
- **Les layouts de composants M3 basculent automatiquement** dans les frameworks natifs (Compose, Android Views) en activant RTL — ne pas réécrire les composants pour RTL.
- **Tester sur device réel ou émulateur RTL** : les bugs bidi sont souvent invisibles en LTR et se révèlent uniquement quand le layout entier est mirrored.

---

## Règle de classification : bascule ou pas ?

| Élément | Bascule en RTL ? | Raison |
|---------|-----------------|--------|
| Layouts (navigation, contenu, panes) | ✅ Oui | La progression spatiale est sémantique |
| Icônes directionnelles (flèche arrière, forward, next) | ✅ Oui | Elles encodent une direction |
| Icônes de lecture (play, pause, media controls) | ✅ Oui | Convention : lecture = direction naturelle |
| Icônes universelles (téléphone, email, burger menu) | ❌ Non | Pas de sens directionnel |
| Horloge, graphiques circulaires | ❌ Non | Convention universelle sens horaire |
| Texte dans les images | ❌ Non | Faire une image séparée si besoin |
| Barres de progression | ✅ Oui | Début → fin suit la direction de lecture |
| Sliders | ✅ Oui | Min (début) est à droite en RTL |
| Navigation Bar / Rail / Drawer | ✅ Oui | Position de la navigation bascule |
| Logo de marque | ❌ Non | Identité fixe |
| Chiffres | ❌ Non | Chiffres arabes/indiens selon contexte |

---

## Heuristiques

**H1 — Identifier les éléments à mirrorer vs fixer**

Correction du layout RTL ∝ Identification correcte des éléments directionnels [poids: très fort] + Usage du mirroring automatique du framework [poids: fort] − Mirroring universel de tout l'écran [poids: fort, négatif] − Oubli d'un élément directionnel [poids: fort, négatif]

- **Test de classification rapide** : se demander "si cet élément était dans un livre traduit en arabe, sa position/orientation changerait-elle ?" → oui : bascule. Non : reste.
- **Zone de bascule** : icônes ambiguës (ex : icône de "partage" selon la plateforme) — vérifier les guidelines spécifiques de la plateforme cible.
- **Raison généralisable** : un mirroring aveugle de tout l'écran crée des bugs sur les éléments universels (horloge mirrorée, logo mirroré) ; un mirroring incomplet laisse des incohérences sémantiques.

---

**H2 — Texte et typographie en bidi**

Lisibilité bidi ∝ Algorithme bidi natif [poids: fort] + Police supportant les glyphes RTL [poids: fort] − Concaténation de chaînes LTR+RTL en code [poids: fort, négatif]

- **Sens de chaque variable** : le système de rendu de texte natif (Android/iOS/Web) gère automatiquement le mélange LTR/RTL dans un même paragraphe (Unicode Bidi Algorithm) — le reconstruire manuellement produit des résultats incorrects.
- **Police** : vérifier que la police sélectionnée supporte les glyphes arabes, hébreux ou persian — Roboto ne les supporte pas ; utiliser Noto ou une police spécifique.
- **Zone de bascule** : chaînes mixtes (nom de marque LTR dans un texte RTL) — utiliser les caractères de contrôle Unicode bidi (`&lrm;`, `&rlm;`) pour forcer la direction sur des séquences ambiguës, pas du CSS arbitraire.
- **Raison généralisable** : les bugs bidi textuel surviennent presque toujours dans les chaînes construites dynamiquement en code (concaténation) — tester avec des données réelles en arabe, pas des placeholders.

---

**H3 — Navigation et App Bar en RTL**

Cohérence de navigation RTL ∝ Inversion correcte de la position des éléments [poids: fort] + Comportement des gestes (back gesture) [poids: fort] − Copy-paste du layout LTR [poids: fort, négatif]

- **App Bar** : le bouton "retour" passe de gauche à droite en RTL. Les actions (icônes) passent de droite à gauche.
- **Navigation Drawer** : s'ouvre depuis la droite en RTL.
- **Back gesture** : le swipe "retour" Android s'inverse automatiquement en RTL (swipe depuis la gauche en LTR → swipe depuis la droite en RTL) — ne pas intercepter ce geste manuellement.
- **Zone de bascule** : apps avec navigation complexe (tabs + drawer + FAB) — tester chaque composant de navigation individuellement en mode RTL avant de valider le layout global.
- **Raison généralisable** : une App Bar avec le bouton retour mal positionné est la première chose que voit un utilisateur RTL — c'est un signal fort d'une app non adaptée.

---

**H4 — Implémentation : activer RTL sans réécrire**

Coût d'implémentation RTL ∝ Usage des API de layout natifs [poids: très fort] − Positionnement absolu (left/right) [poids: fort, négatif] − Composants custom non RTL-aware [poids: fort, négatif]

- **En Android/Compose** : utiliser `start`/`end` au lieu de `left`/`right` dans tous les attributs de positionnement — `Modifier.padding(start = 16.dp)` au lieu de `Modifier.padding(left = 16.dp)`.
- **En Web** : utiliser les propriétés logiques CSS (`margin-inline-start`, `padding-block-end`, `inset-inline`) au lieu des propriétés physiques — elles s'inversent automatiquement avec `dir="rtl"`.
- **En Flutter** : `TextDirection.rtl` appliqué au `MaterialApp` + propriétés logiques dans les widgets.
- **Zone de bascule** : animations et transitions avec des offsets directionnels — vérifier que les offsets s'inversent correctement (une animation d'entrée depuis la droite en LTR doit venir de la gauche en RTL).
- **Raison généralisable** : chaque propriété physique (`left`, `right`) codée en dur est une dette RTL — les APIs logiques sont la solution systémique, pas l'exception.

---

## Checklist RTL par composant

| Composant | À vérifier |
|-----------|-----------|
| App Bar | Bouton back à droite, titre aligné à droite, actions à gauche |
| Navigation Drawer | S'ouvre depuis la droite |
| Lists | Leading icon à droite, trailing icon à gauche, texte aligné à droite |
| Sliders | Min à droite, max à gauche |
| Progress bars | Progression de droite à gauche |
| Cards | Image leading à droite si applicable |
| Bottom Sheets | Handles centrés (pas d'impact RTL) |
| Dialogs | Boutons : action principale à gauche, annulation à droite (inverse de LTR) |

---

## Règles Do / Don't

✅ **Do :** Utiliser les propriétés logiques CSS et les attributs `start`/`end` Android dès le départ.
✅ **Do :** Activer RTL sur l'émulateur et tester visuellement chaque écran.
✅ **Do :** Distinguer icônes directionnelles (basculent) vs icônes universelles (restent).
✅ **Do :** Laisser l'algorithme bidi natif gérer le texte mixte LTR/RTL.
❌ **Don't :** Utiliser `left`/`right` en CSS ou Android pour des éléments positionnés sémantiquement.
❌ **Don't :** Mirrorer les logos, horloges, graphiques circulaires.
❌ **Don't :** Construire les chaînes bidi textuelles manuellement en code.
❌ **Don't :** Tester RTL uniquement avec du texte placeholder — utiliser du vrai texte arabe/hébreu.

---

## Traduction en application concrète

- **En spec** : annoter chaque composant custom avec "bascule RTL : oui/non" et la règle de mirroring.
- **En code** : ajouter un linter pour détecter les propriétés physiques CSS (`margin-left`, `right`, etc.) dans les fichiers de composants.
- **En test** : activer le mode RTL dès la première sprint de développement — découvrir les problèmes RTL en fin de projet coûte 3–5× plus cher.
