---
source: https://m3.material.io/foundations/layout/grids-spacing
category: Foundations / Layout
spec-version: v0.192
---

# Grids & Spacing — Heuristiques de décision

Périmètre : grille de colonnes · gouttières · marges · espacement 4dp · alignement

---

## Schéma de pensée

La grille et l'espacement sont les outils qui transforment un ensemble d'éléments en une interface perçue comme ordonnée. En M3, l'unité de base est 4dp — tous les espacements sont des multiples de 4. La grille à colonnes (4 sur compact, 12 sur medium+) gère l'alignement horizontal ; les tokens de spacing (`spacing-100` à `spacing-1000`) gèrent les distances internes et externes. Ces deux systèmes combinés réduisent les décisions d'espacement à des choix entre valeurs prédéfinies.

---

## Système de grille M3

| Breakpoint | Colonnes | Gouttière | Marge |
|------------|---------|---------|-------|
| Compact (< 600dp) | **4** | 16dp | 16dp |
| Medium (600–839dp) | **12** | 16dp | 24dp |
| Expanded (840dp+) | **12** | 24dp | 24dp |

---

## Tokens d'espacement (base 4dp)

| Token | Valeur |
|-------|--------|
| `spacing-50` | 2px |
| `spacing-100` | 4px |
| `spacing-200` | 8px |
| `spacing-300` | 12px |
| `spacing-400` | 16px |
| `spacing-500` | 20px |
| `spacing-600` | 24px |
| `spacing-700` | 28px |
| `spacing-800` | 32px |
| `spacing-900` | 36px |
| `spacing-1000` | 40px |

---

## Heuristiques

**H1 — Utiliser uniquement des multiples de 4dp**

Cohérence visuelle ∝ Respect de l'unité 4dp [poids: fort] − Valeurs d'espacement arbitraires [poids: fort, négatif]

- **Règle** : tous les espacements (padding, margin, gap) doivent être multiples de 4 : 4, 8, 12, 16, 20, 24, 32, 40...
- **Exception documentée** : icônes de taille impaire (18dp, 14dp) — elles-mêmes ne sont pas multiples de 4 mais leur espacement autour doit l'être.
- **Zone de bascule** : des écarts de 2dp (valeur `spacing-50`) sont réservés aux cas de raffinement très fin — ne pas les utiliser pour les espacements standards.
- **Raison généralisable** : les écrans physiques ont des densités de pixels (1x, 2x, 3x) — les valeurs multiples de 4 s'alignent toujours correctement sur grille pixel, les valeurs impaires créent du subpixel rendering.

---

**H2 — Gouttières vs marges vs padding interne**

Alignement précis ∝ Distinction claire gouttière/marge/padding [poids: fort] − Confusion entre les trois types d'espacement [poids: modéré, négatif]

| Type | Définition | Valeur M3 standard |
|------|-----------|-------------------|
| **Marge** | Espace entre le bord de l'écran et le contenu | 16dp (compact) / 24dp (medium+) |
| **Gouttière** | Espace entre deux colonnes | 16dp (compact/medium) / 24dp (expanded) |
| **Padding interne** | Espace entre la bordure d'un composant et son contenu | Variable selon composant (ex: Card → 16dp) |

- **Zone de bascule** : listes en plein écran (List items) vs cards dans une grille — les listes ignorent la gouttière de grille (elles vont d'un bord à l'autre) ; les cards s'alignent sur les colonnes.
- **Raison généralisable** : confondre marge et padding crée des désalignements entre composants — annoter explicitement le type d'espacement dans les specs.

---

**H3 — Espacement interne des composants : relation au token**

Cohérence des composants ∝ Usage des tokens de spacing [poids: fort] − Valeurs ad hoc dans les composants [poids: modéré, négatif]

- **Padding standard des composants M3** :
  - List item : 16dp padding horizontal, 8–12dp vertical
  - Card : 16dp padding sur tous les côtés
  - Dialog : 24dp padding
  - Button : 24dp padding horizontal (avec icon : 16dp leading)
- **Zone de bascule** : composants custom — toujours choisir parmi les tokens de spacing, jamais des valeurs libres.
- **Raison généralisable** : les tokens de spacing créent une cohérence perçue même entre des composants qui n'ont pas de relation directe — l'œil détecte une "grammaire d'espacement" commune.

---

## Règles Do / Don't

✅ **Do :** Multiples de 4dp pour tous les espacements.
✅ **Do :** 16dp de marge sur compact, 24dp sur medium+.
✅ **Do :** Aligner le contenu sur les colonnes de la grille (4 sur compact, 12 sur medium+).
✅ **Do :** Distinguer marge / gouttière / padding dans les specs.
❌ **Don't :** Valeurs d'espacement non-multiples de 4 (3dp, 5dp, 7dp, 10dp, 15dp).
❌ **Don't :** Marges inférieures à 16dp sur compact (contenu trop proche des bords).
❌ **Don't :** Aligner sur 4 colonnes en medium/expanded — passer à 12 colonnes.

---

## Traduction en application concrète

- **En Figma** : configurer la grille de mise en page (Layout Grid) avec les valeurs M3 par breakpoint — activer le snapping à la grille.
- **En code** : utiliser `var(--md-sys-spacing-400)` (16px) pour les marges standard, `var(--md-sys-spacing-600)` (24px) pour expanded — jamais des px libres.
- **En spec** : annoter les espacements avec les noms de tokens, pas les valeurs px — la valeur peut changer selon le thème, le token reste stable.
