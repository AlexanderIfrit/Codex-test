---
source: https://m3.material.io/foundations/layout/understanding-layout/overview
category: Foundations / Layout
spec-version: v0.192
---

# Layout Overview — Heuristiques de décision

Périmètre : panes · adaptive design · éléments de layout · navigation · contenu · structure

---

## Schéma de pensée

Le layout en M3 est une réponse à l'espace disponible, pas une contrainte fixe. La stratégie centrale est l'adaptation : un layout qui passe d'un panneau unique (mobile) à deux ou trois panneaux (tablet/desktop) sans redéfinir l'information architecture. Le scaffold fournit les zones standard (navigation, app bar, corps, FAB), les grids fournissent la structure, et les breakpoints définissent les points de transition. Ces trois couches s'organisent de façon prévisible — les maîtriser évite de réinventer des patterns déjà résolus.

---

## Principes

- **Adaptive, pas responsive uniquement** : l'adaptation inclut la réorganisation du contenu (1→2→3 panneaux), pas seulement le redimensionnement.
- **5 breakpoints** : Compact (<600dp) · Medium (600–839dp) · Expanded (840–1199dp) · Large (1200–1599dp) · Extra-large (≥1600dp).
- **Scaffold = structure standard** : app bar + corps + navigation + FAB optionnel. Le scaffold garantit que les composants de navigation occupent toujours les mêmes zones.
- **Reveal, divide, reposition, resize, swap** : 5 stratégies d'adaptation du contenu aux breakpoints.

---

## Éléments fondamentaux du layout

| Élément | Rôle | Position |
|---------|------|---------|
| App Bar (Top) | Titre, actions globales, navigation retour | Haut fixe |
| Navigation Bar | Navigation primaire (compact) | Bas fixe |
| Navigation Rail | Navigation primaire (medium) | Gauche fixe |
| Navigation Drawer | Navigation primaire (expanded) | Gauche fixe ou modal |
| FAB | Action primaire de la vue | Bas droite ou centre |
| Scaffold body | Zone de contenu | Reste de l'espace |

---

## Heuristiques

**H1 — Choisir entre 1, 2 et 3 panneaux**

Richesse du layout ∝ Espace disponible [poids: très fort] + Complexité du contenu [poids: fort] − Fragmentation artificielle sur petit écran [poids: fort, négatif]

| Breakpoint | Pattern de panes recommandé |
|------------|---------------------------|
| Compact (< 600dp) | 1 pane — navigation par screens |
| Medium (600–839dp) | 1–2 panes — liste + détail optionnel |
| Expanded (840dp+) | 2–3 panes — list-detail + panneau supplémentaire |

- **Zone de bascule** : passer de 1 à 2 panes à Medium — uniquement si le contenu s'y prête (liste + détail). Si le contenu est simple et unique, rester sur 1 pane même en Medium.
- **Raison généralisable** : un layout 2-panes sur contenu simple crée de l'espace vide et de la confusion — l'espace supplémentaire doit être utilisé pour révéler du contenu pertinent, pas remplir l'écran.

---

**H2 — 5 stratégies d'adaptation**

Qualité de l'adaptation ∝ Choix de la stratégie alignée avec le contenu [poids: fort] − Redimensionnement uniforme de tout le layout [poids: modéré, négatif]

| Stratégie | Description | Quand l'utiliser |
|-----------|-------------|-----------------|
| **Reveal** | Afficher du contenu caché (panneau latéral, navigation) | Espace supplémentaire permettant plus d'info contextuelle |
| **Divide** | Séparer 2 contenus sur 2 panes | Liste + détail (list-detail pattern) |
| **Resize** | Agrandir les composants proportionnellement | Grids, images, cards |
| **Reposition** | Déplacer des éléments (FAB centre → bas droite) | Ergonomie adaptée à la taille d'écran |
| **Swap** | Remplacer un composant par un autre | Nav Bar → Nav Rail → Nav Drawer selon breakpoint |

- **Zone de bascule** : plusieurs stratégies peuvent s'appliquer simultanément — prioriser Reveal et Divide qui apportent le plus de valeur informative ; Resize seul sans Reveal ni Divide est rarement suffisant.
- **Raison généralisable** : l'espace supplémentaire d'un grand écran est un actif — l'utiliser pour révéler du contexte, pas pour étirer du contenu existant.

---

**H3 — Zones de navigation selon le breakpoint**

Cohérence de navigation ∝ Respect des zones M3 par breakpoint [poids: fort] − Navigation dans des zones non-standard [poids: modéré, négatif]

| Breakpoint | Composant de navigation |
|------------|------------------------|
| Compact (< 600dp) | Navigation Bar (bas) |
| Medium (600–839dp) | Navigation Rail (gauche) |
| Expanded (840dp+) | Navigation Drawer (gauche, permanent ou modal) |

- **Zone de bascule** : Medium avec 3–4 destinations → Navigation Rail standard. Avec 5+ destinations complexes → drawer peut apparaître dès Medium.
- **Raison généralisable** : les zones de navigation M3 correspondent aux zones ergonomiquement confortables selon la taille d'écran (pouce sur le bas pour mobile, main sur le côté pour tablette/desktop).

---

## Règles Do / Don't

✅ **Do :** Adapter la navigation (Bar → Rail → Drawer) selon le breakpoint.
✅ **Do :** Utiliser Reveal pour exploiter l'espace supplémentaire d'un grand écran.
✅ **Do :** Tester les transitions entre breakpoints (pas seulement les cibles finales).
❌ **Don't :** Afficher un layout 2-panes sur contenu simple — laisser l'espace vide si le contenu ne le justifie pas.
❌ **Don't :** Garder une Navigation Bar sur expanded — swap vers Drawer.
❌ **Don't :** Redimensionner uniformément le layout sans révéler de contenu supplémentaire.

---

## Traduction en application concrète

- **En conception** : commencer par le Compact (mobile), puis identifier ce qui peut être révélé ou divisé aux breakpoints supérieurs — ne pas concevoir desktop puis réduire.
- **En spec** : documenter les 3 états principaux (compact/medium/expanded) pour chaque écran et indiquer la stratégie d'adaptation utilisée (reveal/divide/swap).
- **En test** : redimensionner la fenêtre en continu (pas seulement aux breakpoints) — les transitions doivent être fluides et sans saut visuel.
