---
source: https://m3.material.io/foundations/layout/scaffold
category: Foundations / Layout
spec-version: v0.192
---

# Scaffold — Heuristiques de décision

Périmètre : structure de base d'écran · zones de scaffold · App Bar · Navigation · FAB · corps

---

## Schéma de pensée

Le scaffold est la "charpente" d'un écran M3 : il définit les zones standard où chaque type de composant peut vivre. Sa valeur est la prévisibilité — l'utilisateur sait où chercher la navigation, les actions primaires et le titre, quel que soit l'écran. Ne pas utiliser le scaffold (ou le modifier arbitrairement) détruit cette prévisibilité et augmente la charge cognitive.

---

## Zones du scaffold M3

| Zone | Composant | Position |
|------|-----------|---------|
| Top App Bar | App Bar (Small/Medium/Large) | Haut fixe ou scrollable |
| Navigation | Bar / Rail / Drawer | Bas (compact) ou Gauche (medium+) |
| Body | Contenu principal | Reste de l'espace |
| FAB | Floating Action Button | Bas droite ou centre (selon breakpoint) |
| Bottom App Bar | Actions liées au contenu (mobile) | Bas fixe (alternative à la Top App Bar) |
| Snackbar | Feedback temporaire | Au-dessus de la navigation |

---

## Heuristiques

**H1 — Top App Bar : choisir la variante selon le contenu**

Clarté de navigation ∝ Niveau d'importance du titre [poids: fort] + Quantité de contenu scrollable [poids: modéré]

| Variante | Hauteur | Quand l'utiliser |
|----------|---------|-----------------|
| Small | 64dp | Navigation standard, titre court |
| Center-aligned Small | 64dp | Apps de contenu, branding centré |
| Medium | 112dp | Titre de section importante |
| Large | 152dp | Page principale, titre très visible |

- **Collapsing App Bar** : Medium/Large se réduisent à Small au scroll (header scrollable) — pour les pages de contenu long.
- **Zone de bascule** : si le titre est court et la page simple → Small. Si la page est une landing ou un détail avec identité forte → Large.

---

**H2 — FAB : position et visibilité**

Accessibilité de l'action primaire ∝ Visibilité du FAB [poids: fort] + Position ergonomique [poids: fort] − Superposition avec du contenu critique [poids: fort, négatif]

- **Compact** : bas droite, flotte au-dessus du contenu.
- **Medium (avec Rail)** : peut se positionner dans le Rail ou en bas droite.
- **Expanded (avec Drawer permanent)** : centré dans la zone de contenu principale — canonical layout.
- **Zone de bascule** : FAB + Bottom Navigation Bar → le FAB se positionne au centre de la Bottom Nav (embedded FAB) ou juste au-dessus à droite.
- **Raison généralisable** : le FAB doit être accessible en un tap sans déplacer la main — la position bas-droite correspond au pouce naturel en portrait.

---

**H3 — Corps du scaffold : marges et colonnes**

Lisibilité du contenu ∝ Marges adaptées au breakpoint [poids: fort] + Max-width du contenu [poids: modéré]

| Breakpoint | Marge compacte | Marge confortable |
|------------|---------------|------------------|
| Compact | 16dp | 16dp |
| Medium | 24dp | 24dp |
| Expanded | 24dp | 200dp (centré) |

- **Zone de bascule** : sur Expanded+, ne pas laisser le contenu s'étirer à plein écran — définir une max-width et centrer.

---

## Règles Do / Don't

✅ **Do :** Utiliser les zones standard du scaffold — ne pas réinventer la position des composants globaux.
✅ **Do :** Adapter la variante d'App Bar au niveau de la page dans la hiérarchie.
✅ **Do :** Positionner le FAB bas-droite sur compact, centré sur expanded.
❌ **Don't :** Superposer le FAB sur du contenu critique sans inset de scroll.
❌ **Don't :** Mélanger Bottom App Bar et Bottom Navigation sur le même écran.
❌ **Don't :** Changer la position de la navigation entre les écrans d'une même app.

---

## Traduction en application concrète

- **En Compose Android** : `Scaffold()` avec les slots `topBar`, `bottomBar`, `floatingActionButton`, `content` — ne pas construire la structure manuellement.
- **En web** : définir les zones CSS (grid areas ou flexbox) correspondant aux zones scaffold avant de placer les composants.
- **En spec** : annoter les écrans avec les zones scaffold nommées — permet aux développeurs d'implémenter directement sans ambiguïté.
