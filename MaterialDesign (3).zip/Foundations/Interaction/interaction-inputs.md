---
source: https://m3.material.io/foundations/interaction/inputs
category: Foundations / Interaction
spec-version: v0.192
---

# Inputs — Heuristiques de décision

Périmètre : souris · clavier · trackpad · stylet · multi-input · curseur · hover · context menu

---

## Schéma de pensée

Les inputs externes (souris, clavier, trackpad, stylet) ne sont plus réservés aux desktops — ils s'utilisent sur tablettes, téléphones pliables et même téléphones. Concevoir pour plusieurs inputs simultanément n'est pas une option sur ces appareils : un utilisateur peut passer de tactile à souris en une seconde. L'enjeu est de respecter les conventions de chaque input (ce qu'un utilisateur souris attend d'un clic droit, ce qu'un utilisateur clavier attend de Tab) tout en maintenant la cohérence de l'expérience.

---

## Principes

- **Multi-input natif** : le même appareil peut recevoir tactile + souris + clavier simultanément — concevoir pour tous, pas pour un seul.
- **Conventions par input** : chaque device a ses conventions établies (clic droit → context menu, Tab → focus suivant, scroll wheel → défilement) — les respecter est une obligation, pas une option.
- **Cursor visible obligatoire** : dès qu'une souris est connectée, afficher un curseur — quel que soit le type d'appareil.
- **Hover comme état actif** : la souris permet de détecter le hover — l'utiliser pour améliorer la découverte et la lisibilité, pas seulement comme decoration.

---

## Comportements attendus par input

| Action input | Comportement attendu |
|-------------|---------------------|
| Mouvement souris | Curseur visible sur l'écran |
| Clic gauche | Même feedback que tap tactile (ripple) |
| Clic droit | Context menu |
| Hover | Changement d'état du composant (hover state) |
| Sélection texte | Cursor de sélection, highlight |
| Scroll wheel / two-finger drag | Scroll liste (vertical et horizontal) |
| Pinch trackpad | Zoom |
| Clavier physique | Masquer le clavier virtuel |

---

## Heuristiques

**H1 — Détection et adaptation au type d'input**

Qualité d'expérience multi-input ∝ Adaptation au mode d'input actif [poids: fort] + Maintien de la cohérence entre modes [poids: modéré] − Comportements identiques pour tous les inputs [poids: modéré, négatif]

- **Sens de chaque variable** : un clic souris et un tap tactile déclenchent le même résultat fonctionnel mais le feedback visuel peut différer (curseur de sélection de texte n'apparaît qu'en mode souris).
- **Zone de bascule** : sur les appareils qui ne distinguent pas souris et stylet du tactile → traiter comme tactile. Sur les appareils qui les distinguent → adapter les comportements hover et cursor.
- **Raison généralisable** : l'utilisateur n'a pas à changer de mode mentalement quand il change d'input — l'app doit détecter et s'adapter silencieusement.

---

**H2 — Hover : enrichissement vs perturbation**

Valeur du hover ∝ Information additionnelle fournie [poids: fort] + Cohérence avec l'état default [poids: modéré] − Contenu critique exclusivement en hover [poids: très fort, négatif]

- **Hover states M3** : `hovered-state-layer-opacity` = 0.08 (8% overlay de la couleur `on-surface` ou `on-primary`).
- **Utilités légitimes du hover** : révéler des actions secondaires (boutons d'action sur une card), afficher un tooltip, pré-sélectionner un item de liste.
- **Interdit** : placer des informations critiques ou des actions primaires exclusivement en hover — inaccessible au tactile.
- **Zone de bascule** : actions supplémentaires en hover (boutons qui apparaissent sur une card) — toujours accessibles via long press ou menu contextuel en mode tactile.
- **Raison généralisable** : le hover est une amélioration progressive — l'interface doit être 100% fonctionnelle sans lui.

---

**H3 — Navigation clavier : Tab order et focus**

Accessibilité clavier ∝ Ordre de Tab logique [poids: fort] + Indicateur de focus visible [poids: fort] + Gestion des raccourcis clavier [poids: modéré]

- **Tab order** : suivre l'ordre de lecture naturel (gauche-droite, haut-bas en LTR) — tester avec Tab seul sans souris.
- **Focus indicator** : toujours visible (outline M3 sur `secondary`) — ne jamais supprimer `outline: none` sans alternative.
- **Raccourcis clavier** : implémenter les raccourcis standard de la plateforme (Ctrl+Z/Undo, Ctrl+S/Save, Escape/Fermer) — ne pas les redéfinir pour des usages custom.
- **Zone de bascule** : composants complexes (date pickers, menus, dialogs) — implémenter les patterns ARIA keyboard (arrow keys dans les menus, Escape pour fermer) conformément aux spécifications W3C.
- **Raison généralisable** : un utilisateur clavier navigue l'interface linéairement — chaque trap de focus ou saut d'ordre le désorie complètement.

---

**H4 — Context menu (clic droit)**

Utilité du context menu ∝ Pertinence des actions proposées [poids: fort] + Cohérence avec les conventions plateforme [poids: fort] − Actions critiques exclusivement dans le context menu [poids: fort, négatif]

- **Déclenchement** : clic secondaire souris OU deux doigts trackpad OU long press tactile.
- **Contenu** : actions contextuelles liées à l'objet cliqué — pas les actions globales de l'app.
- **Maximum recommandé** : < 7 items (au-delà → sous-menu ou réorganiser la IA).
- **Zone de bascule** : sur mobile sans souris, le context menu doit être accessible via long press ou un bouton overflow visible — ne pas présupposer que l'utilisateur a une souris.
- **Raison généralisable** : le context menu est une convention forte sur desktop — le respecter réduit l'apprentissage ; en créer un non-conventionnel perturbe les utilisateurs expérimentés.

---

**H5 — Scroll wheel et trackpad**

Fluidité de scroll ∝ Scroll physiquement lié au mouvement [poids: fort] + Inertie momentum [poids: modéré] − Scroll intercepté ou non-standard [poids: modéré, négatif]

- **Scroll wheel** : défilement vertical standard — ne pas le remapper sur une action horizontale sans raison explicite.
- **Two-finger drag trackpad** : défilement vertical ET horizontal.
- **Pinch trackpad** : zoom — implémenter si le contenu est zoomable (cartes, images, canvas).
- **Zone de bascule** : composants avec scroll interne (list dans un dialog) + scroll page — gérer correctement l'interception du scroll pour éviter que le scroll de la liste fasse défiler la page derrière.
- **Raison généralisable** : le scroll wheel est le geste le plus fréquent sur desktop — tout comportement inattendu est perçu comme un bug.

---

## Règles Do / Don't

✅ **Do :** Afficher un curseur dès qu'une souris est connectée, quel que soit l'appareil.
✅ **Do :** Implémenter le clic droit → context menu avec actions contextuelles.
✅ **Do :** Maintenir un Tab order logique et un focus indicator visible.
✅ **Do :** Rendre toutes les actions hover-only accessibles autrement (long press, overflow menu).
✅ **Do :** Respecter les raccourcis clavier standard de la plateforme.
❌ **Don't :** Placer des informations ou actions critiques uniquement en hover.
❌ **Don't :** Intercepter le scroll wheel sur des éléments non-scrollables.
❌ **Don't :** Supprimer `outline` sans indicateur de focus alternatif.
❌ **Don't :** Redéfinir des raccourcis clavier standard (Ctrl+Z, Escape) pour des usages custom.

---

## Traduction en application concrète

- **En spec** : documenter les comportements par input (touch, mouse, keyboard) pour chaque composant interactif — pas seulement le comportement touch.
- **En test** : effectuer un test complet clavier (Tab, arrow keys, Enter, Escape, Ctrl+Z) sur chaque flux critique — sans jamais toucher la souris.
- **En review** : vérifier que chaque action accessible en hover est également accessible sans souris (tactile ou clavier).
