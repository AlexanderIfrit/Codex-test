---
source: https://m3.material.io/foundations/interaction/states
category: Foundations / Interaction
spec-version: v0.192
---

# States — Heuristiques de décision

Périmètre : state layers · 5 états interactifs · opacités · combinaisons d'états · disabled

---

## Schéma de pensée

Les états M3 sont une couche de communication entre le système et l'utilisateur : ils informent de l'interactivité, de la position dans le flux, et du résultat d'une action. Le mécanisme central est la **state layer** — un overlay coloré appliqué sur la surface du composant à une opacité précise. Ce mécanisme est unifié : le même système d'overlay fonctionne sur tous les composants, garantissant une cohérence de langage visuel sans exception.

---

## Principes

- **5 états interactifs** : Enabled (default), Hovered, Focused, Pressed, Dragged.
- **2 états non-interactifs** : Disabled, Error.
- **State layer = overlay coloré** : couleur `on-[surface]` appliquée à une opacité précise selon l'état.
- **Combinaisons d'états** : Selected + Hovered, Focused + Selected — les layers se superposent.
- **Disabled ≠ Hidden** : un composant disabled reste visible mais signale son inactivité par l'opacité — ne jamais masquer un disabled.

---

## State layers — valeurs de référence

| État | Couleur overlay | Opacité |
|------|----------------|---------|
| Hovered | `on-surface` (ou `on-primary` selon surface) | **8%** |
| Focused | `on-surface` | **12%** |
| Pressed | `on-surface` | **12%** |
| Dragged | `on-surface` | **16%** |
| Disabled (container) | `on-surface` | **12%** |
| Disabled (content) | `on-surface` | **38%** |

### Sur surfaces colorées (ex: Filled Button)
| État | Couleur overlay | Opacité |
|------|----------------|---------|
| Hovered | `on-primary` | **8%** |
| Focused | `on-primary` | **12%** |
| Pressed | `on-primary` | **12%** |

---

## Heuristiques

**H1 — State layer vs changement de couleur directe**

Cohérence du système ∝ Usage des state layers [poids: fort] − Changement de couleur directe du fond [poids: fort, négatif]

- **State layer = overlay** : ne pas changer la couleur de fond du composant — appliquer un overlay semi-transparent par-dessus. Le fond reste constant, seule la couche d'état change.
- **Avantage** : fonctionne sur n'importe quelle couleur de surface (primary, secondary, surface) sans recalcul.
- **Zone de bascule** : état Selected — le fond change réellement (vers `secondary-container`) car c'est un état persistant différent des états transitoires (hover, focus, pressed).
- **Raison généralisable** : les overlays semi-transparents s'adaptent automatiquement au thème (clair/sombre) sans recalcul — un changement de couleur directe crée une dépendance au thème actif.

---

**H2 — Disabled : visibilité et opacité**

Communication d'inactivité ∝ Réduction d'opacité [poids: fort] − Masquage complet [poids: très fort, négatif]

- **Container disabled** : 12% opacité → surface presque transparente → composant visible mais clairement inactif.
- **Content disabled** : 38% opacité → texte/icône visible mais atténué.
- **Ne jamais masquer** : un composant disabled masqué crée une confusion sur l'existence de la fonctionnalité.
- **Zone de bascule** : désactiver TEMPORAIREMENT vs supprimer définitivement — temporaire → disabled. Définitif → retirer de l'UI (et expliquer ailleurs pourquoi).
- **Raison généralisable** : le disabled à 38% est en dessous du seuil WCAG de contraste — c'est une exception documentée (l'élément non-interactif n'a pas les mêmes exigences de contraste qu'un élément actif).

---

**H3 — Combinaisons d'états**

Lisibilité d'état ∝ Superposition cohérente [poids: fort] + Opacité résultante perceptible [poids: modéré] − Annulation mutuelle des states [poids: modéré, négatif]

- **Selected + Hovered** : fond `secondary-container` + 8% overlay `on-secondary-container`.
- **Focused + Selected** : fond `secondary-container` + 12% overlay + indicateur de focus.
- **Pressed annule visuellement le hover** : pressed remplace hover (12% > 8%, pas d'addition).
- **Zone de bascule** : Dragged (16%) sur fond clair peut paraître trop fort — vérifier le contraste résultant sur le fond spécifique.
- **Raison généralisable** : les combinaisons d'états sont calculées par le système M3 — ne pas les recalculer manuellement, utiliser les tokens composants qui gèrent déjà les états combinés.

---

**H4 — États et accessibilité**

Accessibilité des états ∝ Différentiation non-couleur [poids: fort] + Indication AT des états [poids: fort] − Communication par couleur seule [poids: fort, négatif]

- **Focus** : toujours accompagné d'un indicateur visible (outline M3) — la state layer seule ne suffit pas pour le focus.
- **Disabled** : communiqué via `aria-disabled="true"` — pas seulement via l'opacité.
- **Pressed** : le ripple est le signal visuel principal (animation depuis le point de contact).
- **Error** : communiqué via `role="alert"` ou `aria-invalid="true"` — pas seulement via la couleur `error`.
- **Zone de bascule** : composants sans surface propre (text buttons, icon buttons) — la state layer est appliquée sur un fond transparent → le ripple est le seul feedback visible pressed.

---

## Règles Do / Don't

✅ **Do :** Utiliser les state layers (overlays) pour tous les états transitoires (hover, focus, pressed).
✅ **Do :** Maintenir l'opacité disabled à 38% pour le contenu, 12% pour le container.
✅ **Do :** Toujours doubler les états visuels par des signaux AT (aria-disabled, aria-invalid).
✅ **Do :** Garder les composants disabled visibles (pas masqués).
❌ **Don't :** Changer la couleur de fond directement pour hover/focus/pressed.
❌ **Don't :** Masquer un composant disabled — le rendre opaque à 38%.
❌ **Don't :** Communiquer un état uniquement par la couleur.
❌ **Don't :** Inventer des opacités d'état différentes des valeurs M3 — incohérence dans le système.

---

## Traduction en application concrète

- **En spec** : livrer un tableau d'états pour chaque composant interactif (default, hover, focus, pressed, disabled, selected si applicable) avec les overlays et opacités exactes.
- **En code** : utiliser les composants M3 natifs — ils implémentent automatiquement les state layers. Si composant custom : implémenter via `Ripple` (Android), `:hover`/`:focus-visible` (web) avec les opacités correctes.
- **En test** : vérifier les états sur fond clair ET fond sombre — les overlays semi-transparents doivent rester lisibles dans les deux modes.
