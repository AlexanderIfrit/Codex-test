---
source: https://m3.material.io/foundations/interaction/selection
category: Foundations / Interaction
spec-version: v0.192
---

# Selection — Heuristiques de décision

Périmètre : indicateurs de sélection · types de sélection · sélection multiple · feedback visuel

---

## Schéma de pensée

La sélection est le moyen pour l'utilisateur de signifier "c'est cet élément qui est concerné par ce que je vais faire". Elle doit être instantanément visible, clairement distinguée des autres états (hover, focus, pressed), et réversible à tout moment. Les indicateurs de sélection en M3 reposent sur le changement de couleur de surface et non sur des affordances externes (coches, bordures) — la surface elle-même communique son état.

---

## Principes

- **Visibilité immédiate** : l'indicateur de sélection doit être visible dès le tap/clic — pas après une animation de transition.
- **Surface comme vecteur** : M3 utilise `secondary-container` comme couleur de surface sélectionnée — pas de bordure ni de coche externe requise (bien qu'elles restent optionnelles).
- **Sélection unique vs multiple** : deux patterns distincts — radio-button style (1 seul item) vs checkbox style (plusieurs items).
- **Désélection possible** : toujours permettre à l'utilisateur de désélectionner — une sélection irréversible est une erreur de conception.

---

## Types de sélection et indicateurs

| Type | Indicateur M3 | Cas d'usage |
|------|-------------|------------|
| Item list sélectionné | `secondary-container` background | Navigation items, menus |
| Chip filtrant | `secondary-container` + checkmark icon | Filtres actifs |
| Tab active | Indicateur de ligne sous le label | Navigation entre vues |
| Checkbox checked | Fond `primary` + checkmark | Sélection multiple formulaire |
| Radio selected | Dot `primary` intérieur | Choix exclusif |
| Segmented button | Fond `secondary-container` sur segment actif | Mode actif |

---

## Heuristiques

**H1 — Distinguer sélection de hover et focus**

Clarté de l'état ∝ Différentiation visuelle entre états [poids: fort] + Cohérence de l'indicateur de sélection [poids: fort] − Ambiguïté entre hover et selected [poids: fort, négatif]

- **Hiérarchie des états visuels** :
  - Default : pas d'overlay
  - Hovered : 8% overlay `on-surface`
  - Focused : 12% overlay `on-surface` + indicateur de focus
  - **Selected : fond `secondary-container`** (changement de surface, pas overlay)
  - Selected + Hovered : `secondary-container` + 8% overlay
- **Zone de bascule** : si `secondary-container` est proche visuellement de `surface` dans un thème → risque de confusion selected/default. Ajouter un indicateur secondaire (icône checkmark, bordure légère).
- **Raison généralisable** : la sélection est un état persistant (reste visible après relâchement) ; hover et focus sont transitoires — les traiter avec le même indicateur crée une confusion sur la persistance.

---

**H2 — Sélection multiple : signaler clairement le mode**

Compréhension du mode ∝ Signal d'entrée en mode multi-sélection [poids: fort] + Indicateur de sélection multiple distinctif [poids: fort] − Mode multi-sélection implicite [poids: fort, négatif]

- **Entrée en mode** : long press sur un item pour activer le mode multi-sélection (convention Android) — ne pas activer silencieusement.
- **Indicateur visuel** : checkbox apparaît sur chaque item en mode multi-sélection — remplace l'icon/avatar habituel.
- **Barre d'actions contextuelles** : apparaît en haut de l'écran (contextual action bar) avec les actions disponibles sur la sélection.
- **Zone de bascule** : mode multi-sélection sur desktop (avec clavier) → Ctrl+clic pour ajouter à la sélection, Shift+clic pour sélectionner une plage — comportements clavier attendus.
- **Raison généralisable** : l'utilisateur doit savoir qu'il est dans un mode spécial (multi-sélection) — sinon un tap sur un item peut être interprété comme une navigation au lieu d'une sélection.

---

**H3 — Désélection et sortie de mode**

Contrôle utilisateur ∝ Facilité de désélection [poids: fort] + Cohérence des chemins de sortie [poids: modéré] − Sélection irréversible sans confirmation [poids: fort, négatif]

- **Désélection d'un item** : tap sur l'item sélectionné désélectionne.
- **Sortie du mode multi-sélection** : bouton Annuler dans la barre contextuelle OU désélectionner tous les items.
- **Zone de bascule** : sélection qui déclenche une action immédiate (radio button → charge un contenu) vs sélection accumulée (checkboxes → confirmer après) — distincts visuellement et comportementalement.
- **Raison généralisable** : la possibilité de se tromper et de corriger est fondamentale — une sélection irréversible est une erreur d'UX.

---

## Tokens de design — sélection

| Token | Valeur |
|-------|--------|
| Selected surface | `md-sys-color.secondary-container` |
| Selected text/icon | `md-sys-color.on-secondary-container` |
| Checkbox checked fill | `md-sys-color.primary` |
| Checkbox checked icon | `md-sys-color.on-primary` |
| Hover state overlay | `md-sys-color.on-surface` @ 8% |
| Focus state overlay | `md-sys-color.on-surface` @ 12% |

---

## Règles Do / Don't

✅ **Do :** `secondary-container` comme fond d'un item sélectionné.
✅ **Do :** Différencier clairement hover (overlay) et selected (changement de surface).
✅ **Do :** Toujours permettre la désélection.
✅ **Do :** Signaler l'entrée en mode multi-sélection (long press + checkbox apparente).
❌ **Don't :** Même indicateur visuel pour hover et selected.
❌ **Don't :** Activer silencieusement le mode multi-sélection.
❌ **Don't :** Sélection irréversible sans action de confirmation explicite.

---

## Traduction en application concrète

- **En spec** : annoter les 5 états d'un item sélectionnable (default, hover, focus, selected, selected+hover) avec les overlays exacts.
- **En design** : vérifier que la différence visuelle entre `surface` et `secondary-container` est perceptible dans le thème utilisé — particulièrement en dark mode.
- **En test** : vérifier que la sélection reste visible après hover et focus — les overlays ne doivent pas écraser l'indicateur de sélection.
