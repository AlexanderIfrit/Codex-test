---
source: https://m3.material.io/foundations/interaction/gestures
category: Foundations / Interaction
spec-version: v0.192
---

# Gestures — Heuristiques de décision

Périmètre : types de gestes tactiles · réponse en temps réel · affordances · navigation par gestes

---

## Schéma de pensée

Les gestes sont le langage naturel du tactile — ils permettent de naviguer, d'agir et de transformer le contenu directement avec le doigt. Leur efficacité repose sur deux principes insécables : le retour en temps réel (l'élément suit le doigt immédiatement) et la conformité aux conventions plateforme (les gestes système ne se contredisent pas avec les gestes in-app). Un geste qui ne répond pas en temps réel ou qui entre en conflit avec les gestes système est un geste raté.

---

## Principes

- **Réponse en temps réel** : les éléments UI répondent aux gestes immédiatement — pas de délai perceptible.
- **Conformité aux gestes système** : les gestes de navigation Android/iOS (swipe bords, back gesture) ont priorité — les gestes in-app ne doivent pas les intercepter.
- **Affordance implicite** : les gestes ne sont pas visibles — les affordances visuelles (handles de drag, flèches de swipe) aident à les découvrir.
- **Feedback adapté** : chaque geste produit un retour visuel (déplacement, élasticité, snap) proportionnel à l'action.

---

## Types de gestes M3

| Geste | Action | Composants concernés |
|-------|--------|---------------------|
| Tap | Sélectionner / activer | Tous les composants interactifs |
| Long press | Sélection contextuelle / drag initiation | Lists, cards, grids |
| Swipe | Navigation / dismissal / reveal | Drawers, bottom sheets, snackbars |
| Drag | Réorganiser / déplacer | Lists réordonnables, sliders |
| Pinch | Zoom in/out | Cartes, images, carousels |
| Fling | Scroll momentum | Toutes les listes scrollables |
| Double tap | Zoom rapide | Images, cartes |
| Pull-to-refresh | Rafraîchissement | Listes, feeds |

---

## Heuristiques

**H1 — Temps réel vs délai : seuil de perception**

Fluidité perçue ∝ Latence de réponse [poids: très fort] + Vitesse de suivi du doigt [poids: fort] − Animations bloquantes avant interaction [poids: fort, négatif]

- **Seuil humain** : une latence > 16ms (1 frame à 60fps) est perceptible ; > 50ms crée une sensation de "lag" ; > 100ms brise l'illusion de contrôle direct.
- **Zone de bascule** : animations de composants (ripple, expansion) — elles doivent démarrer avec le geste, pas après sa fin.
- **Raison généralisable** : la sensation de contrôle direct est le facteur principal de qualité perçue sur tactile — elle disparaît dès que l'UI ne suit pas le doigt.

---

**H2 — Conflits avec les gestes système**

Fiabilité de navigation ∝ Espace non-intercepté pour les gestes système [poids: très fort] − Zones d'interception qui chevauchent les gestes système [poids: très fort, négatif]

- **Android back gesture** : zone de 16dp sur les bords gauche/droit de l'écran réservée — ne pas y placer de swipe in-app interceptant.
- **Geste home/task switcher** : bas de l'écran réservé — bottom sheets et swipe-to-dismiss ne doivent pas intercepter sur toute la hauteur.
- **Zone de bascule** : bottom sheets avec swipe-to-dismiss vs Android navigation gesture — différencier par la vélocité (dismiss rapide = action in-app, swipe lent = geste système laissé passer).
- **Raison généralisable** : les gestes système sont des conventions OS que les utilisateurs ont internalisées — les intercepter crée de la frustration et des erreurs de navigation.

---

**H3 — Affordances pour la découverte des gestes**

Découvrabilité ∝ Signaux visuels d'affordance [poids: fort] + Onboarding des gestes non-évidents [poids: modéré] − Gestes implicites sans aucun indice [poids: modéré, négatif]

- **Affordances visuelles communes** : handle de drag (pill/tiret au centre d'un bottom sheet), ombre de card swipeable, flèche de pull-to-refresh.
- **Gestes évidents vs cachés** : tap et swipe sont attendus ; pinch-to-zoom, long press et double-tap nécessitent des affordances ou un onboarding.
- **Zone de bascule** : les gestes "experts" (raccourcis gestuels) peuvent rester cachés si une alternative claire et visible existe — ils ne doivent jamais être le seul chemin vers une action critique.
- **Raison généralisable** : un geste non découvert est un geste inexistant pour l'utilisateur — les affordances transforment des possibilités en fonctionnalités utilisées.

---

## Règles Do / Don't

✅ **Do :** Répondre au geste immédiatement (< 16ms idéalement).
✅ **Do :** Laisser les gestes système Android/iOS passer librement dans leurs zones réservées.
✅ **Do :** Afficher des affordances visuelles pour les gestes non-évidents.
✅ **Do :** Offrir une alternative tap visible pour tout geste caché (swipe, long press).
❌ **Don't :** Intercepter les gestes système dans leurs zones réservées.
❌ **Don't :** Bloquer une animation avant de démarrer la réponse au geste.
❌ **Don't :** Placer des actions critiques exclusivement derrière des gestes cachés.

---

## Traduction en application concrète

- **En spec** : annoter toutes les zones de gestes (swipe zones, drag handles) et leurs interactions avec les gestes système de la plateforme cible.
- **En test** : tester avec la navigation par gestes Android activée (mode sans boutons) — les conflits n'apparaissent que dans ce mode.
- **En design** : pour chaque geste non-standard, prévoir une affordance visuelle ET une alternative accessible par tap.
