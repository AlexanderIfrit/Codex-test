---
name: material-design-foundations
description: >
  Documentation de référence M3 pour les décisions fondationnelles :
  accessibilité, content design, tokens, interaction, layout, usabilité, XR, montres.
  Format : heuristiques pondérées + schémas de pensée + règles Do/Don't + tokens réels (v0.192+).
  À utiliser pour toute question sur l'accessibilité d'une interface, la rédaction UI,
  les systèmes de tokens, les gestes et états d'interaction, les layouts adaptatifs,
  la bidirectionnalité RTL, les layouts canoniques, ou la conception pour la montre et la XR.
---

# Material Design 3 — Foundations : Index

> Chaque fichier = schéma de pensée + principes + heuristiques décisionnelles + tokens.
> Format : **jamais un résumé**, toujours des équations pondérées actionnables.

---

## Structure

```
MaterialDesign/Foundations/
├── Accessibility/
│   ├── accessibility-overview.md      → Principes, composants natifs, anti-patterns
│   ├── accessibility-designing.md     → Structure, contraste, flux de focus, markup
│   └── accessibility-writing.md       → Alt text, contraste textuel, redimensionnement
├── BuildingForAll/
│   └── building-for-all.md            → Design inclusif, 13 dimensions, co-design
├── ContentDesign/
│   ├── content-design-overview.md     → Principes fondateurs, rôle du content design
│   ├── content-design-alt-text.md     → Alt text : décision, rédaction, cas par cas
│   ├── content-design-global-writing.md → Localisabilité, expansion texte, genre
│   ├── content-design-notifications.md → Notifications : ciblage, CTA, opt-out
│   └── content-design-style-guide.md  → Casse, conséquences, scannabilité, abréviations
├── CustomizingMaterial/
│   └── customizing-material.md        → Dynamic color, thème custom, source couleur
├── DesignTokens/
│   └── design-tokens.md               → 3 classes (ref/sys/comp), nomenclature, cascade
├── Devices/
│   └── watches.md                     → Wear OS : densité, forme circulaire, navigation
├── Interaction/
│   ├── interaction-gestures.md        → Gestes tactiles, temps réel, conflits système
│   ├── interaction-inputs.md          → Souris, clavier, trackpad, stylet, hover
│   ├── interaction-selection.md       → Indicateurs, sélection unique/multiple, états
│   └── interaction-states.md          → State layers, opacités, combinaisons d'états
├── Layout/
│   ├── layout-overview.md             → Panes, stratégies d'adaptation, scaffold
│   ├── layout-scaffold.md             → Zones scaffold, App Bar, FAB, corps
│   ├── layout-grids-spacing.md        → Grille colonnes, gouttières, tokens 4dp
│   ├── layout-breakpoints.md          → 5 breakpoints, fenêtre vs device, transitions
│   ├── layout-bidirectionality-rtl.md → Mirroring RTL, icônes, implémentation
│   └── layout-canonical-examples.md   → Feed, List-Detail, Supporting Pane, layering
├── Usability/
│   ├── usability-overview.md          → Hiérarchie visuelle, 5 tactiques, charge cognitive
│   └── usability-applying-expressive.md → Application flux complet, test, best practices
└── XR/
    ├── xr-design.md                   → Distance, motion sickness, multi-modal, tokens XR
    └── xr-components.md               → Composants M3 en XR, ajustements, états
```

---

## Index par question de décision

### Accessibilité

| Question | Fichier |
|----------|---------|
| Quels composants M3 embarquent automatiquement le support AT ? | `Accessibility/accessibility-overview.md` |
| Quels seuils de contraste pour le texte, les composants ? | `Accessibility/accessibility-designing.md` |
| Comment annoter les specs pour l'accessibilité ? | `Accessibility/accessibility-designing.md` |
| Indicateur de focus : quand et comment ? | `Accessibility/accessibility-designing.md` |
| Comment rédiger un alt text ? | `Accessibility/accessibility-writing.md` |
| Texte zoomable et redimensionnement : règles ? | `Accessibility/accessibility-writing.md` |
| Design inclusif : quelles dimensions couvrir ? | `BuildingForAll/building-for-all.md` |

### Content Design

| Question | Fichier |
|----------|---------|
| Principes fondateurs du content design M3 | `ContentDesign/content-design-overview.md` |
| Alt text : nécessaire ou pas, comment rédiger ? | `ContentDesign/content-design-alt-text.md` |
| Rédiger pour une audience internationale ? | `ContentDesign/content-design-global-writing.md` |
| Expansion de texte à la traduction ? | `ContentDesign/content-design-global-writing.md` |
| Rédiger une notification efficace ? | `ContentDesign/content-design-notifications.md` |
| Sentence case, conséquences, titres scannables ? | `ContentDesign/content-design-style-guide.md` |

### Tokens & Personnalisation

| Question | Fichier |
|----------|---------|
| Quelle classe de token utiliser (ref/sys/comp) ? | `DesignTokens/design-tokens.md` |
| Convention de nommage des tokens ? | `DesignTokens/design-tokens.md` |
| Tokens vs valeurs hex en dur ? | `DesignTokens/design-tokens.md` |
| Dynamic color vs static color : quand ? | `CustomizingMaterial/customizing-material.md` |
| Thème custom comme infrastructure ? | `CustomizingMaterial/customizing-material.md` |

### Interaction

| Question | Fichier |
|----------|---------|
| Types de gestes, latence, conflits système ? | `Interaction/interaction-gestures.md` |
| Souris, clavier, hover, context menu ? | `Interaction/interaction-inputs.md` |
| Sélection unique vs multiple : indicateurs ? | `Interaction/interaction-selection.md` |
| State layers : opacités hover/focus/pressed/disabled ? | `Interaction/interaction-states.md` |
| Combinaisons d'états (selected + hovered) ? | `Interaction/interaction-states.md` |

### Layout

| Question | Fichier |
|----------|---------|
| 1, 2 ou 3 panes selon le breakpoint ? | `Layout/layout-overview.md` |
| Zones du scaffold, App Bar, FAB ? | `Layout/layout-scaffold.md` |
| Grille, gouttières, marges, tokens 4dp ? | `Layout/layout-grids-spacing.md` |
| 5 breakpoints M3 : valeurs, appareils, transitions ? | `Layout/layout-breakpoints.md` |
| Layout RTL : quoi mirrorer, comment implémenter ? | `Layout/layout-bidirectionality-rtl.md` |
| Feed, List-Detail, Supporting Pane : quand utiliser ? | `Layout/layout-canonical-examples.md` |

### Usabilité

| Question | Fichier |
|----------|---------|
| Hiérarchie visuelle : règles et niveaux ? | `Usability/usability-overview.md` |
| 5 tactiques expressives M3 (conteneur, taille, forme, couleur, typo) ? | `Usability/usability-overview.md` |
| Appliquer M3 Expressive sur un flux complet ? | `Usability/usability-applying-expressive.md` |
| Tester l'utilisabilité d'un choix expressif ? | `Usability/usability-applying-expressive.md` |

### Appareils spécialisés

| Question | Fichier |
|----------|---------|
| Concevoir pour Wear OS (montre) ? | `Devices/watches.md` |
| Cibles tactiles, texte, navigation sur montre ? | `Devices/watches.md` |
| Distance, motion sickness, multi-modal en XR ? | `XR/xr-design.md` |
| Composants M3 en XR : ajustements de taille ? | `XR/xr-components.md` |

---

## Tokens de référence rapide (Foundations)

### State Layers — opacités M3
| État | Opacité overlay |
|------|----------------|
| Hover | 8% |
| Focus | 12% |
| Pressed | 12% |
| Dragged | 16% |
| Selected | fond `secondary-container` (pas overlay) |
| Disabled content | 38% opacité |
| Disabled container | 12% opacité |

### Breakpoints M3
| Nom | Largeur | Navigation |
|-----|---------|-----------|
| Compact | < 600dp | Navigation Bar (bas) |
| Medium | 600–839dp | Navigation Rail (gauche) |
| Expanded | 840–1199dp | Navigation Drawer modal |
| Large | 1200–1599dp | Navigation Drawer permanent |
| Extra-large | ≥ 1600dp | Navigation Drawer permanent |

### Seuils de contraste WCAG
| Contexte | Rapport minimum |
|----------|----------------|
| Texte normal | 4.5:1 |
| Grand texte (≥18pt ou 14pt bold) | 3:1 |
| Composants fonctionnels (boutons, icônes actives) | 3:1 |
| Décoratif | Pas de seuil |
| Disabled (exception documentée) | < 3:1 toléré |

### Grille M3
| Breakpoint | Colonnes | Gouttière | Marge |
|------------|---------|---------|-------|
| Compact | 4 | 16dp | 16dp |
| Medium | 12 | 16dp | 24dp |
| Expanded | 12 | 24dp | 24dp |

---

## Arbitrages courants (Foundations)

| Question | Réponse |
|----------|---------|
| Composant natif M3 ou composant custom ? | Natif sauf si besoin fonctionnel non couvert — le custom crée une dette d'accessibilité. |
| Alt text vide ou absent ? | Vide explicite (`alt=""`) pour les décoratifs — absent est une erreur. |
| Dynamic color ou static color ? | Dynamic si Android 12+, grand public. Static si iOS, enterprise, brand stricte. |
| Token `md.sys` ou `md.ref` dans un composant ? | `md.sys` — les tokens ref bypassen la sémantique et cassent dark mode / dynamic color. |
| Fenêtre ou device pour détecter le breakpoint ? | Fenêtre uniquement (`WindowSizeClass`, media query width). |
| Mirrorer tout l'écran en RTL ou seulement ce qui a du sens ? | Seulement les éléments directionnels — logos, horloges, icônes universelles restent. |
| State layer ou changement de couleur pour hover/focus ? | State layer (overlay semi-transparent) — jamais un changement de couleur de fond direct. |
| 1 écran par objectif ou plusieurs objectifs par écran ? | 1 objectif primaire par écran — les objectifs secondaires sont visuellement récessifs. |
| Tester l'accessibilité en QA ou pendant la conception ? | Pendant la conception — coût 5–10× inférieur qu'en post-lancement. |
| Head-locked ou world-locked pour les éléments UI en XR ? | World-locked — le head-locked provoque de la fatigue et du motion sickness. |
