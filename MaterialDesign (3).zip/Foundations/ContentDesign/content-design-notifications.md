---
source: https://m3.material.io/foundations/content-design/notifications
category: Foundations / Content Design
spec-version: v0.192
---

# Notifications — Heuristiques de contenu

Périmètre : rédaction de notifications · timing · personnalisation · opt-out · texte dynamique

---

## Schéma de pensée

Une notification utile arrive au bon moment, parle à la bonne personne et lui dit ce qu'elle a besoin de faire ou de savoir — pas ce que le produit veut qu'elle voit. Le premier ennemi de la notification est le générique : plus l'audience est large, plus le message est dilué, plus l'utilisateur désactive les notifications entières. La précision est la condition de la pertinence.

---

## Principes

- **À propos de l'utilisateur, pas du produit** : la notification parle de ce qui concerne l'utilisateur, pas de ce que veut mettre en avant l'équipe produit.
- **5 critères de qualité** : précise, opportune, actionnable, contextuelle, pertinente.
- **Contrôle utilisateur** : toujours donner un moyen simple de désactiver les notifications — le respect de l'opt-out préserve la confiance à long terme.
- **Pas de pub non sollicitée** : les notifications ne sont pas un canal marketing déguisé.
- **Information importante en premier** : les utilisateurs scannent en "F" — le sens critique doit être dans le titre, pas dans le corps.

---

## Heuristiques

**H1 — Placement de l'information critique**

Efficacité de la notification ∝ Position de l'information clé [poids: très fort] + Brièveté du titre [poids: fort] − Redondance avec le nom de l'app dans le titre [poids: fort, négatif]

- **Sens de chaque variable** : les utilisateurs lisent en forme de "F" — le premier tiers est vu, le reste souvent ignoré ou tronqué. Mettre le point essentiel en fin de phrase garantit qu'il sera manqué.
- **Zone de bascule** : quand l'action ET le contexte sont tous deux critiques — prioriser l'action dans le titre, le contexte dans le corps.
- **Raison généralisable** : la notification est consommée en split-second dans un contexte de distraction — le titre doit suffire seul à communiquer l'essentiel.

---

**H2 — Personnalisation et ciblage**

Utilité perçue ∝ Spécificité de l'information [poids: fort] + Alignement avec le contexte utilisateur [poids: fort] − Taille de l'audience ciblée [poids: modéré, négatif inversé]

- **Sens de chaque variable** : plus le message est spécifique à la situation de l'utilisateur (localisation, comportement in-app, préférences), plus il est perçu comme utile ; plus l'audience est large, plus le message est générique et ignoré.
- **Zone de bascule** : la personnalisation requiert des données utilisateur — si ces données ne sont pas disponibles, il vaut mieux ne pas envoyer la notification plutôt qu'envoyer un message générique.
- **Raison généralisable** : une notification générique à grande audience dépense le capital d'attention de l'utilisateur pour zéro valeur — chaque notification inutile augmente le risque de désactivation globale.

---

**H3 — CTA (Call To Action) : spécificité et actionnabilité**

Taux d'action ∝ Clarté du CTA [poids: fort] + Spécificité de l'action proposée [poids: fort] + Motivation explicite [poids: modéré]

- **Sens de chaque variable** : un CTA vague ("Voir plus") n'oriente pas l'utilisateur ; un CTA spécifique ("Confirmer votre réservation du 15 mars") lui dit exactement ce qu'il peut faire et pourquoi.
- **Zone de bascule** : deux actions possibles dans une même notification — les rendre mutuellement exclusives et les différencier clairement (action primaire vs action secondaire) plutôt que d'en faire deux options équivalentes.
- **Raison généralisable** : la valeur d'une notification actionnable est directement proportionnelle à la clarté de l'action suivante — l'ambiguïté force l'utilisateur à ouvrir l'app pour comprendre.

---

**H4 — Texte dynamique : risques et bonnes pratiques**

Fiabilité du contenu de notification ∝ Contrôle éditorial [poids: fort] − Usage de texte dynamique non audité [poids: fort, négatif]

- **Problèmes du texte dynamique** : données manquantes ou nulles → message incohérent ; longueur variable → troncature imprévisible ; différences de format entre plateformes → expériences incohérentes.
- **Bonne pratique** : auditer tous les scénarios de valeur nulle/manquante avant déploiement ; prévoir des fallbacks textuels pour chaque variable dynamique.
- **Zone de bascule** : personnalisation forte (prénom, lieu exact, nombre) vs robustesse — si la donnée peut être absente ou incorrecte, le bénéfice de la personnalisation ne vaut pas le risque d'expérience dégradée.
- **Raison généralisable** : une notification avec une variable dynamique incorrecte ("Bonjour [prénom] !" → "Bonjour null !") détruit immédiatement la confiance et est perçue comme une erreur technique, pas comme une tentative de personnalisation.

---

**H5 — Timing et fréquence**

Utilité à long terme ∝ Pertinence temporelle [poids: fort] + Fréquence maîtrisée [poids: fort] − Interruption dans les mauvais contextes [poids: modéré, négatif]

- **Timing pertinent** : une notification de navigation en voiture 5 minutes avant le départ est utile ; la même 12 heures avant est du bruit.
- **Fréquence** : la saturation détruit la valeur de toutes les notifications — mieux vaut envoyer moins avec un signal fort que beaucoup avec un signal faible.
- **Zone de bascule** : notifications transactionnelles (confirmation de commande, alerte sécurité) → haute fréquence acceptable. Notifications marketing/engagement → seuil bas.
- **Raison généralisable** : l'utilisateur accorde une attention limitée aux notifications — les dépenser sur des informations non urgentes dilapide le capital d'attention disponible pour les alertes vraiment importantes.

---

## Règles Do / Don't

✅ **Do :** Mettre l'information la plus importante en tête du titre.
✅ **Do :** Cibler précisément — une notification pertinente pour 10% vaut mieux qu'une générique pour 100%.
✅ **Do :** Rendre l'opt-out simple et accessible.
✅ **Do :** Prévoir des fallbacks pour toutes les variables dynamiques.
✅ **Do :** CTA spécifiques ("Confirmer votre trajet") > CTA vagues ("Voir plus").
❌ **Don't :** Répéter le nom de l'app dans le titre (déjà visible dans le header OS).
❌ **Don't :** Envoyer des notifications publicitaires non sollicitées.
❌ **Don't :** Utiliser des variables dynamiques sans tester les scénarios de valeur nulle.
❌ **Don't :** Envoyer la même notification à toute la base — segmenter.

---

## Traduction en application concrète

- **En UX writing** : template de notification = Titre (information clé + CTA) / Corps (contexte + détails) / Actions (1–2 max, différenciées).
- **En review de copie** : test "titre seul" — si le titre seul ne suffit pas à comprendre l'action, le réécrire.
- **En ingénierie** : documenter chaque variable dynamique avec ses cas limites (null, trop long, format inattendu) et les fallbacks correspondants.
- **En analytics** : monitorer le taux de désactivation des notifications par type — un taux élevé signale soit une mauvaise pertinence, soit une fréquence excessive.
