---
source: https://m3.material.io/foundations/content-design/style-guide
category: Foundations / Content Design
spec-version: v0.192
---

# Style guide — UX Writing & Grammaire UI

Périmètre : capitalisation · conséquences · scannabilité · abréviations · ponctuation

---

## Schéma de pensée

Le texte d'interface n'est pas du contenu éditorial — c'est une infrastructure fonctionnelle. Chaque mot a un coût d'attention et une probabilité d'être mal interprété. Le style guide M3 converge vers un principe : le texte UI doit guider l'action et communiquer les conséquences sans alarmer, condescendre ni ambiguïser. La sentence case et la concision ne sont pas des préférences stylistiques — ce sont des règles d'accessibilité cognitive.

---

## Principes

- **Sentence case universelle** : tout le texte UI (titres, labels, boutons, navigation, dialogs) utilise la casse de phrase (1ère lettre maj, reste minuscule). Exception : noms propres et termes de marque.
- **Conséquences, pas avertissements** : communiquer ce qui arrivera après une action, en langage neutre et direct — éviter les formulations alarmantes ou condescendantes.
- **Scannabilité** : les utilisateurs scannent, ils ne lisent pas — titres spécifiques, hiérarchie visuelle, mots porteurs de sens en position de scan (début de phrase, titre).
- **Abréviations avec parcimonie** : épeler les mots quand possible ; éviter les abréviations latines (e.g., etc.) — préférer les formulations complètes ("par exemple", "et plus").
- **Pas de ponctuation décorative** : les points finaux, points d'exclamation et ellipses ont des rôles précis — ne pas les utiliser pour le style.

---

## Heuristiques

**H1 — Communiquer les conséquences (pas les peurs)**

Clarté décisionnelle ∝ Description neutre des conséquences [poids: fort] + Mention des moyens d'annulation si disponibles [poids: modéré] − Formulations alarmantes ou conditionnelles [poids: fort, négatif]

- **Sens de chaque variable** : "Ce fichier sera définitivement supprimé." → informatif. "Êtes-vous sûr de vouloir supprimer ? Cette action est irréversible !" → alarmant, culpabilisant.
- **Zone de bascule** : actions réellement irréversibles (suppression permanente, envoi d'email) — communiquer la conséquence sans minimiser, mais sans dramatiser : "Cet événement sera supprimé après 30 jours depuis la corbeille." plutôt que "ATTENTION : cette action ne peut pas être annulée !"
- **Raison généralisable** : l'alarme cognitive provoque soit la paralysie (abandon de l'action légitime) soit l'habitude de cliquer sans lire (après plusieurs fausses alertes).

---

**H2 — Sentence case : règle absolue dans M3**

Cohérence perçue ∝ Uniformité de la casse [poids: fort] − Title case sur les éléments UI [poids: fort, négatif]

- **Règle** : sentence case pour titres, sous-titres, labels, éléments de menu, navigation, boutons — tout.
- **Exceptions** : noms propres (Google, Material Design), termes de marque enregistrés.
- **Zone de bascule** : acronymes et sigles → toujours en majuscules (WCAG, HTTP, PDF) même en sentence case.
- **Raison généralisable** : le title case crée une impression de "document formel" incompatible avec la fluidité d'une interface — la sentence case est plus rapide à lire et plus naturelle dans un contexte conversationnel/interactif.

---

**H3 — Scannabilité : structure porteuse de sens**

Efficacité de navigation ∝ Spécificité des titres [poids: fort] + Position des mots-clés [poids: modéré] − Titres génériques ou vagues [poids: fort, négatif]

- **Sens de chaque variable** : un titre spécifique ("Supprimer votre compte") permet de scanner et comprendre sans lire le contenu ; un titre générique ("Attention") oblige à lire le corps entier.
- **Zone de bascule** : équilibre entre spécificité (long) et concision (court) — viser le mot le plus informatif possible en position initiale : "Déconnexion" > "Vous allez être déconnecté".
- **Raison généralisable** : les utilisateurs en action rapide ne lisent pas, ils scannent les titres et boutons — si le titre est vague, l'erreur d'interprétation est probable.

---

**H4 — Abréviations : épeler pour tout le monde**

Compréhension universelle ∝ Mots complets [poids: fort] − Abréviations ambiguës ou latines [poids: modéré, négatif]

- **Abréviations latines à éviter en UI** : e.g., i.e., etc., vs., et al. → remplacer par "par exemple", "c'est-à-dire", "et autres", "par rapport à", "et collaborateurs".
- **Exception** : abréviations universellement comprises dans le contexte (AM/PM sur une horloge, km/h dans une app de navigation).
- **Zone de bascule** : abréviations spécialisées dans un contexte professionnel (sigle d'une industrie) — acceptables si l'audience cible les maîtrise, risquées pour un public général.
- **Raison généralisable** : les lecteurs d'écran peuvent lire les abréviations de façon inattendue ("e.g." → "e, point, g, point") — les éviter améliore l'accessibilité AT sans coût stylistique.

---

## Règles Do / Don't

✅ **Do :** Sentence case sur tout le texte UI.
✅ **Do :** Communiquer les conséquences en langage neutre et direct.
✅ **Do :** Titres spécifiques qui peuvent être compris sans lire le corps.
✅ **Do :** Épeler les mots plutôt qu'abréger.
❌ **Don't :** Title case pour les éléments d'interface.
❌ **Don't :** Formulations alarmantes ou condescendantes ("Êtes-vous sûr de...?").
❌ **Don't :** Abréviations latines (e.g., etc., i.e.) dans le texte UI.
❌ **Don't :** Titres génériques qui nécessitent de lire le corps pour comprendre.
❌ **Don't :** Points d'exclamation pour l'enthousiasme ("Super !") dans les interfaces d'action.

---

## Traduction en application concrète

- **En UX writing** : pour chaque dialog destructif, formuler la conséquence en 1 phrase neutre + mention du mécanisme d'annulation si disponible.
- **En design review** : vérifier que tous les labels visibles dans un écran sont en sentence case — un rapide scan visuel détecte les title cases résiduels.
- **En content audit** : chercher les titres de dialog et de notification qui commencent par "Êtes-vous sûr", "Attention", "Avertissement" — les reformuler en termes de conséquences.
