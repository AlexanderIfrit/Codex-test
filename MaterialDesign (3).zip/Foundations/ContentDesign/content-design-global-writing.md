---
source: https://m3.material.io/foundations/content-design/global-writing
category: Foundations / Content Design
spec-version: v0.192
---

# Global Writing — Écriture Inclusive et Localisable

Périmètre : écriture pour la localisation · choix de mots · structures de phrases · inclusivité culturelle

---

## Schéma de pensée

L'écriture globale part d'un constat : le texte qui sera traduit doit d'abord être simple, direct et culturellement neutre en anglais. Les structures idiomatiques, les jeux de mots, les références culturelles et les tournures ambiguës résistent à la traduction et produisent des interfaces incohérentes ou incompréhensibles dans d'autres langues. Écrire pour la localisation, même pour un produit initialement en anglais uniquement, discipline l'écriture vers plus de clarté pour tous.

---

## Principes

- **Écriture globale = écriture inclusive** : les textes pensés pour la localisation sont plus clairs pour tous les utilisateurs, y compris les non-natifs en anglais.
- **Simplicité structurelle** : phrases courtes, actif de préférence au passif, verbe principal au début.
- **Neutralité culturelle** : éviter les métaphores sportives, les références locales, les idiomes — ils résistent à la traduction et excluent.
- **AP Style par défaut** : suivre l'Associated Press Stylebook sauf indication contraire spécifique à M3.
- **Clarté sur la créativité** : en contexte d'interface, la clarté prime toujours sur l'originalité stylistique.

---

## Heuristiques

**H1 — Test de localisabilité**

Localisabilité du texte ∝ Neutralité culturelle [poids: fort] + Structure syntaxique simple [poids: fort] − Idiomes et métaphores [poids: fort, négatif] − Références culturelles locales [poids: fort, négatif]

- **Sens de chaque variable** : une phrase simple et directe se traduit littéralement dans 90%+ des langues ; un idiome ("hit the ground running") se traduit rarement et peut produire une formulation absurde.
- **Test pratique** : lire la phrase et se demander "un traducteur non-natif en anglais comprendra-t-il exactement ce que je veux dire ?" Si oui, c'est probablement localisable.
- **Zone de bascule** : le marketing copy ou les messages à forte personnalité de marque peuvent justifier des tournures créatives — mais l'interface fonctionnelle (labels, dialogs, erreurs) n'en bénéficie jamais.
- **Raison généralisable** : un texte simple en anglais est un meilleur point de départ pour la traduction — le traducteur n'a pas à deviner l'intention, il traduit le sens explicite.

---

**H2 — Expansion de texte à la traduction**

Robustesse des layouts ∝ Espace buffer prévu pour expansion [poids: fort] − Conteneurs à largeur fixe sur texte UI [poids: fort, négatif]

- **Règle pratique d'expansion** : le texte anglais se dilate en moyenne de 20–30% en français, espagnol, allemand ; certaines langues asiatiques se contractent. Prévoir un buffer de 30–40% dans les conteneurs à texte court (labels, boutons).
- **Zone de bascule** : les boutons et labels courts (1–3 mots) sont les plus risqués — "OK" peut devenir "D'accord" (×3), "Save" peut devenir "Enregistrer" (×2).
- **Raison généralisable** : un layout qui casse en allemand parce que le bouton "Save" est devenu "Speichern" est un problème de design, pas de traduction — il faut prévoir l'espace dès la conception.

---

**H3 — Inclusivité de genre dans l'écriture**

Inclusivité perçue ∝ Formulations neutres en genre [poids: fort] − Suppositions de genre sur l'utilisateur [poids: fort, négatif]

- **En anglais** : utiliser "they/them" singulier au lieu de "he/she" — standard AP Style depuis 2017.
- **En design** : éviter de supposer le genre de l'utilisateur dans les messages ("Bienvenue, Monsieur X").
- **Zone de bascule** : quand l'utilisateur a explicitement renseigné son genre dans son profil → utiliser la formulation adaptée. Si non renseigné → formuler neutre.
- **Raison généralisable** : les suppositions de genre créent des expériences d'exclusion pour les utilisateurs non-binaires et réduisent la confiance globale dans le produit.

---

## Règles Do / Don't

✅ **Do :** Phrases courtes, sujet-verbe-complément, actif.
✅ **Do :** Tester la localisabilité de chaque phrase ("un traducteur comprendrait-il exactement ?").
✅ **Do :** Prévoir 30–40% d'espace buffer pour les labels courts (boutons, onglets, menus).
✅ **Do :** Utiliser des formulations neutres en genre.
✅ **Do :** Suivre AP Style pour la ponctuation et les abréviations.
❌ **Don't :** Idiomes, métaphores sportives, références culturelles locales.
❌ **Don't :** Conteneurs de boutons à largeur fixe sur des langues non testées.
❌ **Don't :** Supposer le genre de l'utilisateur dans les messages.
❌ **Don't :** Créativité stylistique au détriment de la clarté dans les interfaces fonctionnelles.

---

## Traduction en application concrète

- **En specs** : documenter les chaînes de texte courtes avec leur longueur max en caractères ET un exemple dans la langue la plus longue attendue (souvent allemand ou finnois).
- **En design review** : vérifier que les conteneurs de texte (boutons, chips, labels) ont de la flexibilité ou un mécanisme de troncature propre.
- **En content audit** : identifier toutes les formulations idiomatiques et les replacer par leurs équivalents directs avant la phase de traduction.
