---
source: https://m3.material.io/foundations/content-design/alt-text
category: Foundations / Content Design
spec-version: v0.192
---

# Alt Text — Heuristiques de rédaction

Périmètre : alt text · légendes · types d'images · graphes & charts · images interactives

---

## Schéma de pensée

L'alt text n'est pas une description d'image — c'est une traduction de l'intention de l'image dans son contexte. Le même visuel peut avoir un alt text radicalement différent selon qu'il illustre un article de blog, une fiche produit ou un rapport de données. La règle première est de partir du contexte pour décider quoi dire, pas de l'image pour décider comment la décrire.

---

## Principes

- **Intention > description** : décrire le sens et le contexte, pas les détails visuels sans rapport avec la fonction de l'image.
- **Décoratif = `alt=""`** : si l'image n'ajoute pas d'information, la masquer aux AT est la bonne décision — `alt` absent est une erreur, `alt=""` est une intention.
- **Cohérence avec le contexte adjacent** : alt text et légende doivent se compléter sans se répéter — une duplication exacte impose deux lectures du même texte.
- **Limite de 140 caractères** : certains lecteurs d'écran tronquent au-delà — viser la concision.
- **Ne jamais commencer par "image de"** : les AT annoncent déjà "image" avant l'alt text.
- **Texte dans les images** : tout texte essentiel intégré visuellement doit figurer dans l'alt text si les AT ne peuvent pas le lire.

---

## Tokens de conception — règles de rédaction

| Situation | Formule alt text |
|-----------|-----------------|
| Image décorative | `alt=""` (vide explicite) |
| Image informative simple | Sujet + contexte pertinent (≤ 140 car.) |
| Produit en shopping app | Nom produit + attributs distinctifs |
| Chart éditorial (1 insight) | "Résumé de [type de données] + [insight principal]" |
| Chart d'analyse (multi-insights) | Structure générale + lien vers données source |
| Map / carte géographique | "Map de [lieu]" + info spatiale essentielle |
| Headshot | Nom de la personne (si identifiable et pertinent) |
| Diagramme fonctionnel | Action ou relation représentée |

---

## H1 — Décision de nécessité : alt text ou pas ?

Nécessité d'alt text ∝ Information perdue sans l'image [poids: très fort] − Redondance avec le texte de la page [poids: modéré]

- **Sens de chaque variable** : si retirer l'image laisse la page aussi informative, l'image est décorative → `alt=""`. Si l'image apporte un sens absent ailleurs, l'alt text est obligatoire.
- **Zone de bascule** : images qui "renforcent" une idée sans l'ajouter — décision subjective. Préférer `alt=""` si l'image est purement illustrative d'un texte déjà complet.
- **Raison généralisable** : exposer des images décoratives aux AT (via un alt text descriptif) crée du bruit cognitif — un utilisateur de lecteur d'écran entend "décoratif" comme une interruption inutile.

---

## H2 — Rédiger l'alt text : focus sur l'intention

Qualité d'alt text ∝ Alignement avec le contexte de la page [poids: fort] + Concision [poids: fort] + Identification de l'élément central [poids: fort] − Détails non pertinents pour le contexte [poids: modéré, négatif]

- **Exemple produit** : dans un shop, décrire l'article vendu ("Arrosoir scandinave à anse cuivrée, couleur crème"), pas le décor environnant ("sur un rebord de fenêtre, des mains d'enfant versant de l'eau...").
- **Exemple contextuel** : même photo de chaise → "Chaise de salle à manger en chêne brun" (shop) vs "Livres posés sur une chaise de bois près d'une baignoire vintage" (article déco).
- **Zone de bascule** : quand le contexte est ambigu (article généraliste), choisir l'interprétation la plus utile pour l'utilisateur type de la page — pas la plus complète visuellement.
- **Raison généralisable** : l'alt text suit le contexte, pas l'image — la même image dans deux contextes différents mérite deux alt texts différents.

---

## H3 — Charts et graphes : extraire l'insight, pas les données

Utilité de l'alt text de chart ∝ Capture de l'insight principal [poids: fort] + Contexte du type de chart [poids: modéré] − Énumération des points de données [poids: fort, négatif]

- **Chart éditorial (1 takeaway)** : formuler l'insight directement. Ex : "Votre compte de pas était 55% plus élevé cette semaine avec 4 106 pas supplémentaires en moyenne."
- **Chart d'analyse (multi-takeaways)** : décrire la structure générale + inviter à explorer les données. Éviter d'introduire un biais en choisissant un seul takeaway arbitraire.
- **Formule générale** : "Résumé de [type de données] + [raison de montrer ce graphe]"
- **Zone de bascule** : chart d'analyse avec 2–3 takeaways évidents → les inclure tous. Au-delà, préférer un lien vers les données brutes plutôt qu'une liste exhaustive.
- **Raison généralisable** : copier les valeurs des points de données dans l'alt text reproduit la surcharge cognitive du graphe lui-même — l'alt text doit offrir l'insight, pas les données brutes.

---

## H4 — Légendes et alt text : complémentarité, pas duplication

Expérience AT ∝ Complémentarité légende/alt text [poids: fort] − Répétition exacte légende dans alt text [poids: fort, négatif]

- **Rôle de la légende** : information utile aux utilisateurs voyants ET aux AT — doit apporter une valeur propre à l'image.
- **Alt text par rapport à la légende** : capturer l'essentiel visuel que la légende ne dit pas déjà.
- **Zone de bascule** : si la légende est déjà complète, l'alt text peut être minimal (juste l'objet central) sans être une répétition.
- **Cohérence terminologique** : utiliser les mêmes mots que la légende pour le même objet — "antique" dans la légende et "vintage" dans l'alt text créent une incohérence.

---

## Règles Do / Don't

✅ **Do :** Écrire `alt=""` pour les images décoratives.
✅ **Do :** Limiter l'alt text à 140 caractères.
✅ **Do :** Adapter l'alt text au contexte de la page, pas seulement à l'image.
✅ **Do :** Pour les charts éditoriaux : capturer l'insight dans l'alt text.
✅ **Do :** Dupliquer le texte essentiel intégré dans une image dans l'alt text.
❌ **Don't :** Commencer par "image de" ou "photo de".
❌ **Don't :** Répéter la légende mot pour mot dans l'alt text.
❌ **Don't :** Omettre l'attribut `alt` — le lecteur d'écran lit alors le nom du fichier.
❌ **Don't :** Énumérer tous les points de données d'un chart dans l'alt text.
❌ **Don't :** Décrire les détails décoratifs hors contexte (cadre, arrière-plan, accessoires).

---

## Traduction en application concrète

- **En spec de design** : pour chaque composant avec image, inclure l'alt text recommandé — ne pas laisser ce choix aux développeurs.
- **En content review** : passer l'alt text au test "enlève l'image : l'alt text suffit-il à comprendre ce que l'image apportait ?" Si non, réécrire.
- **En audit AT** : activer VoiceOver/TalkBack et naviguer les écrans avec images — l'alt text doit communiquer l'information sans voir l'image.
- **Pour les charts** : livrer un alt text distinct pour chaque variante éditoriale vs analytique — ne pas utiliser le même template pour les deux.
