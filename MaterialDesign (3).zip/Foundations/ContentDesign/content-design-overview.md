---
source: https://m3.material.io/foundations/content-design/overview
category: Foundations / Content Design
spec-version: v0.192
---

# Content Design — Vue d'ensemble

Périmètre : UX writing · design de l'information · principes fondateurs · rôle du contenu dans l'UI

---

## Schéma de pensée

Le content design n'est pas de la rédaction appliquée à l'interface — c'est une discipline de design à part entière. Chaque mot d'une interface est une décision de design : il occupe de l'espace, il oriente l'action, il communique une relation de confiance. Les principes de content design M3 partent d'une conviction : un texte clair réduit la friction, un texte ambigu la crée. Le content designer est responsable de la clarté fonctionnelle de l'interface, pas de son style.

---

## Principes

- **Le contenu est une infrastructure, pas de la décoration** : le texte d'interface guide les décisions et les actions — il n'est pas là pour "enrichir" l'UI.
- **Clarté > Créativité** : dans les interfaces fonctionnelles, la clarté prime toujours. La créativité stylistique est réservée aux surfaces marketing/éditoriales.
- **Concision par défaut** : chaque mot qui ne contribue pas à la compréhension doit être retiré — la brièveté est une marque de respect pour l'attention de l'utilisateur.
- **Le contenu et la structure sont inséparables** : ce que dit un écran et comment il est organisé sont des décisions liées — le content designer et l'UX designer travaillent sur le même problème.
- **Cohérence du vocabulaire** : un même concept doit toujours être désigné par le même terme dans toute l'interface — l'incohérence terminologique crée une confusion cognitive.

---

## Heuristiques

**H1 — Hiérarchie du contenu : information critique en premier**

Compréhension immédiate ∝ Position de l'information critique [poids: très fort] + Progressivité de l'information [poids: fort] − Texte introductif avant le point essentiel [poids: fort, négatif]

- **Sens de chaque variable** : les utilisateurs lisent en "F" (première ligne, partie gauche des lignes suivantes) — l'information la plus importante doit être dans le premier tiers visible.
- **Pattern éprouvé** : titre = quoi / corps = pourquoi ou comment / CTA = action suivante. Ne pas inverser cet ordre.
- **Zone de bascule** : textes d'erreur et d'état vide — commencer par l'impact sur l'utilisateur ("Impossible d'envoyer votre message") avant la cause technique ("Erreur réseau 503").
- **Raison généralisable** : l'utilisateur arrête de lire dès qu'il a l'information suffisante pour agir — si cette information est à la fin, une partie des utilisateurs agira sans l'avoir vue.

---

**H2 — Cohérence terminologique**

Clarté du vocabulaire ∝ Uniformité des termes pour un même concept [poids: fort] − Synonymes pour le même concept dans la même interface [poids: fort, négatif]

- **Sens de chaque variable** : "Sauvegarder" sur un écran et "Enregistrer" sur un autre pour la même action crée un doute : "sont-ce deux actions différentes ?"
- **Glossaire de contenu** : définir et documenter les termes-clés du produit (noms des entités, labels des actions critiques) avant de rédiger — tous les contenus s'y conforment.
- **Zone de bascule** : mots techniques vs mots courants — utiliser le vocabulaire de l'utilisateur, pas celui de l'équipe produit. "Fichier supprimé définitivement" > "Hard delete effectué".
- **Raison généralisable** : l'incohérence terminologique n'est pas un défaut de rédaction — c'est un signal d'architecture d'information floue qui se manifeste dans le texte.

---

**H3 — Rôle du content design dans le processus**

Impact du content design ∝ Implication dès la phase de conception [poids: fort] + Intégration dans les specs [poids: fort] − Contenu ajouté en fin de projet [poids: très fort, négatif]

- **Sens de chaque variable** : le contenu ajouté en fin de processus "remplit" les espaces prévus pour lui — il ne peut pas influencer la structure de la page, la hiérarchie des sections ni les flows. Impliquer le content design dès le wireframing permet de concevoir la structure ET le contenu ensemble.
- **Zone de bascule** : projets avec des délais serrés — au minimum, spécifier les types de contenu (titre court, description, CTA) et leurs contraintes (longueur max) avant de commencer les maquettes.
- **Raison généralisable** : une maquette sans contenu réel est une hypothèse sur ce que le contenu sera — ces hypothèses sont systématiquement démenties par le contenu réel, qui est plus long, plus complexe, ou structuré différemment.

---

**H4 — Contenu comme outil de confiance**

Confiance de l'utilisateur ∝ Transparence du langage [poids: fort] + Cohérence entre promesse et réalité [poids: fort] − Formulations ambiguës sur les conséquences [poids: fort, négatif]

- **Sens de chaque variable** : un utilisateur qui comprend exactement ce qu'une action fera (et ce qu'elle ne fera pas) a confiance dans le produit. Un texte qui minimise, exagère ou ambiguïse les conséquences érode cette confiance.
- **Zone de bascule** : textes des CTA de conversion ("Essayer gratuitement" vs "Commencer l'essai gratuit de 30 jours — aucune carte requise") — la précision augmente la conversion ET la confiance, l'ambiguïté peut générer du volume mais crée de la déception.
- **Raison généralisable** : la confiance se construit dans les micro-moments — chaque texte d'interface est une opportunité de la renforcer ou de l'éroder.

---

## Périmètre du Content Design M3

| Sujet | Fichier de référence |
|-------|---------------------|
| Alt text et texte dans les images | `content-design-alt-text.md` |
| Écriture globale et localisation | `content-design-global-writing.md` |
| Rédaction de notifications | `content-design-notifications.md` |
| Style guide : casse, ponctuation, abréviations | `content-design-style-guide.md` |

---

## Règles Do / Don't

✅ **Do :** Impliquer le content design dès la phase de wireframing.
✅ **Do :** Définir un glossaire de termes-clés avant de rédiger les interfaces.
✅ **Do :** Placer l'information critique en premier (titre, première ligne).
✅ **Do :** Utiliser le vocabulaire de l'utilisateur, pas celui de l'équipe technique.
❌ **Don't :** Traiter le contenu comme du "Lorem ipsum" à remplacer en fin de projet.
❌ **Don't :** Utiliser des synonymes pour le même concept dans la même interface.
❌ **Don't :** Prioriser la créativité stylistique sur la clarté fonctionnelle.
❌ **Don't :** Laisser les développeurs choisir les labels et messages d'erreur sans validation content design.

---

## Traduction en application concrète

- **En brief de design** : inclure une section "contraintes de contenu" (longueurs max, types de texte attendus) dans chaque spec de composant.
- **En review** : pour chaque écran, identifier les textes qui n'ont pas été validés par un content designer et les traiter comme des dettes de qualité.
- **En handoff** : livrer les spécifications de contenu (texte exact, longueur max, comportement de troncature) en même temps que les spécifications visuelles — pas séparément.
