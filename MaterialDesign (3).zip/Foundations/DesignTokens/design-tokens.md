---
source: https://m3.material.io/foundations/design-tokens
category: Foundations / Design Tokens
spec-version: v0.192
---

# Design Tokens — Heuristiques de décision

Périmètre : classes de tokens (reference / system / component) · nomenclature · usage dans design et code · thèmes

---

## Schéma de pensée

Les design tokens sont le pont entre la décision de design et l'implémentation technique. Ils remplacent les valeurs codées en dur par des noms porteurs de sens, permettant à un changement de s'appliquer partout simultanément. La hiérarchie en trois classes (reference → system → component) est la clé : chaque classe a une portée différente et une audience différente — confondre les classes brise la scalabilité du système.

---

## Principes

- **Token = nom + valeur** : `md.ref.palette.secondary90` pointe vers `#E8DEF8` — le nom reste stable, la valeur peut changer.
- **Trois classes de tokens** : reference (palette brute), system (rôles sémantiques), component (propriétés spécifiques d'un composant).
- **Valeur unique** : un token peut pointer vers une couleur, une fonte, une mesure, ou un autre token.
- **Source de vérité unique** : designer et développeur référencent le même token → garantie de cohérence même quand la valeur change.
- **Propagation automatique** : changer la valeur d'un token système met à jour tous les composants qui le consomment.

---

## Structure des trois classes de tokens

| Classe | Préfixe | Portée | Audience |
|--------|---------|--------|---------|
| Reference | `md.ref.` | Palette brute, valeurs concrètes | Design system / theming |
| System | `md.sys.` | Rôles sémantiques (color, typescale, shape, elevation) | Composants, designers |
| Component | `md.comp.` | Propriétés d'un composant précis | Ingénieurs, design specs |

### Exemple de cascade
```
md.ref.palette.primary40 = #6750A4
  ↓
md.sys.color.primary = md.ref.palette.primary40
  ↓
md.comp.filled-button.container.color = md.sys.color.primary
```

---

## Nomenclature des tokens

Format : `md.[class].[category].[subcategory].[property]`

| Segment | Exemples |
|---------|----------|
| class | `ref`, `sys`, `comp` |
| category | `color`, `typescale`, `shape`, `elevation`, `palette` |
| subcategory | `primary`, `secondary`, `label-large`, `corner-full` |
| property | `color`, `font`, `size`, `weight`, `line-height` |

Exemple complet : `md.comp.fab.primary.container.color` → couleur de surface du FAB primaire.

---

## H1 — Choisir la classe de token à référencer

Bonne pratique de référence ∝ Niveau d'abstraction requis [poids: fort] − Référencement de tokens de classe inférieure [poids: modéré, négatif]

| Contexte | Classe à utiliser |
|----------|------------------|
| Construire un composant M3 standard | `md.sys.*` (rôles couleur, typescale) |
| Créer un composant custom | `md.sys.*` d'abord, `md.ref.*` si besoin d'une nuance palette précise |
| Lire une spec de composant M3 | `md.comp.*` pour les valeurs exactes du composant |
| Construire un thème de marque | `md.ref.*` pour définir la palette source |

- **Zone de bascule** : utiliser directement `md.ref.palette.primary40` dans un composant bypasse la sémantique système → si le thème change (dark mode, dynamic color), le composant ne s'adapte pas.
- **Raison généralisable** : plus on monte en abstraction (comp → sys → ref), plus on gagne en résilience thématique mais moins on contrôle la valeur exacte.

---

## H2 — Tokens vs valeurs codées en dur

Maintenabilité ∝ Usage de tokens [poids: très fort] − Valeurs hexadécimales directes [poids: très fort, négatif]

- **Hex dur = dette** : `#6750A4` dans un composant ne se met jamais à jour avec le thème — dark mode, dynamic color, thème de marque : tout échoue.
- **Token system = résilience** : `md.sys.color.primary` vaut `#6750A4` en light et `#D0BCFF` en dark automatiquement.
- **Zone de bascule** : les couleurs de marque figées (logo, badge critique) peuvent nécessiter des valeurs fixes — utiliser dans ce cas `md.sys.color.primary-fixed` ou des custom tokens documentés, pas des hex libres.
- **Raison généralisable** : chaque valeur codée en dur est un point de déchirure potentielle lors d'une mise à jour thématique — et ces mises à jour arrivent toujours.

---

## H3 — Quand utiliser les design tokens (critères de pertinence)

Valeur des tokens ∝ Complexité du produit [poids: fort] + Nombre de plateformes [poids: fort] + Fréquence des mises à jour thématiques [poids: modéré]

**Tokens particulièrement utiles si :**
- Design system partagé entre plusieurs équipes ou produits
- Support de plusieurs thèmes (clair/sombre, marques, dynamic color)
- Collaboration design ↔ développement sur des cycles rapides
- Scalabilité sur Android, Web, iOS simultanément

**Tokens moins critiques si :**
- Projet one-shot avec une seule équipe et un seul thème
- Prototype ou preuve de concept sans maintenance prévue

- **Zone de bascule** : même sur un projet simple, utiliser les tokens M3 système dès le départ coûte zéro effort supplémentaire — le risque est de devoir refactoriser si le projet grossit.

---

## H4 — Tokens dans les contextes (contextes spécifiques)

Résultat contextuel ∝ Token adapté au contexte [poids: fort] − Token hors contexte [poids: modéré, négatif]

| Contexte | Comportement attendu |
|----------|---------------------|
| Dark mode | `md.sys.color.*` → valeurs automatiquement inversées |
| Dynamic color (Android 12+) | `md.sys.color.*` → valeurs extraites du wallpaper |
| Contraste élevé | `md.sys.color.*` → valeurs à fort contraste |
| Thème de marque | `md.sys.color.primary` remappé vers la couleur de marque |

- **Zone de bascule** : custom tokens (`md.comp.custom-button.background`) — fonctionnent si mappés sur des tokens système ; échouent s'ils pointent vers des valeurs brutes hors système.

---

## Tokens de référence rapide (M3 system)

### md.sys.color (principaux)
| Token | Usage |
|-------|-------|
| `primary` | Action principale |
| `on-primary` | Texte/icône sur `primary` |
| `primary-container` | Surface d'action tonal |
| `secondary-container` | Indicateurs de sélection |
| `surface` | Fond de base |
| `on-surface` | Texte principal |
| `outline` | Bordures |

### md.sys.shape
| Token | Valeur |
|-------|--------|
| `corner-none` | 0px |
| `corner-extra-small` | 4px |
| `corner-small` | 8px |
| `corner-medium` | 12px |
| `corner-large` | 16px |
| `corner-extra-large` | 28px |
| `corner-full` | 9999px |

### md.sys.elevation
| Level | Valeur |
|-------|--------|
| `level0` | 0dp |
| `level1` | 1dp |
| `level2` | 3dp |
| `level3` | 6dp |
| `level4` | 8dp |
| `level5` | 12dp |

---

## Règles Do / Don't

✅ **Do :** Utiliser `md.sys.color.*` dans tous les composants (pas `md.ref.palette.*` directement).
✅ **Do :** Documenter les custom tokens selon la même convention de nommage.
✅ **Do :** Référencer les mêmes tokens en design (Figma) et en code.
❌ **Don't :** Coder des valeurs hex directement dans les composants.
❌ **Don't :** Bypasser la hiérarchie ref → sys → comp dans les composants.
❌ **Don't :** Inventer des noms de tokens sans suivre la convention `md.[class].[cat].[prop]`.

---

## Traduction en application concrète

- **En Figma** : utiliser exclusivement les variables de token M3 — jamais le color picker libre pour les éléments UI.
- **En code** : `var(--md-sys-color-primary)` plutôt que `#6750A4` — même règle pour les autres catégories.
- **En handoff design→dev** : annoter les specs avec les noms de tokens exacts (pas les valeurs hex) — la valeur peut changer, le token ne change pas.
- **En thème de marque** : définir la palette source dans les tokens ref, laisser le système générer les tokens système → les composants s'adaptent sans modification.
