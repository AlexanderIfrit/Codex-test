---
source: https://m3.material.io/foundations/building-for-all
category: Foundations / Building For All
spec-version: v0.192
---

# Building for All — Construire pour tout le monde

Périmètre : design inclusif · co-design · dimensions d'expérience · recherche avec les communautés

---

## Schéma de pensée

Construire pour tous ne signifie pas construire pour un utilisateur moyen universel — cet utilisateur n'existe pas. Il s'agit de reconnaître activement les dimensions de l'expérience humaine qui peuvent être exclues, et d'inclure ces perspectives dans la recherche, la conception et les tests. L'équipe produit ne peut pas représenter tous ses utilisateurs, mais elle peut choisir de travailler avec les communautés concernées plutôt que de les imaginer.

---

## Principes

- **L'équipe ne suffit pas** : un team homogène produit un produit homogène — inclure activement des perspectives extérieures, notamment celles des groupes souvent négligés.
- **Dimensions d'expérience** : âge, culture, handicap, éducation & littératie, ethnicité, genre, géographie & pertinence mondiale, attributs physiques, race, religion, orientation sexuelle, statut socio-économique, maîtrise technologique.
- **Co-design, pas test** : collaborer avec les communautés dès la conception, pas uniquement les tester sur des prototypes finis.
- **Les besoins évoluent** : une personne peut être dans des situations très différentes au cours de sa vie — concevoir pour un spectre de besoins changeants, pas pour un profil figé.

---

## Heuristiques

**H1 — Étendue de la représentation dans la recherche**

Inclusivité du produit ∝ Diversité des profils de recherche [poids: fort] + Profondeur d'implication des communautés marginalisées [poids: fort] − Généralisation de patterns majoritaires [poids: modéré, négatif]

- **Sens de chaque variable** : plus la recherche couvre de dimensions d'expérience différentes, plus les angles morts sont identifiés tôt ; s'appuyer uniquement sur des patterns majoritaires crée des produits invisibles pour les minorités.
- **Zone de bascule** : la pression de calendrier pousse à se limiter aux utilisateurs "typiques" — documenter explicitement les dimensions non couvertes par la recherche comme risques connus.
- **Raison généralisable** : les produits conçus avec les communautés marginalisées deviennent souvent meilleurs pour tous (effets "curb cut") — ce n'est pas un coût, c'est un investissement en qualité.

---

**H2 — Co-design vs test utilisateur**

Impact inclusif ∝ Phase d'implication [poids: fort] + Pouvoir décisionnel laissé aux communautés [poids: modéré] − Implication uniquement en validation finale [poids: fort, négatif]

- **Sens de chaque variable** : impliquer des utilisateurs non-représentés en phase de conception permet d'explorer des alternatives ; les impliquer uniquement pour tester un prototype fini confirme des erreurs sans permettre de les éviter.
- **Zone de bascule** : co-designer nécessite des ressources (recrutement, facilitation, temps) — commencer par une ou deux sessions exploratoires avec des groupes ciblés plutôt que d'attendre les moyens d'un programme de co-design complet.
- **Raison généralisable** : l'expert de sa propre expérience est l'utilisateur lui-même — aucun persona ou empathy map ne remplace ce savoir de première main.

---

**H3 — Couverture des dimensions d'expérience**

Robustesse inclusive ∝ Nombre de dimensions couvertes dans l'audit [poids: modéré] + Profondeur d'analyse par dimension [poids: fort] − Présupposition que "accessible = inclusif" [poids: fort, négatif]

- **13 dimensions à auditer** : âge · culture · handicap · éducation/littératie · ethnicité · genre · géographie/pertinence mondiale · attributs physiques · race · religion · orientation sexuelle · statut socio-économique · maîtrise technologique.
- **Zone de bascule** : l'accessibilité (handicap) est une dimension parmi 13 — un produit WCAG AA conforme peut rester exclusif sur d'autres dimensions (ex : présupposition d'accès à une connexion rapide).
- **Raison généralisable** : chaque dimension non auditée est un angle mort potentiel ; les lister explicitement rend le risque visible et priorisable.

---

## Règles Do / Don't

✅ **Do :** Inclure explicitement les 13 dimensions dans les grilles de recherche et de test.
✅ **Do :** Collaborer avec des organisations et experts représentant des groupes marginalisés.
✅ **Do :** Documenter les dimensions non couvertes comme risques connus dans les specs produit.
✅ **Do :** Intégrer les perspectives minoritaires dès la phase de conception, pas uniquement en test.
❌ **Don't :** Présupposer qu'un design "universel" fonctionne pour tous sans recherche.
❌ **Don't :** Confondre accessibilité (conformité WCAG) et inclusivité (toutes dimensions).
❌ **Don't :** Recruter uniquement parmi les utilisateurs "typiques" ou proches de l'équipe.

---

## Traduction en application concrète

- **En cadrage de recherche** : pour chaque étude, lister les 13 dimensions et indiquer lesquelles sont couvertes, lesquelles sont exclues et pourquoi — rendre les angles morts explicites.
- **En brief de conception** : inclure une section "populations à risque d'exclusion" identifiant les groupes dont les besoins pourraient ne pas être satisfaits par le design proposé.
- **En test** : recruter délibérément au moins un profil par dimension prioritaire pour le contexte du produit — pas seulement des utilisateurs représentatifs de la majorité.
