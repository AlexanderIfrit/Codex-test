---
source: https://m3.material.io/foundations/customization
category: Foundations / Customizing Material
spec-version: v0.192
---

# Customizing Material — Heuristiques de personnalisation

Périmètre : dynamic color · schémas de couleur custom · thème de marque · color schemes statiques vs dynamiques

---

## Schéma de pensée

Personnaliser Material ne signifie pas sortir du système — c'est piloter le système avec ses propres valeurs d'entrée. M3 est conçu pour que la couleur de marque, les préférences de l'utilisateur (wallpaper), et les exigences d'accessibilité convergent automatiquement. Le levier principal est la **couleur source** : une seule valeur d'entrée génère un schéma complet cohérent et accessible. Le piège est de penser que personnaliser signifie remplacer des tokens par des hex fixes — c'est l'opposé de ce que le système attend.

---

## Principes

- **Dynamic color = union marque + préférences utilisateur** : M3 permet aux couleurs de marque et aux choix individuels de coexister sans conflit.
- **Thème custom = fallback obligatoire** : pour que le schéma dynamique (wallpaper) fonctionne, l'app doit d'abord avoir un thème custom auquel les couleurs générées peuvent se mapper.
- **Le système gère le contraste** : les ajustements de contraste, de lisibilité, d'états d'interaction et de structure des composants sont automatiques — ne pas les recalculer manuellement.
- **Dynamic color : choix développeur ET paramètre utilisateur** : activer le dynamic color requiert une décision technique ET le respect des préférences utilisateur — les deux peuvent coexister avec la couleur de marque.

---

## Heuristiques

**H1 — Couleur source : entrée du thème**

Cohérence thématique ∝ Qualité de la couleur source [poids: fort] + Chroma de la source [poids: modéré] − Valeurs hex directes dans les composants [poids: fort, négatif]

| Type de source | Quand l'utiliser |
|----------------|-----------------|
| Wallpaper utilisateur (Android 12+) | App grand public, personnalisation max |
| Couleur de contenu in-app (cover, image) | Media players, galeries, lecture |
| Couleur de marque statique | Enterprise, apps institutionnelles, iOS, web |

- **Zone de bascule** : source à faible chroma (gris, beige pâle) → schéma terne. Préférer une couleur de marque saturée comme fallback.
- **Raison généralisable** : l'algorithme HCT extrait la teinte mais ajuste chroma et tone automatiquement pour garantir l'accessibilité — la source oriente, elle ne commande pas le résultat final.

---

**H2 — Thème custom comme infrastructure**

Robustesse du dynamic color ∝ Présence d'un thème custom complet [poids: très fort] − App sans thème custom [poids: très fort, négatif]

- **Sans thème custom** : le dynamic color ne sait pas sur quoi se mapper → expérience dégradée ou absence de personnalisation.
- **Avec thème custom** : les couleurs générées (wallpaper, contenu) remplissent les rôles définis dans le thème — cohérence garantie.
- **Zone de bascule** : apps avec forte identité de marque — appliquer le dynamic color sélectivement (écran de profil, espace personnel) tout en maintenant la couleur de marque sur les écrans principaux.
- **Raison généralisable** : le thème custom est le contrat entre les décisions de marque et le système de couleur dynamique — sans lui, les deux entrent en conflit.

---

**H3 — Schéma statique vs dynamique**

Expérience de marque ∝ Contrôle de la couleur [poids: fort] + Cohérence multi-plateforme [poids: modéré] − Adaptabilité aux préférences utilisateur [poids: modéré]

| Schéma | Avantage | Limitation |
|--------|----------|------------|
| Baseline (statique M3) | Prêt à l'emploi, cohérent multiplateforme | Pas de personnalisation utilisateur |
| Dynamic color | Expérience personnelle, engagement élevé | Android 12+ seulement |
| Custom statique | Identité de marque forte | Nécessite le Material Theme Builder |
| Hybride | Marque + personalisation | Complexité d'implémentation |

- **Zone de bascule** : iOS n'a pas de dynamic color basé sur le wallpaper → prévoir systématiquement un fallback statique, même si Android utilise le dynamic.
- **Raison généralisable** : un produit multiplateforme doit avoir un schéma statique comme base — le dynamic color est une amélioration progressive, pas un remplacement.

---

**H4 — Custom color schemes : règles de sécurité**

Accessibilité du schéma custom ∝ Utilisation du Material Theme Builder [poids: fort] + Validation des paires de contraste [poids: fort] − Définition manuelle des paires on-X [poids: fort, négatif]

- **Ne pas définir `on-primary` manuellement** : la garantie de contraste 4.5:1 est algorithmique — la calculer à la main introduit des erreurs silencieuses.
- **Material Theme Builder** : outil officiel pour générer un schéma custom accessible à partir d'une couleur source.
- **Zone de bascule** : couleurs de marque à faible contraste intrinsèque (jaune clair, rose pâle) → l'algorithme peut les désaturer pour garantir le contraste — la couleur finale peut différer de la charte graphique de marque.
- **Raison généralisable** : HCT garantit algorithmiquement l'accessibilité des paires — sortir du système pour "contrôler" la couleur exacte brise cette garantie.

---

## Règles Do / Don't

✅ **Do :** Construire un thème custom avec Material Theme Builder avant d'activer le dynamic color.
✅ **Do :** Prévoir un schéma statique comme fallback pour iOS et Android < 12.
✅ **Do :** Appliquer le dynamic color sélectivement (espaces personnels) si la marque est forte.
✅ **Do :** Laisser le système calculer les paires `on-X` pour garantir le contraste.
❌ **Don't :** Coder des hex directement dans les composants.
❌ **Don't :** Supposer que dynamic color = perte de contrôle de la marque.
❌ **Don't :** Définir manuellement `on-primary`, `on-secondary`, etc. sans validation algorithmique.

---

## Traduction en application concrète

- **En setup** : entrer la couleur primaire de marque dans Material Theme Builder → exporter le schéma de tokens → mapper dans Figma ET dans le code (même source de vérité).
- **En design** : utiliser le schéma généré comme palette Figma — ne pas ajuster les valeurs individuellement dans les composants.
- **En code** : implémenter le thème custom PUIS activer le dynamic color comme surcouche — tester les deux modes (dynamique + fallback statique).
