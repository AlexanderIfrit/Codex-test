---
source: https://m3.material.io/foundations/watches
category: Foundations / Devices
spec-version: v0.192
---

# Design for Watches (Wear OS) — Heuristiques de décision

Périmètre : contraintes d'écran montre · interactions Wear OS · M3 Expressive · layout circulaire / carré

---

## Schéma de pensée

Concevoir pour les montres n'est pas une réduction de l'interface mobile — c'est un changement de paradigme complet. L'espace est radically contraint (< 50mm), les interactions durent secondes, pas minutes, et la montre est un appareil à usage contextuel ultra-court. Toute l'architecture d'information doit être repensée : une montre n'affiche pas une app, elle répond à un besoin précis en moins de 10 secondes.

---

## Principes

- **Glanceability first** : l'information doit être comprise en un coup d'œil — pas de lecture, pas de scan.
- **Interactions ultra-courtes** : une tâche sur montre dure < 10 secondes — si c'est plus long, c'est un cas mobile.
- **Contrôles de montre** : Digital Crown / Bezel rotatif, boutons physiques, swipes — les intégrer comme inputs primaires, pas secondaires.
- **M3 Expressive on Wear OS** : composants spécifiques adaptés aux formes circulaires et aux tailles d'écran < 50mm.
- **Ressources limitées** : batterie, connexion, puissance CPU — les animations doivent être légères et intentionnelles.

---

## Heuristiques

**H1 — Réduction d'information : ce qui doit rester vs disparaître**

Lisibilité sur montre ∝ Densité informationnelle réduite [poids: très fort] + Hiérarchie extrême [poids: fort] − Éléments secondaires ou tertiaires [poids: fort, négatif]

- **Règle de réduction** : si une information est "nice to have" sur mobile, elle n'a pas sa place sur montre. Ne garder que ce qui répond à la question "que fait l'utilisateur dans les prochaines 10 secondes ?"
- **Zone de bascule** : données complexes (graphes, tableaux, listes longues) — ne pas les adapter, les supprimer. Afficher uniquement le chiffre ou l'insight principal.
- **Raison généralisable** : un écran de 40mm visible depuis un poignet en mouvement impose une hiérarchie absolue — une seule information principale, les autres sacrifiées.

---

**H2 — Cibles tactiles et taille de texte**

Utilisabilité physique ∝ Taille des cibles [poids: très fort] + Corps de texte [poids: fort] − Éléments trop petits pour un doigt en mouvement [poids: très fort, négatif]

- **Cible minimale** : 48×48dp (même règle que mobile, plus critique sur montre).
- **Corps de texte minimal** : 12sp (préférer 14–16sp pour les informations primaires).
- **Zone de bascule** : layout avec plusieurs boutons sur un écran montre — réduire drastiquement le nombre d'actions (max 2) plutôt que de réduire la taille.
- **Raison généralisable** : sur montre, les interactions se font debout, en mouvement, avec un seul doigt — la précision est inférieure à celle du mobile posé sur une table.

---

**H3 — Forme d'écran : circulaire vs carré**

Cohérence visuelle ∝ Adaptation à la forme de l'écran [poids: fort] − Layouts rectangulaires copiés du mobile [poids: fort, négatif]

- **Écran circulaire** : placer les éléments importants au centre et dans la zone visible centrale — les coins sont masqués.
- **Zones mortes** : sur les écrans ronds, ~15% des coins sont hors cadre — ne jamais y placer d'actions ou d'informations critiques.
- **Zone de bascule** : texte long sur écran circulaire — utiliser `ScalingLazyColumn` (Wear OS) pour le scroll, ne pas tenter d'adapter un layout mobile directement.
- **Raison généralisable** : les composants Wear OS M3 sont conçus pour les deux formes — utiliser les composants natifs plutôt que de recréer des layouts custom.

---

**H4 — Navigation : rotatif et swipes**

Fluidité de navigation ∝ Intégration du Digital Crown/Bezel [poids: fort] + Swipes latéraux pour dismissal [poids: modéré] − Navigation par tap uniquement [poids: modéré, négatif]

- **Digital Crown / Bezel rotatif** : input principal pour le scroll et la sélection — ne pas le traiter comme optionnel.
- **Swipe vers bas** : convention universelle de dismissal sur Wear OS — toujours implémenter.
- **Zone de bascule** : interactions complexes (multi-step, formulaires) → les renvoyer sur le téléphone apparié plutôt que de les forcer sur montre.
- **Raison généralisable** : la montre est un device de consultation et d'action simple — les flux complexes appartiennent au téléphone.

---

## Règles Do / Don't

✅ **Do :** 1 action principale par écran montre maximum.
✅ **Do :** Intégrer le Digital Crown / Bezel comme input de navigation primaire.
✅ **Do :** Tester sur écran circulaire ET carré si le produit les supporte tous deux.
✅ **Do :** Utiliser les composants Wear OS natifs (ScalingLazyColumn, Chip, Button Wear).
❌ **Don't :** Adapter des layouts mobiles directement — reconcevoir depuis zéro.
❌ **Don't :** Placer des éléments critiques dans les coins d'un écran circulaire.
❌ **Don't :** Créer des flux > 3 étapes sur montre — renvoyer vers mobile.
❌ **Don't :** Utiliser du texte < 12sp.

---

## Traduction en application concrète

- **En conception** : commencer par la question "quel est l'unique besoin que l'utilisateur satisfait en < 10s ?" → cela définit le seul écran principal.
- **En spec** : annoter les zones mortes des écrans circulaires dans les maquettes.
- **En test** : tester sur appareil physique montre — les émulateurs ne reproduisent pas fidèlement l'expérience tactile sur un poignet en mouvement.
