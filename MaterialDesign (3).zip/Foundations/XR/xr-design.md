---
source: https://m3.material.io/foundations/xr/design
category: Foundations / XR
spec-version: v0.192
---

# Design for Immersive XR — Heuristiques de décision

Périmètre : extended reality · interaction XR · layout spatial · accessibilité XR · M3 Expressive en XR

---

## Schéma de pensée

La réalité étendue (XR) regroupe AR (augmented reality) et VR (virtual reality) — des environnements où l'interface n'est plus contrainte par un rectangle d'écran fixe. Les principes M3 s'appliquent mais leurs expression change radicalement : profondeur, confort visuel, interactions spatiales et prévention de la fatigue sont des paramètres sans équivalent sur mobile ou desktop. Concevoir pour XR exige de repenser la proximité, l'échelle et le mouvement comme dimensions de design à part entière.

---

## Principes

- **Confort visuel primordial** : la fatigue oculaire et le mal des transports (motion sickness) sont des risques réels — les interactions doivent minimiser les mouvements brusques et le contenu flickering.
- **Espace 3D, UI 2D** : les composants M3 restent majoritairement planaires (panels 2D dans l'espace 3D) — éviter les interfaces entièrement spatiales pour les tâches textuelles.
- **Distance de lecture** : les éléments UI en XR ont des distances de lecture différentes du mobile — adapter les tailles de texte et d'icônes à la distance de placement dans l'espace.
- **Multi-modal** : XR combine gaze, gestes de main, contrôleurs, voix — concevoir pour plusieurs modalités simultanément.

---

## Heuristiques

**H1 — Distance et échelle des éléments UI**

Lisibilité en XR ∝ Taille angulaire des éléments [poids: très fort] + Distance de placement [poids: fort] − Taille absolue sans considération de distance [poids: fort, négatif]

- **Règle d'or** : en XR, la taille perçue dépend de la distance — un élément à 1m doit être plus grand qu'un élément à 0.5m pour la même lisibilité angulaire.
- **Zone de référence comfortable** : 0.5–2m pour les panneaux UI principaux. En-dessous de 0.5m → inconfort visuel. Au-delà de 3m → illisible.
- **Zone de bascule** : texte dans un environnement XR — toujours valider la lisibilité à la distance de placement prévue, pas seulement en mockup 2D.
- **Raison généralisable** : les dp et px n'ont pas de sens en XR — l'unité pertinente est le degré d'angle visuel (≥ 0.3° pour un texte lisible).

---

**H2 — Confort de mouvement et prévention du motion sickness**

Confort utilisateur ∝ Stabilité des éléments UI [poids: fort] + Mouvements lents et prévisibles [poids: fort] − Animations rapides / flickering [poids: très fort, négatif] − UI qui suit la tête (head-locked) [poids: fort, négatif]

- **UI world-locked vs head-locked** : préférer world-locked (panneau ancré dans l'espace) à head-locked (panneau qui suit la tête) — le head-locked provoque rapidement de la fatigue.
- **Exception head-locked** : notifications urgentes, HUD minimaux — limités à quelques secondes.
- **Animations** : transitions lentes (≥ 400ms), pas de flashs ni de mouvements brusques — respecter `prefers-reduced-motion` si supporté.
- **Zone de bascule** : scroll de contenu long en XR — privilégier la pagination (panel à panel) sur le scroll fluide qui peut provoquer du motion sickness.

---

**H3 — Interactions multi-modales**

Accessibilité de l'interaction ∝ Nombre de modalités supportées [poids: fort] + Feedback multi-sensoriel [poids: modéré] − Dépendance à une seule modalité [poids: fort, négatif]

| Modalité | Input | Feedback |
|----------|-------|---------|
| Gaze | Regard + dwell (maintien du regard) | Highlight visuel de la cible |
| Gestes de main | Pinch, tap, swipe dans l'air | Feedback visuel + haptique |
| Contrôleur | Triggers, boutons, joysticks | Feedback haptique + visuel |
| Voix | Commandes vocales | Confirmation visuelle |

- **Zone de bascule** : gaze + dwell seul → lent et inconfortable pour les tâches fréquentes. Combiner avec gestes ou contrôleur pour les actions répétées.
- **Raison généralisable** : en XR, les utilisateurs ont des préférences et des capacités très variables — un seul mode d'interaction exclut une partie significative des utilisateurs.

---

**H4 — Accessibilité spécifique XR**

Inclusivité en XR ∝ Alternatives textuelles aux éléments spatiaux [poids: fort] + Support des préférences de confort [poids: fort] − Expériences exclusivement visuelles/gestuelles [poids: modéré, négatif]

- **Confort de champ de vision** : ne pas placer d'informations critiques hors du champ de vision comfortable (60° autour du centre).
- **Préférences de réduction de mouvement** : respecter les paramètres système si disponibles.
- **Alternatives pour les interactions gestuelles** : toujours proposer une alternative contrôleur ou voix.
- **Zone de bascule** : expériences VR immersives (sans vue du monde réel) → risque accru de désorientation — prévoir des pauses, des sorties rapides et des repères spatiaux.

---

## Règles Do / Don't

✅ **Do :** Panneaux UI world-locked plutôt que head-locked.
✅ **Do :** Valider la lisibilité à la distance de placement réelle.
✅ **Do :** Supporter au moins 2 modalités d'interaction distinctes.
✅ **Do :** Limiter les animations rapides et les flashs.
❌ **Don't :** Placer du texte corps en XR sans test de distance.
❌ **Don't :** Concevoir des interactions geste-only sans alternative.
❌ **Don't :** Utiliser des panneaux head-locked pour du contenu long.
❌ **Don't :** Ignorer le motion sickness comme variable de design.

---

## Traduction en application concrète

- **En conception** : prototyper à l'échelle 1:1 dans l'espace dès le début — les mockups 2D ne révèlent pas les problèmes de distance et de confort.
- **En spec** : annoter chaque élément UI avec sa distance de placement prévue et sa taille angulaire cible.
- **En test** : effectuer des sessions de test de confort (minimum 10 minutes continues) pour détecter la fatigue et le motion sickness avant de valider un prototype.
