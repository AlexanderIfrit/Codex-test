---
source: https://m3.material.io/foundations/xr/components
category: Foundations / XR
spec-version: v0.192
---

# XR Components — Adaptation M3 en Extended Reality

Périmètre : composants M3 Expressive adaptés XR · App Bars · Dialogs · Navigation · Boutons

---

## Schéma de pensée

Les composants M3 en XR conservent leur sémantique fonctionnelle mais voient leur présentation transformée par les contraintes de l'espace 3D. L'adaptation n'est pas cosmétique — elle concerne la distance de lecture, l'interaction spatiale et le confort visuel. Chaque composant XR est une version du composant mobile conçue pour fonctionner à une distance ≥ 0.5m et avec des interactions multi-modales.

---

## Principes

- **Composants planaires dans l'espace 3D** : les composants M3 restent des surfaces 2D placées dans l'espace — ils n'ont pas de volumétrie propre.
- **Tailles adaptées à la distance** : les tokens de taille (hauteur de bouton, taille de texte) doivent être réévalués pour correspondre à la distance de placement XR.
- **Même hiérarchie, nouvelle expression** : la hiérarchie visuelle M3 (primary > secondary > tertiary) s'applique, mais les contrastes doivent être renforcés pour compenser la distance.
- **Feedback multi-sensoriel** : hover, focus et pressed states doivent être perceptibles à distance — amplifier les changements visuels.

---

## Heuristiques

**H1 — App Bars en XR**

Efficacité des App Bars XR ∝ Ancrage spatial clair [poids: fort] + Taille adaptée à la distance [poids: fort] − Réplication directe du mobile [poids: fort, négatif]

- **Placement** : ancrer l'App Bar en haut du panneau UI, world-locked — ne jamais head-locked.
- **Taille** : hauteur augmentée (≥ 64dp équivalent à distance normale) pour rester lisible à 0.5–1m.
- **Zone de bascule** : en VR immersif sans repères visuels, l'App Bar peut être réduite ou masquée pour ne pas obstruer la vue — utiliser un geste de rappel.

---

**H2 — Dialogs en XR**

Attention captée ∝ Contraste entre dialog et environnement [poids: fort] + Placement dans le champ de vision [poids: fort] − Dialog hors champ de vision [poids: très fort, négatif]

- **Placement** : toujours dans le champ de vision central comfortable (≤ 30° du centre du regard).
- **Overlay** : un scrim (fond semi-opaque) est indispensable pour séparer le dialog de l'environnement AR/VR.
- **Zone de bascule** : dialog bloquant en VR — raccourcir le contenu et limiter les choix (max 2 boutons) — l'utilisateur ne peut pas "regarder ailleurs" pour penser.
- **Raison généralisable** : un dialog hors champ de vision en XR équivaut à un dialog derrière un autre élément sur mobile — l'utilisateur ne sait pas qu'il est là.

---

**H3 — Boutons et interactions tactiles XR**

Actionnabilité ∝ Taille de la cible [poids: très fort] + Feedback visuel amplifié [poids: fort] − Cibles de taille mobile non adaptées [poids: fort, négatif]

- **Cible minimale** : équivalent ≥ 56dp à la distance de placement standard (vs 48dp mobile).
- **Hover state** : amplifié en XR — changement visible à la distance d'interaction.
- **Focus visible** : indicator de focus plus grand et plus contrasté qu'en mobile (gaze + dwell requiert un feedback clair d'activation).
- **Zone de bascule** : gaze-triggered buttons → prévoir un délai de confirmation (dwell de 1–2s) pour éviter les activations accidentelles.

---

**H4 — Navigation en XR**

Clarté de navigation ∝ Cohérence des points d'ancrage [poids: fort] + Stabilité de position des éléments de nav [poids: fort] − Navigation qui suit le regard [poids: fort, négatif]

- **Navigation Bar** : placer en position stable (bas du panneau, world-locked) — pas de navigation flottante qui suit la tête.
- **Navigation Drawer** : peut s'ouvrir latéralement dans l'espace — mais toujours world-locked et dans le champ de vision.
- **Zone de bascule** : XR avec déplacements physiques de l'utilisateur (room-scale VR) → la navigation spatiale (se déplacer vers une zone) peut remplacer les composants de navigation classiques.

---

## Tokens adaptés XR (ajustements recommandés)

| Token | Valeur mobile | Valeur XR recommandée |
|-------|--------------|----------------------|
| Button height | 40dp | 56dp+ |
| Text minimum | 12sp | 16sp (à 0.5m) |
| Touch target | 48×48dp | 56×56dp+ |
| Focus indicator width | 3px | 4px+ |
| Scrim opacity | 0.32 | 0.5–0.7 (pour séparation AR) |

---

## Règles Do / Don't

✅ **Do :** Augmenter les cibles d'interaction par rapport aux équivalents mobiles.
✅ **Do :** Amplifier les hover et focus states — visibles à distance.
✅ **Do :** Ancrer tous les composants de navigation world-locked.
✅ **Do :** Placer les dialogs dans le champ de vision central (≤ 30°).
❌ **Don't :** Copier les tailles de composants mobiles sans adaptation.
❌ **Don't :** Éléments de navigation head-locked.
❌ **Don't :** Dialog bloquant sans scrim pour séparer de l'environnement.
❌ **Don't :** Cible < 56dp équivalent pour les interactions gaze+dwell.

---

## Traduction en application concrète

- **En spec** : livrer deux versions des specs de composants — mobile et XR — avec les ajustements de taille annotés.
- **En design** : prototyper sur device XR réel avant de valider les tailles — les mockups 2D ne permettent pas de juger la lisibilité à distance.
- **En code** : utiliser les composants Compose XR ou les variants XR des libraries M3 — ne pas reconstruire à partir des composants mobile sans adaptation.
