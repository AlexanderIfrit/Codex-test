# Routage — Foundations M3

> Table de routage par besoin. Pour chaque question, le fichier à charger en priorité.
> Charger uniquement ce qui est nécessaire — chaque fichier est autonome.

---

## Par domaine de décision

### Accessibilité & Inclusion

| Besoin / Question | Fichier prioritaire |
|-------------------|-------------------|
| Quels composants M3 embarquent le support AT automatiquement ? | `Accessibility/accessibility-overview.md` |
| Créer un composant custom accessible : checklist | `Accessibility/accessibility-overview.md` |
| Contraste couleur : seuils WCAG, états, exceptions | `Accessibility/accessibility-designing.md` |
| Structure de focus : ordre Tab, indicateur visible, trappes | `Accessibility/accessibility-designing.md` |
| Annotation AT dans les specs design | `Accessibility/accessibility-designing.md` |
| Alt text : rédiger, décider de sa nécessité, cas limites | `Accessibility/accessibility-writing.md` |
| Texte redimensionnable : unités, zoom 200%, tronquature | `Accessibility/accessibility-writing.md` |
| Design inclusif : quelles populations à risque d'exclusion ? | `BuildingForAll/building-for-all.md` |
| Co-design vs test utilisateur : différence | `BuildingForAll/building-for-all.md` |
| Les 13 dimensions d'expérience à auditer | `BuildingForAll/building-for-all.md` |

---

### Content Design & UX Writing

| Besoin / Question | Fichier prioritaire |
|-------------------|-------------------|
| Principes fondateurs : rôle du contenu dans l'UI | `ContentDesign/content-design-overview.md` |
| Cohérence terminologique dans une interface | `ContentDesign/content-design-overview.md` |
| Alt text d'une image de produit, d'un chart, d'une carte | `ContentDesign/content-design-alt-text.md` |
| Alt text décoratif vs informatif : décision | `ContentDesign/content-design-alt-text.md` |
| Rédiger pour une audience internationale (localisabilité) | `ContentDesign/content-design-global-writing.md` |
| Expansion de texte à la traduction : buffer, exemples | `ContentDesign/content-design-global-writing.md` |
| Formulations neutres en genre | `ContentDesign/content-design-global-writing.md` |
| Notifications : efficacité, ciblage, CTA, opt-out | `ContentDesign/content-design-notifications.md` |
| Texte dynamique dans les notifications | `ContentDesign/content-design-notifications.md` |
| Sentence case vs title case dans l'UI | `ContentDesign/content-design-style-guide.md` |
| Communiquer les conséquences d'une action destructive | `ContentDesign/content-design-style-guide.md` |
| Titres scannables, abréviations, ponctuation | `ContentDesign/content-design-style-guide.md` |

---

### Design Tokens & Personnalisation

| Besoin / Question | Fichier prioritaire |
|-------------------|-------------------|
| Hiérarchie ref / sys / comp : quelle classe utiliser ? | `DesignTokens/design-tokens.md` |
| Convention de nommage `md.[class].[cat].[prop]` | `DesignTokens/design-tokens.md` |
| Tokens vs valeurs hex codées en dur | `DesignTokens/design-tokens.md` |
| Dark mode et dynamic color avec les tokens | `DesignTokens/design-tokens.md` |
| Tokens dans Figma vs code : synchronisation | `DesignTokens/design-tokens.md` |
| Couleur source : wallpaper vs marque vs contenu | `CustomizingMaterial/customizing-material.md` |
| Thème custom comme infrastructure du dynamic color | `CustomizingMaterial/customizing-material.md` |
| Schéma statique vs dynamique : choix selon le contexte | `CustomizingMaterial/customizing-material.md` |

---

### Interaction

| Besoin / Question | Fichier prioritaire |
|-------------------|-------------------|
| Gestes tactiles : types, latence, feedback en temps réel | `Interaction/interaction-gestures.md` |
| Conflits entre gestes in-app et gestes système Android | `Interaction/interaction-gestures.md` |
| Affordances pour la découverte des gestes | `Interaction/interaction-gestures.md` |
| Souris : hover, context menu, scroll wheel | `Interaction/interaction-inputs.md` |
| Clavier : Tab order, raccourcis, patterns ARIA | `Interaction/interaction-inputs.md` |
| Trackpad : pinch, two-finger drag, scroll | `Interaction/interaction-inputs.md` |
| Multi-input : adapter l'UI selon le mode d'input actif | `Interaction/interaction-inputs.md` |
| Sélection : indicateurs, unique vs multiple | `Interaction/interaction-selection.md` |
| Mode multi-sélection : entrée, signalement, barre d'actions | `Interaction/interaction-selection.md` |
| State layers : opacités hover / focus / pressed / disabled | `Interaction/interaction-states.md` |
| Composants disabled : opacité, visible ou masqué ? | `Interaction/interaction-states.md` |
| Combinaisons d'états (selected + hovered, focused + selected) | `Interaction/interaction-states.md` |
| Accessibilité des états (aria-disabled, aria-invalid, ripple) | `Interaction/interaction-states.md` |

---

### Layout & Structure

| Besoin / Question | Fichier prioritaire |
|-------------------|-------------------|
| 1, 2 ou 3 panes selon le breakpoint | `Layout/layout-overview.md` |
| 5 stratégies d'adaptation (Reveal, Divide, Resize, Reposition, Swap) | `Layout/layout-overview.md` |
| Zones du scaffold, position des composants globaux | `Layout/layout-scaffold.md` |
| App Bar : quelle variante (Small/Medium/Large) ? | `Layout/layout-scaffold.md` |
| FAB : position selon le breakpoint | `Layout/layout-scaffold.md` |
| Grille de colonnes, gouttières, marges | `Layout/layout-grids-spacing.md` |
| Unité 4dp : règle et tokens `spacing-*` | `Layout/layout-grids-spacing.md` |
| Padding interne des composants M3 standard | `Layout/layout-grids-spacing.md` |
| 5 breakpoints M3 : valeurs exactes | `Layout/layout-breakpoints.md` |
| Fenêtre vs device pour détecter le breakpoint | `Layout/layout-breakpoints.md` |
| Navigation selon le breakpoint (Bar→Rail→Drawer) | `Layout/layout-breakpoints.md` |
| Foldables, multi-window, orientation | `Layout/layout-breakpoints.md` |
| Layout RTL : quoi mirrorer, quoi fixer | `Layout/layout-bidirectionality-rtl.md` |
| Implémentation RTL : `start`/`end`, propriétés logiques CSS | `Layout/layout-bidirectionality-rtl.md` |
| Icônes directionnelles vs universelles en RTL | `Layout/layout-bidirectionality-rtl.md` |
| Layouts canoniques : Feed, List-Detail, Supporting Pane | `Layout/layout-canonical-examples.md` |
| Choisir entre Feed / List-Detail / Supporting Pane | `Layout/layout-canonical-examples.md` |
| Layering et layouts custom | `Layout/layout-canonical-examples.md` |

---

### Usabilité

| Besoin / Question | Fichier prioritaire |
|-------------------|-------------------|
| Hiérarchie visuelle : niveaux, règles de dominance | `Usability/usability-overview.md` |
| 5 tactiques expressives M3 (conteneur, taille, forme, couleur, typo) | `Usability/usability-overview.md` |
| Charge cognitive : seuils, gestion, surcharge | `Usability/usability-overview.md` |
| Concevoir basé sur les objectifs primaires | `Usability/usability-overview.md` |
| Appliquer M3 Expressive sur un flux complet | `Usability/usability-applying-expressive.md` |
| Mapper les tactiques expressives à des objectifs de flux | `Usability/usability-applying-expressive.md` |
| Test d'utilisabilité : méthodes, seuils d'alarme | `Usability/usability-applying-expressive.md` |

---

### Appareils spécialisés

| Besoin / Question | Fichier prioritaire |
|-------------------|-------------------|
| Wear OS (montre) : cibles tactiles, densité | `Devices/watches.md` |
| Texte minimum, navigation montre | `Devices/watches.md` |
| Écran circulaire vs carré : zones mortes | `Devices/watches.md` |
| Digital Crown / Bezel : input de navigation | `Devices/watches.md` |
| XR : distance des éléments, taille angulaire | `XR/xr-design.md` |
| XR : motion sickness, head-locked vs world-locked | `XR/xr-design.md` |
| XR : gaze, gestes de main, contrôleurs, voix | `XR/xr-design.md` |
| Composants M3 en XR : ajustements de taille | `XR/xr-components.md` |
| Navigation en XR : ancrage, world-locked | `XR/xr-design.md` |

---

## Décisions fréquentes (arbitrages inter-fichiers)

| Décision | Fichiers à croiser |
|----------|-------------------|
| Composant custom accessible : coût et checklist | `accessibility-overview.md` + `accessibility-designing.md` |
| Alt text dans un contexte précis | `accessibility-writing.md` + `content-design-alt-text.md` |
| Token couleur pour un composant custom | `design-tokens.md` + `customizing-material.md` |
| Hover-only action accessible en multi-input | `interaction-inputs.md` + `accessibility-designing.md` |
| Layout adaptatif complet (breakpoints + navigation + panes) | `layout-breakpoints.md` + `layout-overview.md` + `layout-scaffold.md` |
| Layout RTL avec canonical layout | `layout-bidirectionality-rtl.md` + `layout-canonical-examples.md` |
| Expressivité qui guide l'accessibilité (contraste + hiérarchie) | `usability-overview.md` + `accessibility-designing.md` |
| Notification accessible et bien rédigée | `content-design-notifications.md` + `accessibility-writing.md` |
